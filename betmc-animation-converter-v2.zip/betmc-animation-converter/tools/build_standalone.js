// Gera dist/betmc-standalone.html: o app inteiro em UM arquivo (CSS+JS embutidos), sem rede.
// Serve para testar no Chrome do celular (Arquivos > abrir com Chrome) sem APK.
const fs = require('fs'), path = require('path');
const W = path.join(__dirname, '..', 'www'), rd = (f) => fs.readFileSync(path.join(W, f), 'utf8');
let html = rd('index.html');
const inl = (code) => { if (/<\/script/i.test(code)) throw new Error('</script dentro do JS'); return code; };
html = html.replace('<link rel="stylesheet" href="style.css">', () => '<style>\n' + rd('style.css') + '\n</style>');
html = html.replace(/<script src="core\.js"[^>]*><\/script>/, () => '<script>\n' + inl(rd('core.js')) + '\n</script>');
html = html.replace(/<script src="app\.js"[^>]*><\/script>/, () => '<script>\n' + inl(rd('app.js')) + '\n</script>');
fs.mkdirSync(path.join(__dirname, '..', 'dist'), { recursive: true });
fs.writeFileSync(path.join(__dirname, '..', 'dist', 'betmc-standalone.html'), html);
console.log('dist/betmc-standalone.html', (html.length / 1024).toFixed(0) + ' KB');
