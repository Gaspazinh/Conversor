package com.betmc.converter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Motor NATIVO de VÍDEO → MCPACK (100% offline, sem bibliotecas externas).
 *
 * Divisão de trabalho (contrato com www/video.js):
 *  - JS decide TUDO que é lógica do pacote (JSONs, caminhos, quantidade de frames) a partir do pacote-base e do core.js;
 *  - Kotlin só faz o que o WebView não faz bem: decodificar o vídeo, recortar/redimensionar, gravar o ZIP em streaming
 *    (um quadro por vez, memória baixa) e devolver um RESUMO do ZIP gravado para o JS validar.
 *
 * Ordem geométrica de cada quadro (conforme pedido): rotação → recorte central 16:9 → redimensionamento.
 */
class VideoEngine(
    private val ctx: Context,
    private val post: (String) -> Unit,          // executa JS na página (thread qualquer)
    private val onBusy: (Boolean) -> Unit,       // liga/desliga "tela sempre ligada"
) {
    private val tag = "BetMC-Video"
    private val exec = Executors.newSingleThreadExecutor()
    private val cancelled = AtomicBoolean(false)
    private val busy = AtomicBoolean(false)
    @Volatile private var uri: Uri? = null
    private val outFile: File get() = File(ctx.cacheDir, "video_out.mcpack")
    private var baseCache: ByteArray? = null

    private class Stop : RuntimeException()
    private class Fail(msg: String) : RuntimeException(msg)

    private fun q(s: String) = JSONObject.quote(s)
    private fun call(fn: String, arg: String) = post("window.$fn&&window.$fn($arg)")
    private fun progress(frac: Double, stage: String) = post("window.__onVideoProgress&&window.__onVideoProgress($frac,${q(stage)})")

    /* ------------------------------------------------------------------ pacote-base (asset) */
    @Synchronized private fun base(asset: String): ByteArray {
        val c = baseCache
        if (c != null) return c
        val b = ctx.assets.open(asset).use { it.readBytes() }
        baseCache = b
        return b
    }
    fun baseSize(asset: String): Int = base(asset).size
    fun baseChunk(asset: String, index: Int, chunk: Int): String {
        val b = base(asset)
        val from = index * chunk
        if (from >= b.size) return ""
        val to = minOf(b.size, from + chunk)
        return Base64.encodeToString(b, from, to - from, Base64.NO_WRAP)
    }

    /* ------------------------------------------------------------------ geometria (espelha centerCrop de video.js) */
    private object Geo {
        /** [x, y, w, h] do recorte central com proporção tw:th, sem deformar. */
        fun centerCrop(sw: Int, sh: Int, tw: Int, th: Int): IntArray =
            if (sw.toLong() * th > sh.toLong() * tw) {
                val w = maxOf(1L, (sh.toLong() * tw) / th).toInt()
                intArrayOf((sw - w) / 2, 0, w, sh)
            } else {
                val h = maxOf(1L, (sw.toLong() * th) / tw).toInt()
                intArrayOf(0, (sh - h) / 2, sw, h)
            }
    }

    /** Lê quadros e entrega sempre na orientação correta (rotação aplicada exatamente uma vez). */
    private class Grabber(private val r: MediaMetadataRetriever, rawW: Int, rawH: Int, private val rot: Int) {
        private val swap = rot % 180 == 90
        private val expW = if (swap) rawH else rawW
        private val expH = if (swap) rawW else rawH
        fun at(timeUs: Long): Bitmap? {
            val raw = r.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
                ?: r.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: return null
            return upright(raw)
        }

        /**
         * O Android costuma entregar o quadro JÁ girado (API recente). Se vier nas dimensões "cruas" de um vídeo
         * com rotação 90/270, giramos aqui. Rotação 180 e vídeos quadrados não são distinguíveis por dimensão:
         * assume-se que o framework já aplicou (limitação documentada).
         */
        private fun upright(b: Bitmap): Bitmap {
            if (swap && expW != expH && b.width == expH && b.height == expW) {
                val m = Matrix().apply { postRotate(rot.toFloat()) }
                val g = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
                if (g !== b) b.recycle()
                return g
            }
            return b
        }
    }

    private fun scaleTo(src: Bitmap, w: Int, h: Int): Bitmap {
        var cur = src
        while (cur.width >= w * 2 && cur.height >= h * 2) { // reduz em passos de 1/2: evita serrilhado
            val n = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (cur !== src) cur.recycle()
            cur = n
        }
        if (cur.width != w || cur.height != h) {
            val n = Bitmap.createScaledBitmap(cur, w, h, true)
            if (cur !== src) cur.recycle()
            cur = n
        }
        return cur
    }

    private fun cropTo(src: Bitmap, tw: Int, th: Int): Bitmap {
        val c = Geo.centerCrop(src.width, src.height, tw, th)
        return if (c[0] == 0 && c[1] == 0 && c[2] == src.width && c[3] == src.height) src
        else Bitmap.createBitmap(src, c[0], c[1], c[2], c[3])
    }

    private fun pngBytes(b: Bitmap, opaque: Boolean): ByteArray {
        if (opaque) b.setHasAlpha(false) // PNG RGB (sem canal alfa), como os frames do pacote-base
        val bo = ByteArrayOutputStream(1 shl 20)
        if (!b.compress(Bitmap.CompressFormat.PNG, 100, bo)) throw Fail("Falha ao codificar PNG.")
        return bo.toByteArray()
    }

    private fun crcOf(b: ByteArray): Long { val c = CRC32(); c.update(b); return c.value }

    /** Imagem derivada do quadro já recortado em 16:9 (full-res): recorta para a proporção do alvo e redimensiona. */
    private fun derived(cropped16x9: Bitmap, w: Int, h: Int, opaque: Boolean): ByteArray {
        val c = cropTo(cropped16x9, w, h)
        val s = scaleTo(c, w, h)
        try { return pngBytes(s, opaque) } finally {
            if (s !== cropped16x9) s.recycle()
            if (c !== cropped16x9 && c !== s) c.recycle()
        }
    }

    private class FirstAssets(val icon: ByteArray, val stat: ByteArray, val frame1: ByteArray)

    /** Do primeiro quadro (já girado): recorte 16:9 → frame 1, imagem estática e ícone. Libera o bitmap recebido. */
    private fun firstFrameAssets(first: Bitmap, outW: Int, outH: Int, iconW: Int, iconH: Int, statW: Int, statH: Int): FirstAssets {
        val c16 = cropTo(first, 16, 9)
        try {
            val stat = derived(c16, statW, statH, false)
            val icon = derived(c16, iconW, iconH, false)
            val s = scaleTo(c16, outW, outH)
            val f1 = try { pngBytes(s, true) } finally { if (s !== c16) s.recycle() }
            return FirstAssets(icon, stat, f1)
        } finally {
            if (c16 !== first) c16.recycle()
            first.recycle()
        }
    }

    /* ------------------------------------------------------------------ 1) seleção/leitura do vídeo */
    fun probe(u: Uri) {
        exec.execute {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, u)
                val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                val mime = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: ""
                if (w <= 0 || h <= 0) throw Fail("O arquivo escolhido não parece ter faixa de vídeo legível.")
                if (dur <= 0L) throw Fail("Não foi possível ler a duração do vídeo.")
                val g = Grabber(r, w, h, rot)
                val f0 = g.at(0) ?: throw Fail("Não foi possível decodificar o primeiro quadro (codec não suportado neste aparelho?).")
                val th = scaleTo(f0, minOf(360, f0.width), maxOf(1, f0.height * minOf(360, f0.width) / f0.width))
                val jb = ByteArrayOutputStream()
                th.compress(Bitmap.CompressFormat.JPEG, 80, jb)
                if (th !== f0) th.recycle()
                f0.recycle()
                var name = ""
                try { ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: "" } } catch (_: Exception) {}
                uri = u
                val o = JSONObject().put("ok", true).put("name", name).put("durationMs", dur).put("width", w).put("height", h)
                    .put("rotation", rot).put("mime", mime).put("thumb", Base64.encodeToString(jb.toByteArray(), Base64.NO_WRAP))
                call("__onVideoPicked", o.toString())
            } catch (e: Throwable) {
                Log.e(tag, "probe falhou", e)
                call("__onVideoPicked", JSONObject().put("ok", false).put("err", e.message ?: e.toString()).toString())
            } finally { try { r.release() } catch (_: Exception) {} }
        }
    }

    /* ------------------------------------------------------------------ 2) extração + montagem do pacote */
    fun cancel() { cancelled.set(true) }

    fun build(planJson: String): String {
        val u = uri ?: return "err:Nenhum vídeo selecionado."
        val plan = try { JSONObject(planJson) } catch (e: Exception) { return "err:Plano inválido: ${e.message}" }
        if (!busy.compareAndSet(false, true)) return "err:Já existe uma conversão em andamento."
        cancelled.set(false)
        onBusy(true)
        exec.execute {
            try {
                runBuild(u, plan)
            } catch (e: Stop) {
                outFile.delete()
                call("__onVideoCancelled", "")
            } catch (e: OutOfMemoryError) {
                outFile.delete()
                call("__onVideoError", q("Memória insuficiente. Tente uma resolução menor (960×540 ou 854×480) ou menos FPS."))
            } catch (e: Throwable) {
                Log.e(tag, "build falhou", e)
                outFile.delete()
                call("__onVideoError", q(e.message ?: e.toString()))
            } finally {
                busy.set(false)
                onBusy(false)
            }
        }
        return "ok"
    }

    private fun checkStop() { if (cancelled.get()) throw Stop() }

    private fun runBuild(u: Uri, plan: JSONObject) {
        val n = plan.getInt("N")
        val fps = plan.getDouble("fps")
        val outW = plan.getJSONArray("frameSize").getInt(0)
        val outH = plan.getJSONArray("frameSize").getInt(1)
        val iconPath = plan.getString("iconPath"); val iconW = plan.getJSONArray("iconSize").getInt(0); val iconH = plan.getJSONArray("iconSize").getInt(1)
        val statPath = plan.getString("staticPath"); val statW = plan.getJSONArray("staticSize").getInt(0); val statH = plan.getJSONArray("staticSize").getInt(1)
        val manifestPath = plan.getString("manifestPath")
        val framePaths = plan.getJSONArray("framePaths")
        val drop = HashSet<String>().also { s -> plan.getJSONArray("dropPaths").let { a -> for (i in 0 until a.length()) s.add(a.getString(i)) } }
        val texts = plan.getJSONObject("texts")
        if (framePaths.length() != n) throw Fail("Plano inconsistente: ${framePaths.length()} caminhos para $n frames.")

        progress(0.0, "Verificando espaço e abrindo o vídeo")
        val need = (n.toLong() * outW * outH * 3 * 6 / 10) + 64L * 1024 * 1024
        val free = ctx.cacheDir.usableSpace
        if (free < need) throw Fail("Espaço livre insuficiente: preciso de cerca de ${need / 1048576} MB e há ${free / 1048576} MB. Libere espaço ou reduza FPS/resolução.")
        outFile.delete()

        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, u)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (w <= 0 || h <= 0 || dur <= 0L) throw Fail("Não foi possível reler o vídeo (arquivo movido ou permissão perdida). Selecione-o novamente.")
            val maxMs = (plan.optDouble("maxSeconds", 12.0) * 1000).toLong()
            if (n.toDouble() / fps > minOf(dur, maxMs) / 1000.0 + 1e-6) throw Fail("Plano pede $n frames a $fps FPS, mais do que o trecho permitido do vídeo.")
            val grab = Grabber(r, w, h, rot)

            // ---- primeiro quadro: vira frame 1, ícone e imagem estática
            progress(0.01, "Extraindo o primeiro quadro")
            val first = grab.at(0) ?: throw Fail("Falha ao decodificar o primeiro quadro do vídeo.")
            val assets = firstFrameAssets(first, outW, outH, iconW, iconH, statW, statH)
            val iconBytes = assets.icon
            val statBytes = assets.stat
            val frame1 = assets.frame1
            checkStop()

            // ---- pacote-base (somente leitura): tudo que não é frame/ícone/estática é copiado ou substituído pelo texto do plano
            progress(0.03, "Lendo o pacote-base")
            val baseEntries = LinkedHashMap<String, ByteArray?>() // null = diretório
            ZipInputStream(base(plan.getString("baseAsset")).inputStream()).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    val name = e.name.replace('\\', '/')
                    if (e.isDirectory) baseEntries[name] = null
                    else if (!drop.contains(name) && name != iconPath && name != statPath) baseEntries[name] = zin.readBytes()
                    e = zin.nextEntry
                }
            }

            // ---- ZIP final em streaming
            ZipOutputStream(BufferedOutputStream(FileOutputStream(outFile), 1 shl 16)).use { zos ->
                zos.setLevel(6)
                fun deflated(name: String, data: ByteArray) {
                    zos.putNextEntry(ZipEntry(name).apply { method = ZipEntry.DEFLATED })
                    zos.write(data); zos.closeEntry()
                }
                fun stored(name: String, data: ByteArray) { // PNG já é comprimido: grava sem recomprimir
                    val e = ZipEntry(name)
                    e.method = ZipEntry.STORED; e.size = data.size.toLong(); e.compressedSize = data.size.toLong(); e.crc = crcOf(data)
                    zos.putNextEntry(e); zos.write(data); zos.closeEntry()
                }
                fun putBase(name: String) {
                    when {
                        baseEntries[name] == null && baseEntries.containsKey(name) -> { zos.putNextEntry(ZipEntry(name)); zos.closeEntry() }
                        else -> deflated(name, baseEntries[name]!!)
                    }
                }
                fun emit(name: String) {
                    when {
                        texts.has(name) -> deflated(name, texts.getString(name).toByteArray(Charsets.UTF_8))
                        else -> putBase(name)
                    }
                }
                progress(0.04, "Gravando arquivos do pacote")
                if (baseEntries.containsKey(manifestPath) || texts.has(manifestPath)) emit(manifestPath)
                for (name in baseEntries.keys) if (name != manifestPath) emit(name)
                // ícone e estática: mesmos caminhos do pacote-base
                stored(iconPath, iconBytes)
                stored(statPath, statBytes)

                // ---- frames: um por vez; nada de imagens falsas ou duplicadas
                for (k in 0 until n) {
                    checkStop()
                    progress(0.05 + 0.90 * k / n, "Extraindo e gravando frame ${k + 1} de $n")
                    val bytes: ByteArray = if (k == 0) frame1 else {
                        val t = Math.round(k * 1_000_000.0 / fps)
                        val raw = grab.at(t) ?: throw Fail("Falha ao decodificar o quadro ${k + 1} (instante ${"%.2f".format(t / 1e6)} s). O codec deste vídeo pode não ser suportado.")
                        val c16 = cropTo(raw, 16, 9)
                        val s = scaleTo(c16, outW, outH)
                        try { pngBytes(s, true) } finally {
                            if (s !== c16) s.recycle()
                            if (c16 !== raw) c16.recycle()
                            raw.recycle()
                        }
                    }
                    stored(framePaths.getString(k), bytes)
                }
            }

            checkStop()
            progress(0.96, "Lendo o pacote gravado para validação")
            val gen = JSONObject().put("iconCrc", crcOf(iconBytes)).put("staticCrc", crcOf(statBytes)).put("frame1Crc", crcOf(frame1))
            val summary = summarize(outFile, gen)
            progress(1.0, "Pacote gravado")
            call("__onVideoBuilt", q(summary.toString()))
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    /** Resumo do ZIP gravado: lê o arquivo de verdade (CRC recalculado) e devolve ao JS para a validação. */
    private fun summarize(f: File, gen: JSONObject): JSONObject {
        val arr = JSONArray()
        ZipFile(f).use { z ->
            val en = z.entries()
            val buf = ByteArray(1 shl 16)
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (e.isDirectory) continue
                checkStop()
                val name = e.name.replace('\\', '/')
                val isJson = name.endsWith(".json", ignoreCase = true)
                val isPng = name.endsWith(".png", ignoreCase = true)
                val crc = CRC32()
                val head = ByteArray(32); var headLen = 0
                val text = if (isJson) ByteArrayOutputStream() else null
                var size = 0L
                z.getInputStream(e).use { ins ->
                    while (true) {
                        val r = ins.read(buf)
                        if (r < 0) break
                        crc.update(buf, 0, r); size += r
                        if (headLen < head.size) { val c = minOf(head.size - headLen, r); System.arraycopy(buf, 0, head, headLen, c); headLen += c }
                        text?.write(buf, 0, r)
                    }
                }
                val o = JSONObject().put("p", name).put("size", size).put("crc", crc.value).put("crcOk", e.crc == crc.value)
                if (isPng) {
                    val sig = intArrayOf(0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)
                    var ok = headLen >= 24
                    if (ok) for (i in sig.indices) if ((head[i].toInt() and 0xFF) != sig[i]) ok = false
                    fun be(p: Int) = ((head[p].toInt() and 0xFF) shl 24) or ((head[p + 1].toInt() and 0xFF) shl 16) or ((head[p + 2].toInt() and 0xFF) shl 8) or (head[p + 3].toInt() and 0xFF)
                    o.put("png", JSONObject().put("ok", ok).put("w", if (ok) be(16) else 0).put("h", if (ok) be(20) else 0))
                }
                if (text != null) o.put("text", String(text.toByteArray(), Charsets.UTF_8))
                arr.put(o)
            }
        }
        return JSONObject().put("entries", arr).put("gen", gen).put("fileSize", f.length())
    }

    /* ------------------------------------------------------------------ 3) exportação (SAF) */
    fun discard() { outFile.delete() }

    fun export(dest: Uri) {
        exec.execute {
            try {
                val f = outFile
                if (!f.exists()) throw Fail("O pacote gerado não está mais disponível. Converta o vídeo novamente.")
                val total = f.length()
                var done = 0L
                val os = ctx.contentResolver.openOutputStream(dest, "wt") ?: throw Fail("Android não abriu o destino escolhido.")
                os.use { out ->
                    FileInputStream(f).use { ins ->
                        val buf = ByteArray(1 shl 20)
                        var lastPct = -1
                        while (true) {
                            val r = ins.read(buf)
                            if (r < 0) break
                            out.write(buf, 0, r); done += r
                            val pct = (done * 100 / maxOf(1L, total)).toInt()
                            if (pct != lastPct) { lastPct = pct; call("__onVideoExportProgress", (done.toDouble() / total).toString()) }
                        }
                        out.flush()
                    }
                }
                var onDisk = -1L
                try { ctx.contentResolver.openFileDescriptor(dest, "r")?.use { onDisk = it.statSize } } catch (_: Exception) {}
                var name = ""
                try { ctx.contentResolver.query(dest, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: "" } } catch (_: Exception) {}
                call("__onVideoExported", JSONObject().put("ok", true).put("name", name).put("written", done).put("onDisk", onDisk).put("expected", total).toString())
            } catch (e: Throwable) {
                Log.e(tag, "export falhou", e)
                call("__onVideoExported", JSONObject().put("ok", false).put("err", e.message ?: e.toString()).toString())
            }
        }
    }

    fun shutdown() { cancelled.set(true); outFile.delete() }
}
