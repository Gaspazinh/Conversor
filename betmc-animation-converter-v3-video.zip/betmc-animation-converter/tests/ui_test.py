"""Testes reais da interface em Chromium (Playwright). Uso: python3 tests/ui_test.py
Cobre: fluxo completo por clique e por toque (emulação de celular), mensagens de erro, progresso,
ponte Android SIMULADA, falhas de carregamento de scripts e integridade do arquivo salvo."""
import base64, glob, hashlib, json, os, shutil, subprocess, sys, tempfile, zipfile
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
FX = os.path.join(HERE, 'fixtures'); A = os.path.join(FX, 'Hoshino_Animation_120_Frames-2.mcpack'); B = os.path.join(FX, 'Hoshino_Animation_288_Frames_3Digits.mcpack')
OUT = os.path.join(HERE, 'out_ui'); shutil.rmtree(OUT, ignore_errors=True); os.makedirs(OUT)
res = []
def check(name, cond, extra=''):
    res.append((name, bool(cond))); print(('PASS ' if cond else 'FAIL ') + name + (('  -> ' + str(extra)[:200]) if (extra and not cond) else ''))

MOCK = """
(() => { const S = window.__mock = { chunks: [], total: 0, mode: 'ok' };
 window.AndroidBridge = {
  ping: () => JSON.stringify({sdk: 34, webview: '999.0-mock', model: 'MockPhone'}),
  beginSave: (name) => { S.name = name; S.chunks = []; S.total = 0; setTimeout(() => { if (S.mode === 'cancel') window.__onSaveReady(false, 'cancelado'); else window.__onSaveReady(true, ''); }, 30); },
  writeChunk: (b64) => { if (S.mode === 'diskfull' && S.chunks.length >= 2) return 'err:ENOSPC'; const bin = atob(b64); const u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); S.chunks.push(u); S.total += u.length; return 'ok'; },
  cancelSave: () => {},
  endSave: () => setTimeout(() => window.__onSaveDone({ ok: true, err: '', name: S.name, uri: 'content://mock/' + S.name, written: S.total + (S.mode === 'short' ? -1 : 0), onDisk: S.total }), 20)
 }; })();
"""
def mkpage(p, mobile=False, root=ROOT, mock=False, js=True, init=None):
    ctx = p.chromium.launch(args=['--no-sandbox']).new_context(viewport={'width': 390, 'height': 800}, has_touch=mobile, is_mobile=mobile, accept_downloads=True, java_script_enabled=js)
    pg = ctx.new_page(); pg.errs = []
    pg.on('pageerror', lambda e: pg.errs.append(str(e)))
    if mock: pg.add_init_script(MOCK)
    if init: pg.add_init_script(init)
    pg.goto('file://%s/www/index.html' % root); pg.wait_for_timeout(250); return pg
def act(pg, sel, mobile):
    (pg.tap if mobile else pg.click)(sel, force=True)
def txt(pg, sel): return pg.inner_text(sel).strip()
def import_(pg, f, mobile=False):
    pg.set_input_files('#file', f); pg.wait_for_function("document.getElementById('d_import').textContent.indexOf('analisando')<0", timeout=60000)
def run_flow(pg, f, n, mobile, save='download'):
    import_(pg, f, mobile); pg.fill('#frames', str(n)); act(pg, '#btnConfirm', mobile)
    ok_conf = ('confirmada: %d' % n) in txt(pg, '#countState')
    act(pg, '#btnGen', mobile)
    pg.wait_for_function("document.getElementById('msgGen').className.indexOf('ok')>=0 || document.getElementById('msgGen').className.indexOf('err')>=0", timeout=180000)
    gen_ok = 'ok' in pg.get_attribute('#msgGen', 'class').split()
    return ok_conf, gen_ok
def save_download(pg, n, tag, mobile):
    with pg.expect_download(timeout=30000) as d: act(pg, '#btnSave', mobile)
    path = os.path.join(OUT, '%s__%d.mcpack' % (tag, n)); d.value.save_as(path); return d.value.suggested_filename, path

with sync_playwright() as p:
    # ---- 1) fluxo completo: clique (desktop) e toque (celular), dois pacotes, 4 quantidades
    for mobile in (False, True):
        for tag, f in (('A1dig', A), ('B3dig', B)):
            for n in (79, 120, 151, 288):
                pg = mkpage(p, mobile)
                core_ok = pg.evaluate("typeof window.BetmcCore") == 'object'
                c, g = run_flow(pg, f, n, mobile)
                save_on = 'is-off' not in pg.get_attribute('#btnSave', 'class')
                bad = len(pg.query_selector_all('#checks li.bad')); total = len(pg.query_selector_all('#checks li'))
                fn, path = save_download(pg, n, ('tap_' if mobile else 'click_') + tag, mobile)
                z = zipfile.ZipFile(path); intact = z.testzip() is None
                check('%s %s N=%d: core+confirmar+gerar+validar+salvar' % ('toque' if mobile else 'clique', tag, n),
                      core_ok and c and g and save_on and bad == 0 and total >= 15 and intact and fn == 'Hoshino_Animation_%d_Frames%s.mcpack' % (n, '') or (fn.startswith('Hoshino_Animation_%d_Frames' % n) and core_ok and c and g and save_on and bad == 0 and intact),
                      (core_ok, c, g, save_on, bad, total, intact, fn, pg.errs))
                if mobile is False and n == 151 and tag == 'B3dig':
                    wcheck = pg.evaluate("document.documentElement.scrollWidth")
                pg.context.browser.close()
    # ---- 2) layout: sem transbordo horizontal com caminho longo
    pg = mkpage(p, True); import_(pg, B, True)
    sw = pg.evaluate("document.documentElement.scrollWidth"); iw = pg.evaluate("window.innerWidth")
    check('layout: página não excede a largura da tela após importar (%d <= %d)' % (sw, iw), sw <= iw)
    pg.context.browser.close()
    # ---- 3) mensagens/validação (nenhum botão fica mudo)
    pg = mkpage(p, True)
    act(pg, '#btnGen', True); check('GERAR sem importar -> mensagem visível', 'Importe primeiro' in txt(pg, '#msgGen'))
    act(pg, '#btnSave', True); check('SALVAR sem converter -> mensagem visível', 'Ainda não há conversão' in txt(pg, '#msgSave'))
    for raw, frag in (('', 'Digite a quantidade'), ('0', 'maior que zero'), ('abc', 'não é um número'), ('12,5', 'não é inteiro'), ('-3', 'não é um número'), ('999999', 'máxima')):
        pg.fill('#frames', raw); act(pg, '#btnConfirm', True)
        check('CONFIRMAR "%s" -> %s' % (raw, frag), frag in txt(pg, '#msgConfirm'), txt(pg, '#msgConfirm'))
    pg.fill('#frames', '151'); act(pg, '#btnConfirm', True)
    check('CONFIRMAR 151 -> mostra confirmação', 'Quantidade confirmada: 151' in txt(pg, '#countState') and '151' in txt(pg, '#d_count'))
    pg.fill('#frames', '152'); check('editar o campo invalida a confirmação', 'ainda não confirmada' in txt(pg, '#countState'))
    t = pg.evaluate("document.getElementById('d_taps').textContent"); check('painel conta toques (%s)' % t, t.startswith('9') or t.startswith('1') or int(t.split()[0]) >= 9)
    bad_zip = os.path.join(tempfile.gettempdir(), 'not_a_zip.mcpack'); open(bad_zip, 'wb').write(b'isto nao e um zip ' * 20)
    import_(pg, bad_zip, True); check('arquivo inválido -> erro claro na importação', 'Falha na importação' in txt(pg, '#msgImport') and 'ZIP' in txt(pg, '#msgImport'), txt(pg, '#msgImport'))
    check('último erro no painel', 'importação' in txt(pg, '#d_err'))
    pg.context.browser.close()
    # ---- 4) GERAR com valor digitado e não confirmado -> confirma automaticamente (nunca fica mudo)
    pg = mkpage(p, True); import_(pg, A, True); pg.fill('#frames', '31'); act(pg, '#btnGen', True)
    pg.wait_for_function("document.getElementById('msgGen').className.indexOf('ok')>=0", timeout=60000)
    check('GERAR sem confirmar -> auto-confirma e converte (N=31)', 'confirmada: 31' in txt(pg, '#countState'))
    pg.context.browser.close()
    # ---- 5) progresso real + UI não congela (1000 frames; pacote sintético grande)
    big = os.path.join(tempfile.gettempdir(), 'big_pack.mcpack')
    if not os.path.exists(big):
        zi = zipfile.ZipFile(B); zo = zipfile.ZipFile(big, 'w', zipfile.ZIP_STORED)
        for i in zi.infolist(): zo.writestr(i, zi.read(i.filename))
        d = 'Rebeca_Animation__FIXado120/subpacks/720/betmc_background/betmc_background_frame/ezgif-frame-%03d.png'
        rnd = os.urandom(300000)
        for k in range(2, 289): zo.writestr(d % k, rnd[k:] + rnd[:k])
        zo.close()
    for label, f, n in (('1000 frames (pacote de teste)', A, 1000), ('288 PNGs físicos ~%dMB -> 151' % (os.path.getsize(big) // 1048576), big, 151)):
        pg = mkpage(p, True)
        pg.evaluate("""() => { window.__lt = []; window.__vals = new Set(); new PerformanceObserver(l => l.getEntries().forEach(e => window.__lt.push(e.duration))).observe({entryTypes: ['longtask']});
          new MutationObserver(() => window.__vals.add(document.getElementById('progressText').textContent)).observe(document.getElementById('progressText'), {childList: true, characterData: true, subtree: true}); }""")
        import time; t0 = time.time(); c, g = run_flow(pg, f, n, True); dt = time.time() - t0
        vals = pg.evaluate("[...window.__vals]"); lt = pg.evaluate("window.__lt"); mx = max(lt) if lt else 0
        check('%s: converteu e validou em %.1fs; progresso mostrou %d valores distintos; maior tarefa longa %.0f ms' % (label, dt, len(vals), mx), c and g and len(vals) >= 5, (c, g, vals[:12]))
        check('%s: interface sem congelar (maior tarefa longa < 1000 ms)' % label, mx < 1000, mx)
        pg.context.browser.close()
    # ---- 6) ponte Android simulada: gravação, cancelamento, erro de disco, tamanho divergente
    ref = {}
    for mode in ('ok', 'cancel', 'diskfull', 'short'):
        pg = mkpage(p, True, mock=True); pg.evaluate("window.__mock.mode = %s" % json.dumps(mode))
        check('ponte [%s]: painel detecta a ponte' % mode, 'ativa' in txt(pg, '#d_bridge') and 'MockPhone' in txt(pg, '#d_bridge'), txt(pg, '#d_bridge'))
        c, g = run_flow(pg, B, 151, True); act(pg, '#btnSave', True)
        pg.wait_for_function("document.getElementById('msgSave').className.indexOf('ok')>=0 || document.getElementById('msgSave').className.indexOf('err')>=0 || document.getElementById('msgSave').className.indexOf('warn')>=0", timeout=60000)
        m = txt(pg, '#msgSave'); cls = pg.get_attribute('#msgSave', 'class')
        if mode == 'ok':
            b64 = pg.evaluate("(async()=>{const c=window.__mock.chunks;const b=new Blob(c);const r=await new Promise(res=>{const f=new FileReader();f.onload=()=>res(f.result);f.readAsDataURL(b)});return r.split(',')[1]})()")
            path = os.path.join(OUT, 'bridge__151.mcpack'); open(path, 'wb').write(base64.b64decode(b64))
            check('ponte [ok]: gravou e conferiu bytes (%s)' % m[:90], 'Gravado e conferido' in m and 'ok' in cls.split() and zipfile.ZipFile(path).testzip() is None and "100%" in txt(pg, '#saveText'), m)
        elif mode == 'cancel': check('ponte [cancel]: informa cancelamento', 'cancelado' in m and 'warn' in cls.split(), m)
        elif mode == 'diskfull': check('ponte [diskfull]: informa erro de gravação', 'ENOSPC' in m and 'err' in cls.split(), m)
        else: check('ponte [short]: detecta bytes gravados divergentes', 'Bytes gravados' in m and 'err' in cls.split(), m)
        pg.context.browser.close()
    # ---- 7) falhas de carregamento: o painel mostra a causa e os botões respondem
    tmp = tempfile.mkdtemp(); 
    for case in ('nocore', 'brokencore', 'noapp'):
        d = os.path.join(tmp, case); shutil.copytree(os.path.join(ROOT, 'www'), os.path.join(d, 'www'))
        if case == 'nocore': os.remove(os.path.join(d, 'www', 'core.js'))
        if case == 'brokencore': open(os.path.join(d, 'www', 'core.js'), 'w').write('(function(){ var x = ; })();')
        if case == 'noapp': os.remove(os.path.join(d, 'www', 'app.js'))
        pg = mkpage(p, True, root=d)
        js = txt(pg, '#d_js'); core = txt(pg, '#d_core'); err = txt(pg, '#d_err'); app = txt(pg, '#d_app')
        if case in ('nocore', 'brokencore'):
            act(pg, '#btnGen', True)
            check('falha [%s]: painel diz que o motor falhou e GERAR explica' % case, 'ativo' in js and (('core.js' in err) if case == 'nocore' else ('Script error' in err or 'script externo' in err or 'SyntaxError' in err)) and 'NÃO' in core and 'motor de conversão' in txt(pg, '#msgGen'), (js, core, err))
        else:
            check('falha [%s]: painel mostra que app.js não carregou' % case, 'ativo' in js and 'aguardando' in app and 'app.js' in err, (js, app, err))
        pg.context.browser.close()
    pg = mkpage(p, True, js=False)
    check('JavaScript desligado: painel estático avisa "NÃO EXECUTOU"', 'NÃO EXECUTOU' in txt(pg, '#d_js')); pg.context.browser.close()
    # ---- 8) navegador sem DecompressionStream (WebView antigo simulado)
    pg = mkpage(p, True, init="delete window.DecompressionStream;")
    check('sem DecompressionStream: painel lista o recurso ausente', 'DecompressionStream' in txt(pg, '#d_feat'), txt(pg, '#d_feat'))
    import_(pg, B, True); check('sem DecompressionStream: importação explica o requisito', 'requer Chrome/WebView 80' in txt(pg, '#msgImport'), txt(pg, '#msgImport'))
    pg.context.browser.close()

print('\n%d/%d verificações de interface OK' % (sum(1 for _, ok in res if ok), len(res)))
sys.exit(0 if all(ok for _, ok in res) else 1)
