// Testes da lógica de VÍDEO → MCPACK (Node >= 18):  node tests/video_tests.js
// O lado nativo (Kotlin) é SIMULADO aqui por um montador em JS que segue exatamente o mesmo contrato:
// descartar PNGs antigos, aplicar textos do plano, trocar ícone/estática, gravar N PNGs, gerar o resumo.
const fs = require('fs'), path = require('path'), zlib = require('zlib');
const C = require('../www/core.js');
const V = require('../www/video.js');
const BASE = path.join(__dirname, 'fixtures_video', 'Rebeca_Animation_CORRIGIDA.mcpack');
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log('  FALHOU:', m); } };

/* ---- PNG mínimo (RGB) com cor sólida, para frames sintéticos de qualquer tamanho */
const crcT = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = (b) => { let c = 0xffffffff; for (let i = 0; i < b.length; i++) c = crcT[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
function png(w, h, seed) {
  const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc32(td)); return Buffer.concat([l, td, c]); };
  const ih = Buffer.alloc(13); ih.writeUInt32BE(w, 0); ih.writeUInt32BE(h, 4); ih[8] = 8; ih[9] = 2;
  const row = Buffer.alloc(1 + w * 3); for (let x = 0; x < w; x++) { row[1 + x * 3] = seed & 255; row[2 + x * 3] = (seed >> 8) & 255; row[3 + x * 3] = x & 255; }
  const raw = Buffer.concat(Array.from({ length: h }, () => row));
  return Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), chunk('IHDR', ih), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}
/* ---- escritor de ZIP de teste */
function zipWrite(files) { // files: [{name, data(Buffer)}]
  const parts = [], cd = []; let off = 0;
  for (const f of files) {
    const nb = Buffer.from(f.name), c = crc32(f.data), d = zlib.deflateRawSync(f.data), useD = d.length < f.data.length, data = useD ? d : f.data;
    const h = Buffer.alloc(30); h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt16LE(useD ? 8 : 0, 8);
    h.writeUInt32LE(c, 14); h.writeUInt32LE(data.length, 18); h.writeUInt32LE(f.data.length, 22); h.writeUInt16LE(nb.length, 26);
    const e = Buffer.alloc(46); e.writeUInt32LE(0x02014b50, 0); e.writeUInt16LE(20, 4); e.writeUInt16LE(20, 6); e.writeUInt16LE(0x0800, 8); e.writeUInt16LE(useD ? 8 : 0, 10);
    e.writeUInt32LE(c, 16); e.writeUInt32LE(data.length, 20); e.writeUInt32LE(f.data.length, 24); e.writeUInt16LE(nb.length, 28); e.writeUInt32LE(off, 42);
    parts.push(h, nb, data); cd.push(Buffer.concat([e, nb])); off += 30 + nb.length + data.length;
  }
  const cdb = Buffer.concat(cd), end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(cdb.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...parts, cdb, end]);
}
/* ---- "Kotlin" simulado */
async function fakeNative(plan, frames, opts) {
  opts = opts || {};
  const baseBlob = new Blob([fs.readFileSync(BASE)]); const z = await C.openZip(baseBlob);
  const drop = new Set(plan.dropPaths), files = [];
  const gIcon = png(plan.iconSize[0], plan.iconSize[1], 7777), gStatic = png(plan.staticSize[0], plan.staticSize[1], 8888);
  const man = z.entries.find((e) => e.norm === plan.roles.manifest);
  const order = [man, ...z.entries.filter((e) => e !== man)];
  for (const e of order) {
    if (e.isDir) continue;
    if (drop.has(e.norm)) continue;
    if (e.norm === plan.iconPath) { files.push({ name: e.norm, data: gIcon }); continue; }
    if (e.norm === plan.staticPath) { files.push({ name: e.norm, data: gStatic }); continue; }
    if (plan.texts[e.norm] !== undefined) { files.push({ name: e.norm, data: Buffer.from(plan.texts[e.norm], 'utf8') }); continue; }
    files.push({ name: e.norm, data: Buffer.from(await C.extract(z, e)) });
  }
  frames.forEach((f, i) => files.push({ name: plan.framePaths[i], data: f }));
  if (opts.mutate) opts.mutate(files);
  const out = zipWrite(files);
  const oz = await C.openZip(new Blob([out]));
  const entries = [];
  for (const en of oz.entries) {
    if (en.isDir) continue;
    const u8 = Buffer.from(await C.extract(oz, en)); const crc = crc32(u8);
    const o = { p: en.norm, size: u8.length, crc, crcOk: crc === (en.crc >>> 0) };
    if (/\.png$/.test(en.norm)) { const d = V.ihdr(u8); o.png = { ok: !!d, w: d ? d[0] : 0, h: d ? d[1] : 0 }; }
    if (/\.json$/i.test(en.norm)) o.text = u8.toString('utf8');
    entries.push(o);
  }
  return { out, summary: { entries, gen: { iconCrc: crc32(gIcon), staticCrc: crc32(gStatic), frame1Crc: crc32(frames[0]) }, fileSize: out.length } };
}

(async () => {
  /* ===== cálculos puros ===== */
  ok(V.frameCount(12000, 24) === 288, '12 s × 24 = 288');
  ok(V.frameCount(30000, 24) === 288, 'vídeo de 30 s limitado a 12 s → 288');
  ok(V.frameCount(12000, 30) === 360 && V.frameCount(5000, 12) === 60 && V.frameCount(1000, 10) === 10, 'outros FPS');
  ok(V.frameCount(4125, 24) === 99, '4,125 s × 24 = 99');
  ok(V.frameCount(10, 24) === 1, 'vídeo muito curto: 1 frame real (t=0)');
  ok(V.frameCount(0, 24) === 0, 'duração 0 → 0 frames');
  ok(V.frameTimeUs(0, 24) === 0 && V.frameTimeUs(24, 24) === 1000000 && V.frameTimeUs(287, 24) === Math.round(287e6 / 24), 'instantes dos quadros');
  ok(Math.max(...Array.from({ length: 288 }, (_, k) => V.frameTimeUs(k, 24))) < 12e6, 'último instante < 12 s');
  const cc = (sw, sh) => V.centerCrop(sw, sh, 16, 9);
  ok(JSON.stringify(cc(1920, 1080)) === '[0,0,1920,1080]', 'crop 16:9 → sem corte');
  ok(JSON.stringify(cc(1080, 1920)) === '[0,656,1080,607]', 'crop vertical 1080×1920 → faixa central 1080×607: ' + cc(1080, 1920));
  ok(JSON.stringify(cc(1000, 1000)) === '[0,219,1000,562]', 'crop quadrado: ' + cc(1000, 1000));
  ok(JSON.stringify(cc(2560, 1080)) === '[320,0,1920,1080]', 'crop ultrawide: ' + cc(2560, 1080));
  for (const [w, h] of [[1080, 1920], [1000, 1000], [3840, 2160], [720, 1280], [641, 479], [101, 3333], [2560, 1080]]) {
    const [x, y, cw, ch] = cc(w, h); ok(x >= 0 && y >= 0 && x + cw <= w && y + ch <= h && Math.abs(cw / ch - 16 / 9) < 0.02 * (16 / 9) + 1 / ch, `crop dentro da imagem e ~16:9 (${w}×${h} → ${cw}×${ch})`);
  }
  ok(JSON.stringify(V.rotatedSize(1920, 1080, 90)) === '[1080,1920]' && JSON.stringify(V.rotatedSize(1920, 1080, 180)) === '[1920,1080]' && JSON.stringify(V.rotatedSize(1920, 1080, 270)) === '[1080,1920]', 'rotação troca largura/altura');
  ok(V.mcpackFileName('', 'Meu Vídeo.mp4') === 'Meu Vídeo.mcpack' && V.mcpackFileName('abc.mcpack', 'x.mp4') === 'abc.mcpack' && V.mcpackFileName('a/b:c', 'x') === 'abc.mcpack' && V.mcpackFileName('', '') === 'Animation.mcpack', 'nome do arquivo');
  ok(V.displayNameOf('', 'Clip_01.MOV') === 'Clip_01' && V.displayNameOf(' Meu Pack ', 'x') === 'Meu Pack', 'nome de exibição');

  /* ===== plano + montagem simulada + validação, vários N/FPS/resoluções ===== */
  const baseBlob = () => new Blob([fs.readFileSync(BASE)]);
  const cases = [[1, 24, 1280, 720], [10, 10, 640, 360], [60, 12, 960, 540], [120, 24, 1280, 720], [200, 25, 854, 480], [288, 24, 1280, 720], [360, 30, 1280, 720]];
  const keep = {};
  for (const [N, fps, w, h] of cases) {
    const plan = await V.buildPlan(C, baseBlob(), { N, fps, outW: w, outH: h, displayName: 'Teste ' + N, description: N % 2 ? 'Descrição X' : '' });
    ok(plan.framePaths.length === N && plan.framePaths[0].endsWith('ezgif-frame-001.png') && plan.framePaths[N - 1].endsWith('ezgif-frame-' + String(N).padStart(3, '0') + '.png'), `N=${N}: caminhos`);
    const frames = Array.from({ length: N }, (_, i) => png(w, h, i + 1));
    const { out, summary } = await fakeNative(plan, frames);
    const v = V.validatePackage(summary, plan);
    const bad = v.checks.filter((c) => !c.ok);
    console.log(`N=${String(N).padStart(3)} fps=${fps} ${w}×${h}: ${v.ok ? 'OK ' : 'ERRO'} (${v.checks.length} verificações)` + (bad.length ? ' -> ' + bad.map((b) => b.label + ': ' + b.detail).join(' | ') : ''));
    ok(v.ok, `N=${N} fps=${fps} validação`);
    ok(v.checks.length >= 13, 'quantidade de verificações');
    // independente do plano: o ZIP resultante tem exatamente N PNGs de frame
    const oz = await C.openZip(new Blob([out]));
    ok(oz.entries.filter((e) => /ezgif-frame-\d+\.png$/.test(e.norm)).length === N, `N=${N}: PNGs físicos = N`);
    const anim = JSON.parse(summary.entries.find((e) => e.p === plan.roles.anim).text);
    ok(anim['anim_' + N].next.endsWith('.anim_1') && !anim['frame_' + (N + 1)], `N=${N}: loop e sem frame extra`);
    ok(Math.abs(anim.anim_1.duration - 1 / fps) < 1e-12, `N=${N}: duração = 1/fps`);
    const cfg = JSON.parse(summary.entries.find((e) => e.p === plan.roles.configs[0]).text);
    ok(Math.abs(cfg.betmc_main_config.$betmc_frame_duration - 1 / fps) < 1e-12, `N=${N}: $betmc_frame_duration`);
    const mf = JSON.parse(summary.entries.find((e) => e.p === plan.roles.manifest).text);
    ok(mf.header.name === 'Teste ' + N && mf.header.uuid === '99328435-f33f-4806-8c3e-daa7dc42d508' && mf.modules[0].uuid === '0d0288fa-36a7-4a33-ba2f-0e5a45c1b2d6' && JSON.stringify(mf.header.version) === '[0,0,4]', `N=${N}: manifest`);
    ok(N % 2 ? mf.header.description === 'Descrição X' : mf.header.description.startsWith('TikTok'), `N=${N}: descrição só muda se informada`);
    keep[N] = { plan, frames, summary };
    if (N === 288) fs.writeFileSync(path.join(__dirname, 'out_video', 'video_288.mcpack'), out);
  }
  // 288/24: grade idêntica ao pacote-base (anim e frames, byte a byte nos JSONs)
  {
    const z = await C.openZip(baseBlob()); const bp = keep[288].plan;
    const bAnim = new TextDecoder().decode(await C.extract(z, z.entries.find((e) => e.norm === bp.roles.anim)));
    ok(bp.texts[bp.roles.anim] === bAnim, '288 @ 24 FPS: JSON de animação idêntico ao do pacote-base');
    const bBg = new TextDecoder().decode(await C.extract(z, z.entries.find((e) => e.norm === bp.roles.bg)));
    ok(bp.texts[bp.roles.bg] === bBg, '288 @ 24 FPS: JSON de controles idêntico ao do pacote-base');
  }

  /* ===== falhas que DEVEM ser detectadas (validação não pode ser decorativa) ===== */
  const { plan: P, frames: F } = keep[120];
  const run = async (mut, label, want) => {
    const { summary } = await fakeNative(P, F, { mutate: mut });
    const v = V.validatePackage(summary, P);
    ok(!v.ok, `deve reprovar: ${label}`);
    if (want) ok(v.checks.some((c) => !c.ok && want.test(c.label)), `reprova pela verificação certa (${label})`);
  };
  await run((f) => { f.splice(f.findIndex((x) => /ezgif-frame-050\.png$/.test(x.name)), 1); }, 'PNG faltando', /Numeração|referenciados|Quantidade/);
  await run((f) => { f.push({ name: P.framePaths[0].replace('-001', '-121'), data: png(1280, 720, 5) }); }, 'PNG sobrando', /Quantidade|Numeração/);
  await run((f) => { const i = f.findIndex((x) => x.name === P.iconPath); f[i] = { name: P.iconPath, data: Buffer.from('nao e png') }; }, 'ícone inválido', /pack_icon/);
  await run((f) => { const i = f.findIndex((x) => x.name === P.staticPath); f[i] = { name: P.staticPath, data: png(100, 100, 1) }; }, 'estática com dimensões erradas', /static/);
  await run((f) => { const i = f.findIndex((x) => x.name === P.roles.anim); const j = JSON.parse(f[i].data.toString()); j.anim_120.next = '@betmc_animation_288.anim_7'; f[i].data = Buffer.from(JSON.stringify(j)); }, 'loop quebrado', /Encadeamento/);
  await run((f) => { const i = f.findIndex((x) => x.name === P.roles.anim); const j = JSON.parse(f[i].data.toString()); j.anim_5.duration = 0.5; f[i].data = Buffer.from(JSON.stringify(j)); }, 'duração errada', /Duração/);
  await run((f) => { const i = f.findIndex((x) => x.name === P.roles.anim); f[i].data = Buffer.from('{ quebrado'); }, 'JSON inválido', /JSON/);
  await run((f) => { f.splice(f.findIndex((x) => /\/ui\/_ui_defs\.json$/.test(x.name)), 1); }, 'arquivo do pacote-base removido', /pacote-base removido/);
  await run((f) => { const i = f.findIndex((x) => x.name === P.roles.manifest); const j = JSON.parse(f[i].data.toString()); j.header.uuid = '11111111-1111-1111-1111-111111111111'; f[i].data = Buffer.from(JSON.stringify(j)); }, 'UUID alterado', /manifest/);
  await run((f) => { const i = f.findIndex((x) => x.name === P.framePaths[9]); f[i] = { name: P.framePaths[9], data: png(640, 360, 3) }; }, 'frame com resolução errada', /PNGs de frame/);
  { // CRC corrompido
    const { summary } = await fakeNative(P, F); summary.entries[3].crcOk = false;
    ok(!V.validatePackage(summary, P).ok, 'deve reprovar: CRC inválido');
  }
  // erros do plano
  let threw = false; try { await V.buildPlan(C, baseBlob(), { N: 0, fps: 24, outW: 1280, outH: 720, displayName: 'x' }); } catch (e) { threw = true; } ok(threw, 'N=0 rejeitado');
  threw = false; try { await V.buildPlan(C, new Blob([Buffer.from('lixo')]), { N: 10, fps: 24, outW: 1280, outH: 720, displayName: 'x' }); } catch (e) { threw = true; } ok(threw, 'pacote-base inválido rejeitado');

  console.log(`\n${pass} verificações OK, ${fail} falhas`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
