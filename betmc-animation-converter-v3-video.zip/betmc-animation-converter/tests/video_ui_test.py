"""Testes de INTERFACE da aba CONVERTER VÍDEO em Chromium (Playwright). Uso: python3 tests/video_ui_test.py
O lado nativo (Kotlin: MediaMetadataRetriever + ZIP) é SIMULADO: a ponte Android é um mock em JS e o "motor"
é um montador em Python que segue o mesmo contrato do VideoEngine.kt. Isto valida a interface, o plano e a
validação reais (video.js + core.js) — NÃO valida o Kotlin nem a decodificação de vídeo real."""
import base64, json, os, shutil, struct, sys, tempfile, zipfile, zlib
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
BASE = os.path.join(HERE, 'fixtures_video', 'Rebeca_Animation_CORRIGIDA.mcpack')
TMP = tempfile.mkdtemp(prefix='vidui_')
res = []
def check(name, cond, extra=''):
    res.append((name, bool(cond))); print(('PASS ' if cond else 'FAIL ') + name + (('  -> ' + str(extra)[:300]) if (extra and not cond) else ''))

_png_cache = {}
def png(w, h, seed=0):
    k = (w, h, seed)
    if k in _png_cache: return _png_cache[k]
    def chunk(t, d): return struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    row = b'\x00' + bytes([(seed * 40) & 255, 80, 160]) * w
    raw = row * h
    out = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(raw, 1)) + chunk(b'IEND', b'')
    _png_cache[k] = out; return out

STATE = {'mode': 'ok', 'out': None, 'size': 0, 'discarded': 0}

def py_build(plan_json):
    plan = json.loads(plan_json); mode = STATE['mode']
    out_path = os.path.join(TMP, 'out.mcpack'); STATE['out'] = out_path
    z = zipfile.ZipFile(BASE); drop = set(plan['dropPaths']); texts = plan['texts']
    fw, fh = plan['frameSize']; iw, ih = plan['iconSize']; sw, sh = plan['staticSize']
    icon, stat = png(iw, ih, 7), png(sw, sh, 8)
    infos = z.infolist(); man = plan['manifestPath']
    ordered = [i for i in infos if i.filename == man] + [i for i in infos if i.filename != man]
    with zipfile.ZipFile(out_path, 'w') as o:
        for i in ordered:
            n = i.filename
            if n.endswith('/'): o.writestr(n, b''); continue
            if n in drop: continue
            if n == plan['iconPath']: o.writestr(n, icon, zipfile.ZIP_STORED)
            elif n == plan['staticPath']: o.writestr(n, stat, zipfile.ZIP_STORED)
            elif n in texts: o.writestr(n, texts[n].encode('utf-8'), zipfile.ZIP_DEFLATED)
            else: o.writestr(n, z.read(n), zipfile.ZIP_DEFLATED)
        for k, p in enumerate(plan['framePaths']):
            if mode == 'missing' and k == 5: continue
            o.writestr(p, png(fw, fh, 1 if k == 0 else 2), zipfile.ZIP_STORED)
    STATE['size'] = os.path.getsize(out_path)
    entries = []
    with zipfile.ZipFile(out_path) as r:
        for i in r.infolist():
            if i.is_dir(): continue
            d = r.read(i.filename); crc = zlib.crc32(d) & 0xffffffff
            e = {'p': i.filename, 'size': len(d), 'crc': crc, 'crcOk': crc == i.CRC}
            if i.filename.endswith('.png'):
                ok = d[:8] == b'\x89PNG\r\n\x1a\n'; e['png'] = {'ok': ok, 'w': struct.unpack('>I', d[16:20])[0] if ok else 0, 'h': struct.unpack('>I', d[20:24])[0] if ok else 0}
            if i.filename.endswith('.json'): e['text'] = d.decode('utf-8')
            entries.append(e)
    gen = {'iconCrc': zlib.crc32(icon) & 0xffffffff, 'staticCrc': zlib.crc32(stat) & 0xffffffff, 'frame1Crc': zlib.crc32(png(fw, fh, 1)) & 0xffffffff}
    return json.dumps({'entries': entries, 'gen': gen, 'fileSize': STATE['size']})
def py_discard(): STATE['discarded'] += 1; return None

THUMB = base64.b64encode(base64.b64decode('/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA=')).decode() if False else 'AAAA'
MOCK = r"""
(() => { const S = window.__mk = { video: null, last: null, discard: 0, exported: null, size: 0, cancel: false, mode: 'ok' };
 const B64 = '%BASE64%'; const bin = atob(B64); const CH = 512 * 1024;
 window.AndroidBridge = {
  ping: () => JSON.stringify({sdk: 36, webview: 'mock', model: 'MockM34'}),
  hasVideoEngine: () => true,
  pickVideo: () => setTimeout(() => window.__onVideoPicked(S.video), 20),
  baseSize: () => bin.length, baseChunkBytes: () => CH,
  baseChunk: (i) => { const a = i * CH; if (a >= bin.length) return ''; return btoa(bin.slice(a, Math.min(bin.length, a + CH))); },
  startVideoBuild: (planJson) => {
    S.last = JSON.parse(planJson);
    if (S.mode === 'busy') return 'err:Já existe uma conversão em andamento.';
    S.cancel = false;
    setTimeout(async () => {
      for (let i = 1; i <= 4; i++) { if (S.cancel) { window.__onVideoCancelled(); return; } window.__onVideoProgress(i / 5, 'Extraindo e gravando frame ' + i + ' de ' + S.last.N); await new Promise(r => setTimeout(r, 15)); }
      if (S.mode === 'extract_fail') { window.__onVideoError('Falha ao decodificar o quadro 7 (instante 0.29 s). O codec deste vídeo pode não ser suportado.'); return; }
      if (S.mode === 'write_fail') { window.__onVideoError('No space left on device (ENOSPC)'); return; }
      if (S.mode === 'hold') { while (!S.cancel) await new Promise(r => setTimeout(r, 20)); window.__onVideoCancelled(); return; }
      const sum = await window.py_build(planJson); S.size = JSON.parse(sum).fileSize; window.__onVideoBuilt(sum);
    }, 30);
    return 'ok';
  },
  cancelVideo: () => { S.cancel = true; },
  discardVideoOutput: () => { S.discard++; window.py_discard(); },
  exportVideoPack: (name) => { S.exportName = name; setTimeout(() => { window.__onVideoExportProgress(0.5);
      if (S.mode === 'export_cancel') window.__onVideoExported({ok:false, err:'cancelado'});
      else if (S.mode === 'export_short') window.__onVideoExported({ok:true, name, written: S.size - 1, onDisk: S.size - 1, expected: S.size});
      else window.__onVideoExported({ok:true, name, written: S.size, onDisk: S.size, expected: S.size}); }, 30); }
 }; })();
"""
VID = lambda **k: dict({'ok': True, 'name': 'Meu Clipe 01.mp4', 'durationMs': 15000, 'width': 1920, 'height': 1080, 'rotation': 0, 'mime': 'video/mp4', 'thumb': THUMB}, **k)

def page_for(p, video=None, mobile=True, bridge=True):
    b = p.chromium.launch(args=['--no-sandbox']); ctx = b.new_context(viewport={'width': 390, 'height': 800}, has_touch=mobile, is_mobile=mobile)
    pg = ctx.new_page(); pg.errs = []; pg.on('pageerror', lambda e: pg.errs.append(str(e)))
    if bridge:
        pg.expose_function('py_build', py_build); pg.expose_function('py_discard', py_discard)
        pg.add_init_script(MOCK.replace('%BASE64%', BASE64))
        pg.add_init_script('window.__mk.video = %s;' % json.dumps(video or VID()))
    pg.goto('file://%s/www/index.html' % ROOT); pg.wait_for_timeout(300); return pg
BASE64 = base64.b64encode(open(BASE, 'rb').read()).decode()
tap = lambda pg, sel: pg.tap(sel, force=True)
def cls(pg, sel): return pg.get_attribute(sel, 'class') or ''
def wait_msg(pg, sel, t=120000):
    pg.wait_for_function("(s)=>{const c=document.querySelector(s).className;return c.indexOf('ok')>=0||c.indexOf('err')>=0}", arg=sel, timeout=t)
def pick(pg):
    tap(pg, '#tabVideo'); tap(pg, '#btnVPick'); pg.wait_for_function("document.getElementById('msgVPick').className.indexOf('ok')>=0", timeout=5000)
def verify_out(N, fps, name):
    z = zipfile.ZipFile(STATE['out']); assert z.testzip() is None
    fr = [n for n in z.namelist() if n.endswith('.png') and 'ezgif-frame-' in n]
    man = [n for n in z.namelist() if n.endswith('manifest.json')][0]
    m = json.loads(z.read(man)); anim = json.loads(z.read([n for n in z.namelist() if n.endswith('betmc_animation_288.json')][0]))
    return len(fr) == N and m['header']['name'] == name and anim['anim_%d' % N]['next'].endswith('anim_1') and abs(anim['anim_1']['duration'] - 1 / fps) < 1e-12

with sync_playwright() as p:
    # 1) abas: fluxo antigo continua visível por padrão; aba de vídeo mostra/oculta
    pg = page_for(p)
    check('padrão: cartões do fluxo MCPACK→MCPACK visíveis e vídeo oculto', pg.is_visible('#btnImport') and not pg.is_visible('#vSelect'))
    tap(pg, '#tabVideo'); check('aba vídeo: mostra seleção e oculta fluxo antigo', pg.is_visible('#btnVPick') and not pg.is_visible('#btnImport') and not pg.is_visible('#vConfig'))
    tap(pg, '#tabPack'); check('voltar à aba antiga restaura os cartões', pg.is_visible('#btnImport') and not pg.is_visible('#vSelect'))
    check('sem erros de JS na carga', not pg.errs, pg.errs)

    # 2) vídeo de 15 s (>12 s), 24 FPS, 1280×720: 288 frames, fluxo completo por toque
    STATE['mode'] = 'ok'; pg = page_for(p, VID(durationMs=15000))
    pick(pg)
    check('seleção mostra prévia, duração e resolução', pg.is_visible('#vThumb') and '15.00 s' in pg.inner_text('#vInfo') and '1920×1080' in pg.inner_text('#vInfo'), pg.inner_text('#vInfo'))
    check('nomes sugeridos a partir do vídeo', pg.input_value('#vFile') == 'Meu Clipe 01' and pg.input_value('#vName') == 'Meu Clipe 01')
    check('estimativa: 288 frames com corte em 12 s', '288 frames' in pg.inner_text('#vEstimate') and 'corte em 12 s' in pg.inner_text('#vEstimate'), pg.inner_text('#vEstimate'))
    check('padrões: 24 FPS e 1280×720', pg.input_value('#vFps') == '24' and pg.input_value('#vSize') == '1280x720')
    check('SALVAR começa desabilitado', 'is-off' in cls(pg, '#btnVSave'))
    pg.fill('#vFile', 'Minha_Animacao'); pg.fill('#vName', 'Minha Animação ✨'); pg.fill('#vDesc', 'Feito no BetMC')
    tap(pg, '#btnVStart'); wait_msg(pg, '#msgVStart')
    ok = 'ok' in cls(pg, '#msgVStart').split()
    check('conversão automática concluída sem etapas de confirmação', ok, pg.inner_text('#msgVStart'))
    check('barra em 100% e checklist com todas as verificações OK', pg.inner_text('#vProgText') == '100%' and len(pg.query_selector_all('#vChecks li')) >= 13 and not pg.query_selector_all('#vChecks li.bad'))
    check('BAIXAR MCPACK PRONTO liberado', 'is-off' not in cls(pg, '#btnVSave'))
    plan = pg.evaluate('window.__mk.last')
    check('plano nativo: 288 frames, 24 FPS, 1280×720, 12 s máx., nome do arquivo', plan['N'] == 288 and plan['fps'] == 24 and plan['frameSize'] == [1280, 720] and plan['maxSeconds'] == 12 and plan['outName'] == 'Minha_Animacao.mcpack', plan['outName'])
    check('saída montada: 288 PNGs, manifest.header.name, loop, duração', verify_out(288, 24, 'Minha Animação ✨'))
    m = json.loads(zipfile.ZipFile(STATE['out']).read([n for n in zipfile.ZipFile(STATE['out']).namelist() if n.endswith('manifest.json')][0]))
    check('descrição informada aplicada; UUIDs intactos', m['header']['description'] == 'Feito no BetMC' and m['header']['uuid'] == '99328435-f33f-4806-8c3e-daa7dc42d508' and m['modules'][0]['uuid'] == '0d0288fa-36a7-4a33-ba2f-0e5a45c1b2d6')
    tap(pg, '#btnVSave'); pg.wait_for_function("document.getElementById('msgVSave').className.indexOf('ok')>=0", timeout=5000)
    check('exportação usa o nome escolhido e confere bytes', pg.evaluate('window.__mk.exportName') == 'Minha_Animacao.mcpack' and 'Salvo' in pg.inner_text('#msgVSave'), pg.inner_text('#msgVSave'))
    check('sem erros de JS no fluxo', not pg.errs, pg.errs)

    # 3) outros FPS/resoluções e vídeo curto
    for dur, fps, size, N in ((5000, '12', '960x540', 60), (12000, '30', '640x360', 360), (800, '10', '854x480', 8)):
        pg = page_for(p, VID(durationMs=dur, width=1080, height=1920, rotation=90)); pick(pg)
        pg.select_option('#vFps', fps); pg.select_option('#vSize', size)
        tap(pg, '#btnVStart'); wait_msg(pg, '#msgVStart')
        pl = pg.evaluate('window.__mk.last')
        check('dur=%dms fps=%s %s → %d frames, saída válida' % (dur, fps, size, N), 'ok' in cls(pg, '#msgVStart').split() and pl['N'] == N and verify_out(N, int(fps), 'Meu Clipe 01'), pg.inner_text('#msgVStart'))
    pg = page_for(p, VID(durationMs=15000, width=1080, height=1920, rotation=90)); pick(pg)
    check('vídeo vertical girado: resolução exibida após a rotação (1920×1080)', '1920×1080' in pg.inner_text('#vInfo') and 'girado 90' in pg.inner_text('#vInfo'), pg.inner_text('#vInfo'))

    # 4) falhas
    for mode, text in (('extract_fail', 'Falha ao decodificar'), ('write_fail', 'No space left')):
        STATE['mode'] = mode; pg = page_for(p); pg.evaluate("window.__mk.mode='%s'" % mode); pick(pg)
        tap(pg, '#btnVStart'); wait_msg(pg, '#msgVStart')
        check('falha (%s): mensagem específica, sem exportação' % mode, text in pg.inner_text('#msgVStart') and 'is-off' in cls(pg, '#btnVSave'), pg.inner_text('#msgVStart'))
        check('falha (%s): botão de conversão volta a funcionar' % mode, 'is-off' not in cls(pg, '#btnVStart'))
    STATE['mode'] = 'missing'; pg = page_for(p); pick(pg); tap(pg, '#btnVStart'); wait_msg(pg, '#msgVStart')
    check('validação reprova PNG faltando: exportação interrompida, erro específico, arquivo descartado',
          'err' in cls(pg, '#msgVStart').split() and 'Validação falhou' in pg.inner_text('#msgVStart') and 'is-off' in cls(pg, '#btnVSave') and pg.evaluate('window.__mk.discard') == 1 and len(pg.query_selector_all('#vChecks li.bad')) >= 1, pg.inner_text('#msgVStart'))
    STATE['mode'] = 'ok'
    pg = page_for(p); pg.evaluate("window.__mk.mode='hold'"); pick(pg); tap(pg, '#btnVStart'); pg.wait_for_selector('#btnVCancel', state='visible', timeout=5000)
    check('durante a conversão: CANCELAR visível e campos travados', pg.is_disabled('#vFps') and pg.is_visible('#btnVCancel'))
    tap(pg, '#btnVCancel'); pg.wait_for_function("document.getElementById('msgVStart').textContent.indexOf('cancelada')>=0", timeout=5000)
    check('cancelamento: sem arquivo, interface liberada', not pg.is_visible('#btnVCancel') and not pg.is_disabled('#vFps') and 'is-off' in cls(pg, '#btnVSave'))
    pg = page_for(p); pg.evaluate("window.__mk.mode='export_cancel'"); pick(pg); tap(pg, '#btnVStart'); wait_msg(pg, '#msgVStart'); tap(pg, '#btnVSave'); pg.wait_for_function("document.getElementById('msgVSave').textContent.indexOf('cancelado')>=0", timeout=5000)
    check('salvar cancelado: aviso e novo toque permitido', 'is-off' not in cls(pg, '#btnVSave'))
    pg = page_for(p); pg.evaluate("window.__mk.mode='export_short'"); pick(pg); tap(pg, '#btnVStart'); wait_msg(pg, '#msgVStart'); tap(pg, '#btnVSave'); pg.wait_for_function("document.getElementById('msgVSave').className.indexOf('err')>=0", timeout=5000)
    check('bytes gravados divergentes → erro (não afirma sucesso)', 'divergente' in pg.inner_text('#msgVSave'))
    pg = page_for(p); pick(pg); pg.evaluate("window.__mk.mode='busy'"); tap(pg, '#btnVStart'); wait_msg(pg, '#msgVStart', 20000)
    check('nativo recusa início: erro mostrado', 'Já existe' in pg.inner_text('#msgVStart'))
    pg = page_for(p, {'ok': False, 'err': 'Não foi possível ler a duração do vídeo.'}); tap(pg, '#tabVideo'); tap(pg, '#btnVPick'); pg.wait_for_timeout(400)
    check('falha ao ler o vídeo: erro específico e configuração não aparece', 'duração' in pg.inner_text('#msgVPick') and not pg.is_visible('#vConfig'))

    # 5) navegador sem ponte
    pg = page_for(p, bridge=False); tap(pg, '#tabVideo'); tap(pg, '#btnVPick')
    check('sem ponte Android: avisa que é só no app, sem fingir', 'aplicativo' in pg.inner_text('#msgVPick') and not pg.query_selector_all('#vThumb:not([hidden])'))
    # 6) fluxo antigo ainda funciona
    pg = page_for(p, mobile=False)
    pg.set_input_files('#file', BASE); pg.wait_for_function("document.getElementById('d_import').textContent.indexOf('analisando')<0", timeout=60000)
    pg.fill('#frames', '120'); pg.click('#btnConfirm'); pg.click('#btnGen')
    pg.wait_for_function("document.getElementById('msgGen').className.indexOf('ok')>=0 || document.getElementById('msgGen').className.indexOf('err')>=0", timeout=120000)
    check('MCPACK → MCPACK continua funcionando com os novos scripts carregados', 'ok' in cls(pg, '#msgGen').split() and 'is-off' not in cls(pg, '#btnSave'), pg.inner_text('#msgGen'))

fails = [n for n, ok in res if not ok]
print('\n%d/%d OK' % (len(res) - len(fails), len(res))); shutil.rmtree(TMP, ignore_errors=True)
sys.exit(1 if fails else 0)
