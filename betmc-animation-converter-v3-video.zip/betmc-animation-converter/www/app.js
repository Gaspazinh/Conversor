(function () {
  'use strict';
  var Diag = window.BetmcDiag || { set: function () {}, log: function () {}, error: function () {}, tap: function () {} };
  var $ = function (id) { return document.getElementById(id); };
  var C = window.BetmcCore;
  var st = { file: null, info: null, result: null, count: null, busy: false, saving: false };
  var tick = function () { return new Promise(function (r) { setTimeout(r, 0); }); };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var fmtMB = function (n) { return (n / 1048576).toFixed(2) + ' MB'; };

  /* ---------- feedback visível junto de cada botão ---------- */
  function say(id, text, kind) { var e = $(id); e.textContent = text || ''; e.className = 'msg' + (kind ? ' ' + kind : ''); }
  function off(id, isOff) { var b = $(id); b.classList.toggle('is-off', !!isOff); b.setAttribute('aria-disabled', isOff ? 'true' : 'false'); }
  function flash(id) { var c = $(id).closest('.card'); if (!c) return; c.classList.remove('flash'); void c.offsetWidth; c.classList.add('flash'); }
  function showWarns(list) { $('warns').hidden = !list.length; $('warns').innerHTML = list.map(function (w) { return '<p>⚠ ' + esc(w) + '</p>'; }).join(''); }

  /* ---------- barras de progresso (percentual + etapa) ---------- */
  function bar(prefix, frac, stage) {
    var pct = Math.round(Math.max(0, Math.min(1, frac)) * 100);
    var w = $(prefix === 'g' ? 'barWrap' : 'saveBarWrap'), b = $(prefix === 'g' ? 'bar' : 'saveBar');
    b.style.width = pct + '%'; w.setAttribute('aria-valuenow', String(pct));
    $(prefix === 'g' ? 'progressText' : 'saveText').textContent = pct + '%';
    if (prefix === 'g' && stage) $('stage').textContent = stage.toUpperCase();
    return pct;
  }

  function resetResult() {
    st.result = null; off('btnSave', true);
    $('checks').innerHTML = ''; showWarns([]); say('msgGen', ''); say('msgSave', ''); $('saveInfo').textContent = '';
    bar('g', 0, 'PROGRESSO'); bar('s', 0); $('barWrap').classList.remove('err');
    Diag.set('conv', 'parada'); Diag.set('save', 'parado');
  }

  /* ---------- se o motor não carregou: cada botão explica o problema ---------- */
  if (!C) {
    Diag.set('core', '✖ BetmcCore NÃO existe (core.js não executou)', 'bad');
    Diag.error('window.BetmcCore ausente: core.js não foi carregado/executado');
    var msg = 'O motor de conversão (core.js) não carregou. Veja o painel DIAGNÓSTICO acima (Último erro / Recursos).';
    ['btnConfirm', 'btnGen', 'btnSave'].forEach(function (id) {
      off(id, true);
      $(id).addEventListener('click', function () { Diag.tap(id + ' (motor ausente)'); say(id === 'btnConfirm' ? 'msgConfirm' : id === 'btnGen' ? 'msgGen' : 'msgSave', msg, 'err'); });
    });
    $('file').addEventListener('change', function () { say('msgImport', msg, 'err'); });
    window.__betmcAppReady = false; Diag.set('app', '✖ interface sem motor', 'bad');
    return;
  }
  Diag.set('core', '✔ BetmcCore carregado (' + Object.keys(C).length + ' funções)', 'ok');
  var f = C.features();
  Diag.log('features: ' + JSON.stringify(f));

  /* ---------- validação da quantidade, com o motivo ---------- */
  function parseCount(raw) {
    var s = String(raw == null ? '' : raw).trim();
    if (!s) return { err: 'Digite a quantidade de frames (ex.: 151).' };
    if (/[.,]/.test(s) && /^\d+[.,]\d+$/.test(s)) return { err: '"' + s + '" não é inteiro. Use um número inteiro, sem vírgula ou ponto.' };
    if (!/^\d+$/.test(s)) return { err: '"' + s + '" não é um número. Use apenas dígitos (0–9).' };
    var n = parseInt(s, 10);
    if (n < 1) return { err: 'A quantidade deve ser maior que zero.' };
    if (n > 100000) return { err: 'Quantidade máxima: 100000 frames.' };
    return { n: n };
  }
  function renderCount() {
    var el = $('countState');
    if (st.count) { el.textContent = '✓ Quantidade confirmada: ' + st.count + ' frames.'; el.classList.add('confirmed'); Diag.set('count', st.count + ' frames', 'ok'); }
    else { el.textContent = 'Quantidade ainda não confirmada.'; el.classList.remove('confirmed'); Diag.set('count', 'nenhuma'); }
  }

  /* ---------- ETAPA 1: importar e analisar ---------- */
  $('btnImport').addEventListener('click', function () { Diag.tap('IMPORTAR TEXTURA'); $('file').value = ''; });
  $('file').addEventListener('change', async function () {
    var file = $('file').files && $('file').files[0];
    if (!file) { Diag.log('seletor fechado sem arquivo'); say('msgImport', 'Nenhum arquivo selecionado.', 'warn'); return; }
    Diag.log('arquivo escolhido: ' + file.name + ' (' + file.size + ' bytes)');
    resetResult(); st.info = null; st.file = file;
    $('fileName').textContent = file.name + ' (' + fmtMB(file.size) + ')'; $('analysis').hidden = true;
    Diag.set('import', 'analisando ' + file.name + '…', 'warn'); say('msgImport', 'Analisando o pacote…', 'info');
    try {
      await tick();
      var info = await C.analyze(file, function (p) { bar('g', p, 'Analisando'); });
      st.info = info;
      $('analysis').innerHTML = [
        'Animação: <b>' + esc(info.anim.path) + '</b>',
        'Controles: <b>' + esc(info.bg.path) + '</b>',
        'Frames atuais: <b>' + info.n + '</b> · namespace <b>' + esc(info.ns) + '</b>',
        'Nomenclatura atual: <b>' + esc(info.widths.join(' / ')) + '</b> → saída com 3 dígitos',
        'Duração por frame: <b>' + info.duration.toFixed(7) + ' s</b> (preservada)',
        'Grade de offsets: <b>' + info.grid.cols + ' colunas, passo ' + info.grid.dx + '%</b>',
        'PNGs de frame no pacote: <b>' + info.physical.length + '</b> de ' + info.n
      ].join('<br>');
      $('analysis').hidden = false; showWarns(info.warnings);
      bar('g', 1, 'Análise concluída');
      Diag.set('import', '✔ ' + file.name + ' · ' + info.n + ' frames', 'ok');
      say('msgImport', '✔ Pacote reconhecido (' + info.n + ' frames). Agora digite e confirme a quantidade.', 'ok');
    } catch (e) {
      st.info = null; $('analysis').hidden = true; bar('g', 0, 'PROGRESSO');
      Diag.set('import', '✖ falhou', 'bad'); Diag.error('importação: ' + e.message);
      say('msgImport', 'Falha na importação: ' + e.message, 'err');
    }
  });

  /* ---------- ETAPA 2: confirmar quantidade ---------- */
  function confirmCount(auto) {
    var r = parseCount($('frames').value);
    if (r.err) { st.count = null; renderCount(); say('msgConfirm', r.err, 'err'); $('frames').focus(); return null; }
    st.count = r.n; renderCount();
    say('msgConfirm', (auto ? 'Quantidade confirmada automaticamente: ' : '✔ Aplicado: ') + r.n + ' frames.' + (st.info ? '' : ' (importe um pacote para continuar)'), st.info ? 'ok' : 'warn');
    return r.n;
  }
  $('btnConfirm').addEventListener('click', function () { Diag.tap('CONFIRMAR FRAMES'); if (st.busy) { say('msgConfirm', 'Aguarde: conversão em andamento.', 'warn'); return; } confirmCount(false); });
  $('frames').addEventListener('input', function () { if (st.count !== null) { st.count = null; renderCount(); say('msgConfirm', 'Valor alterado: confirme de novo.', 'warn'); } resetResult(); });
  $('frames').addEventListener('keydown', function (ev) { if (ev.key === 'Enter') { ev.preventDefault(); $('btnConfirm').click(); } });

  /* ---------- ETAPAS 3 e 4: gerar + validar ---------- */
  $('btnGen').addEventListener('click', async function () {
    Diag.tap('GERAR');
    if (st.busy) { say('msgGen', 'Conversão já em andamento…', 'warn'); return; }
    if (!st.file || !st.info) { say('msgGen', 'Importe primeiro um pacote .mcpack/.zip válido (botão IMPORTAR TEXTURA).', 'err'); flash('btnImport'); return; }
    var n = (st.count && parseCount($('frames').value).n === st.count) ? st.count : confirmCount(true);
    if (!n) { say('msgGen', 'Corrija a quantidade de frames antes de gerar.', 'err'); flash('btnConfirm'); return; }
    st.busy = true; resetResult(); $('btnGen').classList.add('working');
    say('msgGen', 'Convertendo para ' + n + ' frames…', 'info');
    var t0 = Date.now();
    try {
      Diag.set('conv', 'convertendo 0%', 'warn'); bar('g', 0.01, 'Convertendo'); await tick();
      var r = await C.convert(st.info, n, function (fr, m) { var p = bar('g', fr * 0.80, m || 'Convertendo'); Diag.set('conv', 'convertendo ' + p + '%', 'warn'); });
      Diag.log('convert concluído: ' + r.blob.size + ' bytes'); bar('g', 0.82, 'Validando'); await tick();
      var v = await C.validate(r.blob, n, st.info, r, function (fr) { var p = bar('g', 0.82 + fr * 0.18, 'Validando'); Diag.set('conv', 'validando ' + p + '%', 'warn'); });
      $('checks').innerHTML = v.checks.map(function (c) { return '<li class="' + (c.level === 'ok' ? '' : c.level === 'warn' ? 'warn' : 'bad') + '">' + esc(c.label) + (c.detail ? '<small>' + esc(c.detail) + '</small>' : '') + '</li>'; }).join('');
      showWarns(r.warnings);
      if (v.ok) {
        st.result = { blob: r.blob, N: n, name: C.suggestName(st.file.name, n) };
        bar('g', 1, 'Concluído'); off('btnSave', false);
        var secs = ((Date.now() - t0) / 1000).toFixed(1);
        say('msgGen', '✔ Conversão concluída e validada em ' + secs + ' s (' + v.checks.length + ' verificações). Toque em SALVAR TEXTURA.', 'ok');
        $('saveInfo').textContent = st.result.name + ' · ' + fmtMB(r.blob.size);
        Diag.set('conv', '✔ validado (' + v.checks.length + ' verificações)', 'ok'); flash('btnSave');
      } else {
        bar('g', 1, 'Validação falhou'); $('barWrap').classList.add('err');
        var bad = v.checks.filter(function (c) { return !c.ok; }).map(function (c) { return c.label; });
        say('msgGen', '✖ Validação falhou — salvamento bloqueado: ' + bad.join('; '), 'err');
        Diag.set('conv', '✖ validação falhou', 'bad'); Diag.error('validação: ' + bad.join('; '));
      }
    } catch (e) {
      $('barWrap').classList.add('err');
      say('msgGen', '✖ Erro durante a conversão: ' + e.message + ' — toque em GERAR para tentar novamente.', 'err');
      Diag.set('conv', '✖ erro', 'bad'); Diag.error('conversão: ' + e.message);
    } finally { st.busy = false; $('btnGen').classList.remove('working'); }
  });

  /* ---------- ETAPA 5: salvar ---------- */
  function blobToB64(blob) {
    return new Promise(function (res, rej) {
      var fr = new FileReader();
      fr.onload = function () { res(String(fr.result).split(',')[1] || ''); };
      fr.onerror = function () { rej(fr.error || new Error('Falha ao ler bloco')); };
      fr.readAsDataURL(blob);
    });
  }
  function saveViaBridge(blob, name) {
    var B = window.AndroidBridge;
    return new Promise(function (resolve, reject) {
      var done = false;
      window.__onSaveDone = function (info) {
        if (done) return; done = true;
        try { if (typeof info === 'string') info = JSON.parse(info); } catch (e) { reject(new Error('Resposta inválida do Android.')); return; }
        if (!info.ok) { reject(new Error('Android: ' + (info.err || 'falha ao fechar o arquivo'))); return; }
        if (info.written !== blob.size) { reject(new Error('Bytes gravados (' + info.written + ') ≠ esperado (' + blob.size + ').')); return; }
        if (info.onDisk >= 0 && info.onDisk !== blob.size) { reject(new Error('Tamanho no disco (' + info.onDisk + ') ≠ esperado (' + blob.size + ').')); return; }
        resolve(info);
      };
      window.__onSaveReady = async function (ok, why) {
        if (!ok) { done = true; reject(new Error(why === 'cancelado' ? 'Salvamento cancelado pelo usuário.' : 'Android não abriu o destino: ' + why)); return; }
        try {
          var CH = 512 * 1024;
          for (var o = 0; o < blob.size; o += CH) {
            var r = B.writeChunk(await blobToB64(blob.slice(o, o + CH)));
            if (r !== 'ok') throw new Error('Falha ao gravar: ' + r);
            var p = bar('s', Math.min(o + CH, blob.size) / blob.size); Diag.set('save', 'gravando ' + p + '%', 'warn');
            if ((o / CH) % 4 === 0) await tick();
          }
          B.endSave();
        } catch (e) { try { B.cancelSave(); } catch (x) {} if (!done) { done = true; reject(e); } }
      };
      Diag.log('bridge.beginSave(' + name + ')'); B.beginSave(name);
    });
  }
  $('btnSave').addEventListener('click', async function () {
    Diag.tap('SALVAR TEXTURA');
    if (st.saving) { say('msgSave', 'Salvamento em andamento…', 'warn'); return; }
    if (!st.result) { say('msgSave', 'Ainda não há conversão validada. Importe, confirme a quantidade e toque em GERAR.', 'err'); flash('btnGen'); return; }
    var blob = st.result.blob, name = st.result.name;
    st.saving = true; $('btnSave').classList.add('working'); bar('s', 0);
    say('msgSave', 'Salvando ' + name + '…', 'info'); Diag.set('save', 'iniciando…', 'warn');
    try {
      if (window.AndroidBridge && window.AndroidBridge.beginSave) {
        var info = await saveViaBridge(blob, name); bar('s', 1);
        say('msgSave', '✔ Gravado e conferido: ' + (info.name || name) + ' — ' + info.written + ' bytes (no disco: ' + (info.onDisk >= 0 ? info.onDisk : 'não verificado') + ').', 'ok');
        $('saveInfo').textContent = 'Destino: ' + (info.uri || '(escolhido no seletor)');
        Diag.set('save', '✔ ' + info.written + ' bytes gravados', 'ok');
      } else {
        var url = URL.createObjectURL(blob), a = document.createElement('a');
        a.href = url; a.download = name; a.style.display = 'none'; document.body.appendChild(a); a.click();
        setTimeout(function () { a.remove(); URL.revokeObjectURL(url); }, 60000); bar('s', 1);
        say('msgSave', '✔ Download iniciado pelo navegador: ' + name + ' (' + fmtMB(blob.size) + '). Procure na pasta Downloads.', 'ok');
        Diag.set('save', '✔ download iniciado (navegador)', 'ok');
      }
    } catch (e) {
      var cancelled = /cancelado/.test(e.message);
      say('msgSave', (cancelled ? '⚠ ' : '✖ Erro ao salvar: ') + e.message + ' — toque em SALVAR TEXTURA para tentar de novo.', cancelled ? 'warn' : 'err');
      Diag.set('save', cancelled ? 'cancelado' : '✖ erro', cancelled ? 'warn' : 'bad'); if (!cancelled) Diag.error('salvamento: ' + e.message);
    } finally { st.saving = false; $('btnSave').classList.remove('working'); }
  });

  /* ---------- ponte Android ---------- */
  try {
    if (window.AndroidBridge && window.AndroidBridge.ping) { var pi = JSON.parse(window.AndroidBridge.ping()); Diag.set('bridge', '✔ ativa · Android SDK ' + pi.sdk + ' · WebView ' + pi.webview + ' · ' + pi.model, 'ok'); }
    else Diag.set('bridge', 'ausente (modo navegador: salvar = download)', 'warn');
  } catch (e) { Diag.set('bridge', '✖ erro na ponte: ' + e.message, 'bad'); Diag.error('ponte: ' + e.message); }

  renderCount(); off('btnSave', true);
  window.__betmcAppReady = true; Diag.set('app', '✔ botões ligados (handlers registrados)', 'ok'); Diag.log('app.js pronto');
})();
