/*
 * BetMC — VÍDEO → MCPACK · interface (aba CONVERTER VÍDEO).
 * Não altera o fluxo MCPACK → MCPACK: só mostra/oculta cartões. Lógica em video.js; decodificação/ZIP em VideoEngine.kt.
 */
(function () {
  'use strict';
  var Diag = window.BetmcDiag || { set: function () {}, log: function () {}, error: function () {}, tap: function () {} };
  var $ = function (id) { return document.getElementById(id); };
  var C = window.BetmcCore, V = window.BetmcVideo, B = window.AndroidBridge;
  if (!$('tabVideo')) return;
  var hasNative = !!(B && B.pickVideo && B.startVideoBuild && B.baseSize);
  var st = { cancelReq: false, tab: 'pack', video: null, busy: false, saving: false, built: false, plan: null, summary: null, outName: '', touched: { file: false, name: false } };
  var tick = function () { return new Promise(function (r) { setTimeout(r, 0); }); };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var fmtMB = function (n) { return (n / 1048576).toFixed(1) + ' MB'; };
  function say(id, text, kind) { var e = $(id); e.textContent = text || ''; e.className = 'msg' + (kind ? ' ' + kind : ''); }
  function off(id, isOff) { var b = $(id); b.classList.toggle('is-off', !!isOff); b.setAttribute('aria-disabled', isOff ? 'true' : 'false'); }
  function fmtDur(ms) { var s = ms / 1000, m = Math.floor(s / 60); return (m ? m + ' min ' : '') + (s - m * 60).toFixed(2) + ' s'; }

  /* ---------- abas ---------- */
  var packCards = [].slice.call(document.querySelectorAll('main > section.card')).filter(function (c) { return !c.classList.contains('diag') && !c.classList.contains('vid'); });
  function render() {
    var v = st.tab === 'video';
    packCards.forEach(function (c) { c.hidden = v; });
    $('tabPack').classList.toggle('on', !v); $('tabVideo').classList.toggle('on', v);
    $('vSelect').hidden = !v;
    $('vConfig').hidden = !(v && st.video);
    $('vRun').hidden = !(v && st.video);
    $('vResult').hidden = !(v && st.video);
  }
  $('tabPack').addEventListener('click', function () { Diag.tap('aba MCPACK → MCPACK'); st.tab = 'pack'; render(); });
  $('tabVideo').addEventListener('click', function () {
    Diag.tap('aba CONVERTER VÍDEO'); st.tab = 'video'; render();
    if (!hasNative) say('msgVPick', 'Esta função usa o decodificador de vídeo do Android e só está disponível no aplicativo (APK). No navegador, use a aba MCPACK → MCPACK.', 'warn');
  });

  /* ---------- opções ---------- */
  V.FPS_CHOICES.forEach(function (f) { var o = document.createElement('option'); o.value = String(f); o.textContent = f + ' FPS' + (f === V.DEFAULTS.fps ? ' (padrão)' : ''); if (f === V.DEFAULTS.fps) o.selected = true; $('vFps').appendChild(o); });
  V.SIZE_CHOICES.forEach(function (s) { var o = document.createElement('option'); o.value = s[0] + 'x' + s[1]; o.textContent = s[0] + '×' + s[1] + (s[0] === V.DEFAULTS.outW ? ' (padrão)' : ''); if (s[0] === V.DEFAULTS.outW) o.selected = true; $('vSize').appendChild(o); });
  function cfg() { var wh = $('vSize').value.split('x').map(Number); return { fps: +$('vFps').value, w: wh[0], h: wh[1] }; }
  function updateEstimate() {
    if (!st.video) return;
    var c = cfg(), n = V.frameCount(st.video.durationMs, c.fps), used = Math.min(st.video.durationMs / 1000, V.MAX_SECONDS);
    var mb = (n * c.w * c.h * 3 * 0.5) / 1048576;
    $('vEstimate').textContent = n + ' frames · ' + used.toFixed(2) + ' s usados' + (st.video.durationMs / 1000 > V.MAX_SECONDS ? ' (corte em 12 s)' : '') + ' · ' + c.w + '×' + c.h + ' · pacote estimado em até ~' + Math.round(mb) + ' MB';
  }
  $('vFps').addEventListener('change', updateEstimate); $('vSize').addEventListener('change', updateEstimate);
  $('vFile').addEventListener('input', function () { st.touched.file = true; });
  $('vName').addEventListener('input', function () { st.touched.name = true; });

  /* ---------- 1) seleção ---------- */
  $('btnVPick').addEventListener('click', function () {
    Diag.tap('SELECIONAR VÍDEO');
    if (st.busy) { say('msgVPick', 'Aguarde: conversão em andamento.', 'warn'); return; }
    if (!hasNative) { say('msgVPick', 'Disponível apenas no aplicativo Android (precisa do decodificador nativo).', 'err'); return; }
    say('msgVPick', 'Abrindo o seletor de vídeos…', 'warn'); B.pickVideo();
  });
  window.__onVideoPicked = function (info) {
    if (typeof info === 'string') { try { info = JSON.parse(info); } catch (e) { info = { ok: false, err: 'resposta inválida' }; } }
    if (!info.ok) { say('msgVPick', info.err === 'cancelado' ? 'Seleção cancelada.' : '✖ ' + info.err, info.err === 'cancelado' ? 'warn' : 'err'); if (info.err !== 'cancelado') Diag.error('vídeo: ' + info.err); return; }
    st.video = info; st.built = false; resetRun();
    var rs = V.rotatedSize(info.width, info.height, info.rotation || 0);
    $('vThumb').src = 'data:image/jpeg;base64,' + info.thumb; $('vThumb').hidden = false;
    $('vInfo').hidden = false;
    $('vInfo').innerHTML = '<b>Arquivo:</b> ' + esc(info.name || '(sem nome)') + '<br><b>Duração:</b> ' + fmtDur(info.durationMs) +
      '<br><b>Resolução:</b> ' + rs[0] + '×' + rs[1] + (info.rotation ? ' (girado ' + info.rotation + '°)' : '') + '<br><b>Formato:</b> ' + esc(info.mime || '?');
    var base = V.videoBaseName(info.name) || 'Animation';
    if (!st.touched.file) $('vFile').value = base;
    if (!st.touched.name) $('vName').value = base;
    say('msgVPick', '✔ Vídeo carregado.', 'ok'); off('btnVStart', false); updateEstimate(); render();
    Diag.set('import', 'vídeo: ' + (info.name || '?') + ' · ' + fmtDur(info.durationMs), 'ok');
  };

  /* ---------- progresso / resultado ---------- */
  function bar(frac, stage) {
    var pct = Math.round(Math.max(0, Math.min(1, frac)) * 100);
    $('vBar').style.width = pct + '%'; $('vBarWrap').setAttribute('aria-valuenow', String(pct)); $('vProgText').textContent = pct + '%';
    if (stage) $('vStage').textContent = String(stage).toUpperCase();
    return pct;
  }
  function saveBar(frac) { var pct = Math.round(Math.max(0, Math.min(1, frac)) * 100); $('vSaveBar').style.width = pct + '%'; $('vSaveBarWrap').setAttribute('aria-valuenow', String(pct)); $('vSaveText').textContent = pct + '%'; }
  function showWarns(list) { $('vWarns').hidden = !list.length; $('vWarns').innerHTML = list.map(function (w) { return '<p>⚠ ' + esc(w) + '</p>'; }).join(''); }
  function showChecks(list) { $('vChecks').innerHTML = list.map(function (c) { return '<li class="' + (c.level === 'ok' ? '' : c.level === 'warn' ? 'warn' : 'bad') + '">' + esc(c.label) + (c.detail ? '<small>' + esc(c.detail) + '</small>' : '') + '</li>'; }).join(''); }
  function resetRun() {
    st.built = false; st.plan = null; st.summary = null; off('btnVSave', true);
    $('vChecks').innerHTML = ''; showWarns([]); say('msgVStart', ''); say('msgVSave', ''); $('vSaveInfo').textContent = '';
    bar(0, 'PROGRESSO'); saveBar(0); $('vBarWrap').classList.remove('err');
  }
  function setBusy(b) {
    st.busy = b; off('btnVStart', b || !st.video); $('btnVCancel').hidden = !b;
    ['vFps', 'vSize', 'vFile', 'vName', 'vDesc'].forEach(function (id) { $(id).disabled = b; });
  }
  function fail(msg) {
    setBusy(false); $('vBarWrap').classList.add('err'); say('msgVStart', '✖ ' + msg, 'err'); Diag.error('vídeo → mcpack: ' + msg); Diag.set('conv', '✖ ' + msg, 'bad');
  }

  /* ---------- 2) conversão automática ---------- */
  function b64ToU8(b64) { var bin = atob(b64), u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
  async function loadBase() {
    var size = B.baseSize();
    if (!(size > 0)) throw new Error('Pacote-base não encontrado dentro do aplicativo (assets/base).');
    var parts = [], got = 0;
    for (var i = 0; got < size; i++) {
      var b64 = B.baseChunk(i);
      if (!b64) throw new Error('Falha ao ler o pacote-base embutido.');
      var u = b64ToU8(b64); parts.push(u); got += u.length; await tick();
    }
    if (got !== size) throw new Error('Pacote-base lido incompleto (' + got + ' de ' + size + ' bytes).');
    return new Blob(parts);
  }
  $('btnVStart').addEventListener('click', async function () {
    Diag.tap('CONVERTER VÍDEO → MCPACK');
    if (st.busy) { say('msgVStart', 'Conversão já em andamento.', 'warn'); return; }
    if (!hasNative) { say('msgVStart', 'Disponível apenas no aplicativo Android.', 'err'); return; }
    if (!st.video) { say('msgVStart', 'Selecione um vídeo primeiro.', 'err'); return; }
    var c = cfg(), N = V.frameCount(st.video.durationMs, c.fps);
    if (N < 1) { say('msgVStart', 'O vídeo é curto demais para o FPS escolhido.', 'err'); return; }
    resetRun(); st.cancelReq = false; setBusy(true); Diag.set('conv', 'preparando…', 'warn');
    try {
      bar(0.01, 'Carregando pacote-base');
      var base = await loadBase();
      if (st.cancelReq) { window.__onVideoCancelled(); return; }
      bar(0.04, 'Planejando o pacote');
      var plan = await V.buildPlan(C, base, { N: N, fps: c.fps, outW: c.w, outH: c.h, displayName: V.displayNameOf($('vName').value, st.video.name), description: $('vDesc').value.trim() });
      if (st.cancelReq) { window.__onVideoCancelled(); return; }
      st.plan = plan; st.outName = V.mcpackFileName($('vFile').value, st.video.name); showWarns(plan.warnings);
      bar(0.06, 'Iniciando extração dos frames');
      var r = B.startVideoBuild(JSON.stringify(V.nativePlan(plan, st.outName)));
      if (r !== 'ok') throw new Error(String(r).replace(/^err:/, ''));
      Diag.set('conv', 'extraindo frames…', 'warn');
    } catch (e) { fail(e.message || String(e)); }
  });
  $('btnVCancel').addEventListener('click', function () { Diag.tap('CANCELAR'); st.cancelReq = true; if (B && B.cancelVideo) B.cancelVideo(); say('msgVStart', 'Cancelando…', 'warn'); });

  window.__onVideoProgress = function (frac, stage) { bar(0.06 + 0.86 * frac, stage); };
  window.__onVideoError = function (msg) { fail(msg); };
  window.__onVideoCancelled = function () { setBusy(false); bar(0, 'PROGRESSO'); say('msgVStart', 'Conversão cancelada. Nenhum arquivo foi gerado.', 'warn'); Diag.set('conv', 'cancelada', 'warn'); };
  window.__onVideoBuilt = async function (str) {
    try {
      bar(0.93, 'Validando o pacote');
      var S = typeof str === 'string' ? JSON.parse(str) : str; await tick();
      var v = V.validatePackage(S, st.plan);
      showChecks(v.checks); bar(1, 'Concluído');
      if (!v.ok) {
        if (B.discardVideoOutput) B.discardVideoOutput();
        var bad = v.checks.filter(function (x) { return !x.ok; }).map(function (x) { return x.label + (x.detail ? ' — ' + x.detail : ''); });
        fail('Exportação interrompida. Validação falhou: ' + bad.join(' | ')); return;
      }
      st.summary = S; st.built = true; setBusy(false);
      say('msgVStart', '✔ Pacote pronto e validado (' + v.checks.length + ' verificações): ' + st.plan.N + ' frames, ' + fmtMB(S.fileSize) + '.', 'ok');
      off('btnVSave', false); Diag.set('conv', '✔ pacote validado (' + st.plan.N + ' frames)', 'ok');
    } catch (e) { fail('Erro ao validar: ' + (e.message || e)); }
  };

  /* ---------- 3) exportação ---------- */
  $('btnVSave').addEventListener('click', function () {
    Diag.tap('BAIXAR MCPACK PRONTO');
    if (st.saving) { say('msgVSave', 'Gravação em andamento.', 'warn'); return; }
    if (!st.built) { say('msgVSave', 'Converta um vídeo primeiro: o botão só libera depois de todas as validações passarem.', 'warn'); return; }
    st.saving = true; saveBar(0); say('msgVSave', 'Escolha onde salvar…', 'warn'); B.exportVideoPack(st.outName);
  });
  window.__onVideoExportProgress = function (frac) { saveBar(frac); };
  window.__onVideoExported = function (info) {
    st.saving = false;
    if (typeof info === 'string') { try { info = JSON.parse(info); } catch (e) { info = { ok: false, err: 'resposta inválida' }; } }
    if (!info.ok) { var canc = info.err === 'cancelado'; say('msgVSave', (canc ? '⚠ Salvamento cancelado.' : '✖ Erro ao salvar: ' + info.err) + ' Toque em BAIXAR MCPACK PRONTO para tentar de novo.', canc ? 'warn' : 'err'); return; }
    var exp = st.summary ? st.summary.fileSize : info.expected;
    var good = info.written === exp && info.expected === exp && (info.onDisk < 0 || info.onDisk === exp);
    saveBar(good ? 1 : 0);
    if (!good) { say('msgVSave', '✖ Tamanho gravado divergente (esperado ' + exp + ', gravado ' + info.written + ', no disco ' + info.onDisk + '). Tente salvar de novo.', 'err'); return; }
    say('msgVSave', '✔ Salvo: ' + (info.name || st.outName) + ' (' + fmtMB(info.written) + '). Abra o arquivo para importar no Minecraft.', 'ok');
    $('vSaveInfo').textContent = 'Bytes gravados: ' + info.written + ' · no disco: ' + (info.onDisk < 0 ? 'n/d' : info.onDisk);
  };

  render();
  Diag.log('video_ui.js pronto (ponte de vídeo ' + (hasNative ? 'presente' : 'ausente') + ')');
})();
