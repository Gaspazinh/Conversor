plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.betmc.converter"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.betmc.converter"
        minSdk = 24            // WebView do Android 7+ (CompressionStream exige WebView/Chrome 80+; há fallback sem compressão)
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    // Os mesmos arquivos de ../www viram os assets do app (sem duplicar código).
    sourceSets { getByName("main") { assets.srcDirs("../../www") } }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
}
