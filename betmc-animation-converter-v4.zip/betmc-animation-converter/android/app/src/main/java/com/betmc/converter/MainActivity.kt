package com.betmc.converter

import android.annotation.SuppressLint
import android.content.pm.ApplicationInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.util.Base64
import android.util.Log
import android.view.WindowManager
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.io.OutputStream

/**
 * Casca fina: carrega a interface HTML (assets) e faz a ponte para o seletor de arquivos
 * e para o "Salvar como" do Android (Storage Access Framework). Toda a conversão roda em JS, offline.
 * Erros de carga/console são enviados ao painel DIAGNÓSTICO da página e ao Logcat (tag BetMC).
 */
class MainActivity : AppCompatActivity() {
    private val tag = "BetMC"
    private lateinit var web: WebView
    private var chooserCb: ValueCallback<Array<Uri>>? = null
    private var out: OutputStream? = null
    private var saveUri: Uri? = null
    private var written = 0L

    private val pickFile = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        chooserCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        chooserCb = null
        diag("log", "Android: seletor fechado (resultCode=${r.resultCode})")
    }

    private val createDoc = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri == null) { js("window.__onSaveReady&&window.__onSaveReady(false,'cancelado')"); return@registerForActivityResult }
        try {
            out = contentResolver.openOutputStream(uri, "wt")
            saveUri = uri
            written = 0L
            js("window.__onSaveReady&&window.__onSaveReady(true,'')")
        } catch (e: Exception) {
            Log.e(tag, "openOutputStream falhou", e)
            js("window.__onSaveReady&&window.__onSaveReady(false,${JSONObject.quote(e.toString())})")
        }
    }

    // ---- VÍDEO → MCPACK ----
    // O motor é um singleton do processo (VideoEngine.get): continua trabalhando com o app minimizado/fechado
    // (mantido vivo pelo VideoService) e guarda o estado em disco para a interface ser reconstruída ao voltar.
    private val videoEngine: VideoEngine get() = VideoEngine.get(applicationContext)
    private val pickVideoDoc = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) js("window.__onVideoPicked&&window.__onVideoPicked({ok:false,err:'cancelado'})")
        else {
            // guarda a permissão de leitura: o serviço precisa reabrir o vídeo mesmo depois de a tela fechar
            try { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            videoEngine.probe(uri)
        }
    }
    private val askNotif = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        js("window.__onNotifPermission&&window.__onNotifPermission($granted)")
    }
    private val createMcpack = registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri == null) js("window.__onVideoExported&&window.__onVideoExported({ok:false,err:'cancelado'})")
        else videoEngine.export(uri)
    }

    private fun js(code: String) { web.post { web.evaluateJavascript(code, null) } }
    /** Envia mensagem ao painel de diagnóstico da página (kind = "log" ou "error"). */
    private fun diag(kind: String, msg: String) {
        Log.d(tag, "$kind: $msg")
        js("window.BetmcDiag&&BetmcDiag.${if (kind == "error") "error" else "log"}(${JSONObject.quote(msg)})")
    }

    inner class Bridge {
        @JavascriptInterface fun ping(): String {
            val wv = if (Build.VERSION.SDK_INT >= 26) WebView.getCurrentWebViewPackage()?.versionName else null
            return JSONObject().put("sdk", Build.VERSION.SDK_INT).put("webview", wv ?: "?").put("model", Build.MODEL).toString()
        }

        @JavascriptInterface fun beginSave(name: String) { runOnUiThread { createDoc.launch(name) } }

        /** Retorna "ok" ou "err:<motivo>" para o JS saber, de forma síncrona, se o bloco foi gravado. */
        @JavascriptInterface fun writeChunk(b64: String): String = try {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            out!!.write(bytes)
            written += bytes.size
            "ok"
        } catch (e: Exception) { Log.e(tag, "writeChunk falhou", e); "err:$e" }

        @JavascriptInterface fun cancelSave() { try { out?.close() } catch (_: Exception) {}; out = null }

        // ---- VÍDEO → MCPACK ----
        private val baseAsset = "base/Rebeca_Animation_CORRIGIDA.mcpack"
        private val baseChunkSize = 512 * 1024
        @JavascriptInterface fun hasVideoEngine(): Boolean = true
        @JavascriptInterface fun pickVideo() { runOnUiThread { pickVideoDoc.launch(arrayOf("video/*")) } }
        @JavascriptInterface fun baseSize(): Int = try { videoEngine.baseSize(baseAsset) } catch (e: Exception) { -1 }
        @JavascriptInterface fun baseChunkBytes(): Int = baseChunkSize
        @JavascriptInterface fun baseChunk(index: Int): String = try { videoEngine.baseChunk(baseAsset, index, baseChunkSize) } catch (e: Exception) { "" }
        /** Retorna "ok" ou "err:<motivo>". O progresso e o resultado chegam por window.__onVideo*. */
        @JavascriptInterface fun startVideoBuild(planJson: String, fullPlanJson: String): String = videoEngine.build(planJson, fullPlanJson)
        @JavascriptInterface fun cancelVideo() { videoEngine.cancel() }
        /** Estado persistido (status/etapa/progresso/resultado) para reconstruir a interface. Nunca inicia conversão. */
        @JavascriptInterface fun getVideoState(): String = videoEngine.stateJson()
        /** A interface terminou a verificação do pacote gravado. */
        @JavascriptInterface fun reportValidation(ok: Boolean, msg: String) { videoEngine.reportValidation(ok, msg) }
        @JavascriptInterface fun resetVideo() { videoEngine.reset() }
        // ---- notificações ----
        @JavascriptInterface fun notifEnabled(): Boolean = VideoNotifier.enabled(this@MainActivity)
        @JavascriptInterface fun setNotifEnabled(v: Boolean) { VideoNotifier.setEnabled(this@MainActivity, v) }
        @JavascriptInterface fun notifAllowed(): Boolean = VideoNotifier.canPost(this@MainActivity)
        /** true se o Android ainda vai pedir a permissão de notificações (13+). */
        @JavascriptInterface fun needsNotifPermission(): Boolean = Build.VERSION.SDK_INT >= 33 && !VideoNotifier.canPost(this@MainActivity)
        @JavascriptInterface fun requestNotifPermission() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= 33) askNotif.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                else js("window.__onNotifPermission&&window.__onNotifPermission(true)")
            }
        }
        @JavascriptInterface fun exportVideoPack(name: String) { runOnUiThread { createMcpack.launch(name) } }

        @JavascriptInterface fun endSave() {
            var ok = true
            var err = ""
            try { out?.flush(); out?.close() } catch (e: Exception) { ok = false; err = e.toString() }
            out = null
            val uri = saveUri
            var onDisk = -1L
            var name = ""
            if (uri != null) {
                try { contentResolver.openFileDescriptor(uri, "r")?.use { onDisk = it.statSize } } catch (_: Exception) {}
                try {
                    contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                        if (it.moveToFirst()) name = it.getString(0) ?: ""
                    }
                } catch (_: Exception) {}
            }
            val info = JSONObject().put("ok", ok).put("err", err).put("name", name)
                .put("uri", uri?.toString() ?: "").put("written", written).put("onDisk", onDisk)
            js("window.__onSaveDone&&window.__onSaveDone($info)")
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        if (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0) WebView.setWebContentsDebuggingEnabled(true)
        web = WebView(this).apply { isFocusable = true; isFocusableInTouchMode = true }
        setContentView(web)
        web.requestFocus()
        web.settings.apply {
            javaScriptEnabled = true
            allowFileAccess = true            // assets do próprio app
            allowContentAccess = true
            blockNetworkLoads = true
            cacheMode = WebSettings.LOAD_NO_CACHE
            setSupportZoom(false)            // sem zoom por pinça
            builtInZoomControls = false
            displayZoomControls = false
        }
        videoEngine.listener = { code -> js(code) }
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) { diag("log", "Android: página carregada ($url)") }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                diag("error", "Android: falha ao carregar ${request.url} (${error.description})")
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooserCb?.onReceiveValue(null)
                chooserCb = cb
                diag("log", "Android: abrindo seletor de arquivos")
                return try { pickFile.launch(p.createIntent()); true } catch (e: Exception) {
                    chooserCb = null
                    diag("error", "Android: não abriu o seletor: $e")
                    false
                }
            }
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                val line = "${m.message()} (${m.sourceId()?.substringAfterLast('/')}:${m.lineNumber()})"
                Log.d("$tag-JS", "${m.messageLevel()}: $line")
                // erros de script externo em file:// chegam ao JS sem detalhe; o console do WebView tem o detalhe completo
                if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR && !m.message().startsWith("[betmc]")) diag("log", "console: $line")
                return false
            }
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onStart() { super.onStart(); VideoEngine.appVisible = true }
    override fun onStop() { VideoEngine.appVisible = false; super.onStop() }

    override fun onResume() {
        super.onResume()
        // ao voltar (inclusive pelo toque na notificação) a página relê o estado salvo; nunca inicia outra conversão
        js("window.__onVideoResume&&window.__onVideoResume()")
    }

    override fun onDestroy() {
        // a conversão NÃO é cancelada aqui: ela pertence ao motor/serviço. Só soltamos a referência à página.
        videoEngine.listener = null
        super.onDestroy()
    }
}
