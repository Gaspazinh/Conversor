"""Testes de INTERFACE da v4 em Chromium (Playwright). Uso: python3 tests/video_ui_test.py
O lado nativo (Kotlin: MediaMetadataRetriever, ZIP, Foreground Service, notificações) é SIMULADO: a ponte Android é um mock
em JS e o "motor" é um montador em Python que segue o mesmo contrato do VideoEngine.kt (inclui remover a pasta externa).
Valida interface, plano, validação e reconstrução de estado — NÃO valida o Kotlin, o serviço, as notificações reais nem a decodificação."""
import base64, json, os, shutil, struct, sys, tempfile, zipfile, zlib
from playwright.sync_api import sync_playwright

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
BASE = os.path.join(HERE, 'fixtures_video', 'Rebeca_Animation_CORRIGIDA.mcpack')
TMP = tempfile.mkdtemp(prefix='vidui_')
BASE_HEADER_UUID = '99328435-f33f-4806-8c3e-daa7dc42d508'; BASE_MODULE_UUID = '0d0288fa-36a7-4a33-ba2f-0e5a45c1b2d6'
import re
UUID_RE = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$')
res = []
def check(name, cond, extra=''):
    res.append((name, bool(cond))); print(('PASS ' if cond else 'FAIL ') + name + (('  -> ' + str(extra)[:300]) if (extra and not cond) else ''))

_png_cache = {}
def png(w, h, seed=0):
    k = (w, h, seed)
    if k in _png_cache: return _png_cache[k]
    def chunk(t, d): return struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    row = b'\x00' + bytes([(seed * 40) & 255, 80, 160]) * w
    out = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(row * h, 1)) + chunk(b'IEND', b'')
    _png_cache[k] = out; return out

STATE = {'mode': 'ok', 'out': None, 'size': 0, 'n': 0}
def py_build(plan_json):
    plan = json.loads(plan_json); mode = STATE['mode']; strip = plan.get('stripRoot', '')
    nm = lambda n: n[len(strip):] if strip and n.startswith(strip) else n   # espelha VideoEngine.kt: remove só a pasta externa
    STATE['n'] += 1; out_path = os.path.join(TMP, 'out%d.mcpack' % STATE['n']); STATE['out'] = out_path
    z = zipfile.ZipFile(BASE); drop = set(plan['dropPaths']); texts = plan['texts']
    fw, fh = plan['frameSize']; iw, ih = plan['iconSize']; sw, sh = plan['staticSize']
    icon, stat = png(iw, ih, 7), png(sw, sh, 8)
    infos = z.infolist(); man = plan['manifestPath']
    ordered = [i for i in infos if i.filename == man] + [i for i in infos if i.filename != man]
    with zipfile.ZipFile(out_path, 'w') as o:
        for i in ordered:
            n = i.filename
            if n.endswith('/'):
                if nm(n): o.writestr(nm(n), b'')
                continue
            if n in drop: continue
            if n == plan['iconPath']: o.writestr(nm(n), icon, zipfile.ZIP_STORED)
            elif n == plan['staticPath']: o.writestr(nm(n), stat, zipfile.ZIP_STORED)
            elif n in texts: o.writestr(nm(n), texts[n].encode('utf-8'), zipfile.ZIP_DEFLATED)
            else: o.writestr(nm(n), z.read(n), zipfile.ZIP_DEFLATED)
        for k, p in enumerate(plan['framePaths']):
            if mode == 'missing' and k == 5: continue
            o.writestr(nm(p), png(fw, fh, 1 if k == 0 else 2), zipfile.ZIP_STORED)
        if mode == 'wrapped':  # simula montagem errada (pasta externa mantida)
            pass
    if mode == 'wrapped':
        w = out_path + '.w'
        with zipfile.ZipFile(out_path) as a, zipfile.ZipFile(w, 'w') as b:
            for i in a.infolist(): b.writestr('Pasta/' + i.filename, a.read(i.filename))
        os.replace(w, out_path)
    STATE['size'] = os.path.getsize(out_path)
    entries = []
    with zipfile.ZipFile(out_path) as r:
        for i in r.infolist():
            if i.is_dir(): continue
            d = r.read(i.filename); crc = zlib.crc32(d) & 0xffffffff
            e = {'p': i.filename, 'size': len(d), 'crc': crc, 'crcOk': crc == i.CRC}
            if i.filename.endswith('.png'):
                ok = d[:8] == b'\x89PNG\r\n\x1a\n'; e['png'] = {'ok': ok, 'w': struct.unpack('>I', d[16:20])[0] if ok else 0, 'h': struct.unpack('>I', d[20:24])[0] if ok else 0}
            if i.filename.endswith('.json'): e['text'] = d.decode('utf-8')
            entries.append(e)
    gen = {'iconCrc': zlib.crc32(icon) & 0xffffffff, 'staticCrc': zlib.crc32(stat) & 0xffffffff, 'frame1Crc': zlib.crc32(png(fw, fh, 1)) & 0xffffffff}
    return json.dumps({'entries': entries, 'gen': gen, 'fileSize': STATE['size']})

THUMB = '/9j/4AAQSkZJRgABAQEASABIAAD/2wBDAP//////////////////////////////////////////////////////////////////////////////////////wgALCAABAAEBAREA/8QAFBABAAAAAAAAAAAAAAAAAAAAAP/aAAgBAQABPxA='
MOCK = r"""
(() => { const S = window.__mk = { video: null, mode: 'ok', needsPerm: false, size: 0, fullPlan: null, summary: null, cancel: false, exportName: null, lastPlan: null,
  calls: { start: 0, cancel: 0, reset: 0, report: [], notifReq: 0, setNotif: [], pick: 0 },
  state: { status: 'idle', stage: '', progress: 0, outName: '', error: '', frames: 0, hasFile: false, fileSize: 0, notifEnabled: true, notifAllowed: true } };
 const st = (o) => Object.assign(S.state, o);
 const B64 = '%BASE64%'; const bin = atob(B64); const CH = 512 * 1024;
 const sleep = (ms) => new Promise(r => setTimeout(r, ms));
 S.emitProgress = (f, s) => { st({ progress: f, stage: s }); window.__onVideoProgress && window.__onVideoProgress(f, s); };
 S.finishJob = async (silent) => { const sum = await window.py_build(JSON.stringify(S.lastPlan)); S.size = JSON.parse(sum).fileSize; S.summary = sum;
   st({ status: 'built', stage: 'Verificando', progress: 0.94, hasFile: true, fileSize: S.size }); if (!silent) window.__onVideoBuilt && window.__onVideoBuilt(sum); };
 S.job = async () => {
   for (let i = 1; i <= 4; i++) { if (S.cancel) { st({ status: 'idle', stage: '', progress: 0 }); window.__onVideoCancelled && window.__onVideoCancelled(); return; } S.emitProgress(0.06 + 0.88 * i / 5, 'Extraindo e gravando frame ' + i + ' de ' + S.lastPlan.N); await sleep(15); }
   if (S.mode === 'hold') { while (S.mode === 'hold') { if (S.cancel) { st({ status: 'idle', stage: '', progress: 0 }); window.__onVideoCancelled && window.__onVideoCancelled(); return; } await sleep(20); } }
   const fail = (m) => { st({ status: 'error', error: m }); window.__onVideoError && window.__onVideoError(m); };
   if (S.mode === 'extract_fail') return fail('Falha ao decodificar o quadro 7 (instante 0.29 s). O codec deste vídeo pode não ser suportado.');
   if (S.mode === 'write_fail') return fail('No space left on device (ENOSPC)');
   if (S.mode === 'space') return fail('Espaço livre insuficiente: preciso de cerca de 400 MB e há 80 MB.');
   await S.finishJob(false);
 };
 window.AndroidBridge = {
  ping: () => JSON.stringify({sdk: 36, webview: 'mock', model: 'MockM34'}),
  pickVideo: () => { S.calls.pick++; setTimeout(() => { if (S.video && S.video.ok) st({ video: S.video, status: 'idle' }); window.__onVideoPicked(S.video); }, 20); },
  baseSize: () => bin.length, baseChunkBytes: () => CH,
  baseChunk: (i) => { const a = i * CH; if (a >= bin.length) return ''; return btoa(bin.slice(a, Math.min(bin.length, a + CH))); },
  getVideoState: () => { const o = Object.assign({}, S.state); if (o.status === 'built') { o.plan = S.fullPlan; o.summary = S.summary; } return JSON.stringify(o); },
  startVideoBuild: (planJson, fullPlan) => {
    if (S.mode === 'busy') return 'err:Já existe uma conversão em andamento.';
    S.calls.start++; S.lastPlan = JSON.parse(planJson); S.fullPlan = fullPlan; S.cancel = false;
    st({ status: 'running', stage: 'Preparando', progress: 0.06, outName: S.lastPlan.outName, frames: S.lastPlan.N, error: '' });
    if (S.mode !== 'manual') setTimeout(S.job, 30);
    return 'ok';
  },
  cancelVideo: () => { S.calls.cancel++; S.cancel = true; },
  reportValidation: (ok, msg) => { S.calls.report.push(ok); if (S.state.status !== 'built') return; if (ok) st({ status: 'ready', progress: 1, stage: 'Pronto' }); else st({ status: 'error', error: msg, hasFile: false }); },
  resetVideo: () => { S.calls.reset++; st({ status: 'idle', stage: '', progress: 0, error: '', hasFile: false }); },
  notifEnabled: () => S.state.notifEnabled, setNotifEnabled: (v) => { S.state.notifEnabled = v; S.calls.setNotif.push(v); },
  notifAllowed: () => S.state.notifAllowed, needsNotifPermission: () => S.needsPerm,
  requestNotifPermission: () => { S.calls.notifReq++; setTimeout(() => { S.needsPerm = false; window.__onNotifPermission && window.__onNotifPermission(true); }, 20); },
  exportVideoPack: (name) => { S.exportName = name; setTimeout(() => { window.__onVideoExportProgress(0.5);
      if (S.mode === 'export_cancel') window.__onVideoExported({ok:false, err:'cancelado'});
      else if (S.mode === 'export_short') window.__onVideoExported({ok:true, name, written: S.size - 1, onDisk: S.size - 1, expected: S.size});
      else window.__onVideoExported({ok:true, name, written: S.size, onDisk: S.size, expected: S.size}); }, 30); }
 }; })();
"""
VID = lambda **k: dict({'ok': True, 'name': 'Meu Clipe 01.mp4', 'durationMs': 15000, 'width': 1920, 'height': 1080, 'rotation': 0, 'mime': 'video/mp4', 'thumb': THUMB}, **k)
BASE64 = base64.b64encode(open(BASE, 'rb').read()).decode()

BROWSERS = []
def page_for(p, video=None, bridge=True, restore=None, viewport=(390, 800), mode=None):
    STATE['mode'] = mode if mode in ('missing', 'wrapped') else 'ok'
    b = p.chromium.launch(args=['--no-sandbox']); BROWSERS.append(b)
    while len(BROWSERS) > 3:
        try: BROWSERS.pop(0).close()
        except Exception: pass
    ctx = b.new_context(viewport={'width': viewport[0], 'height': viewport[1]}, has_touch=True, is_mobile=True)
    pg = ctx.new_page(); pg.errs = []; pg.on('pageerror', lambda e: pg.errs.append(str(e)))
    if bridge:
        pg.expose_function('py_build', py_build)
        pg.add_init_script(MOCK.replace('%BASE64%', BASE64))
        pg.add_init_script('window.__mk.video = %s;' % json.dumps(video or VID()))
        if mode: pg.add_init_script("window.__mk.mode = '%s';" % mode)
        if restore: pg.add_init_script("(()=>{const r=%s; Object.assign(window.__mk,{state:r.state,fullPlan:r.plan,summary:r.summary,size:r.size,video:r.video,lastPlan:r.lastPlan}); window.__mk.calls.start=r.start;})();" % json.dumps(restore))
    pg.goto('file://%s/www/index.html' % ROOT); pg.wait_for_timeout(300); return pg
tap = lambda pg, sel: pg.tap(sel, force=True)
def cls(pg, sel): return pg.get_attribute(sel, 'class') or ''
def wait_mode(pg, mode, t=120000): pg.wait_for_function("(m)=>document.getElementById('app').getAttribute('data-mode')===m", arg=mode, timeout=t)
def snap(pg): return pg.evaluate("({state:window.__mk.state, plan:window.__mk.fullPlan, summary:window.__mk.summary, size:window.__mk.size, video:window.__mk.video, lastPlan:window.__mk.lastPlan, start:window.__mk.calls.start})")
def pick(pg): tap(pg, '#btnPick'); wait_mode(pg, 'ready', 5000)
def manifest_of(path):
    z = zipfile.ZipFile(path); return json.loads(z.read('manifest.json')), z

with sync_playwright() as p:
    # ---------- 1) inicialização: só a tela de conversão
    pg = page_for(p)
    body = pg.inner_text('body')
    check('inicia normalmente (sem erros de JS) e modo vazio', not pg.errs and pg.get_attribute('#app', 'data-mode') == 'empty', pg.errs)
    check('somente a tela de conversão: nada de aba/fluxo MCPACK → MCPACK', 'MCPACK → MCPACK' not in body and not pg.query_selector('#tabPack') and not pg.query_selector('#btnImport') and not pg.query_selector('#frames') and not pg.query_selector('#btnGen'))
    check('seletor de vídeo visível; avançadas, converter e resultado ocultos', pg.is_visible('#btnPick') and not pg.is_visible('#pAdv') and not pg.is_visible('#btnStart') and not pg.is_visible('#pDone'))
    check('diagnóstico oculto ao iniciar', not pg.is_visible('#diag') and 'DIAGNÓSTICO' not in body.upper().replace('DIAGNÓSTICO (DESENVOLVEDOR)', '') or not pg.is_visible('#diag'))
    check('aviso técnico da pasta-raiz não existe na interface', 'pasta-raiz' not in pg.content() and 'manifest.json' not in body)
    # ---------- 2) zoom e rolagem
    meta = pg.get_attribute('meta[name=viewport]', 'content')
    check('viewport sem zoom (user-scalable=no, maximum-scale=1)', 'user-scalable=no' in meta and 'maximum-scale=1' in meta and 'width=device-width' in meta, meta)
    ta = pg.evaluate("getComputedStyle(document.body).touchAction + '|' + getComputedStyle(document.querySelector('#btnPick')).touchAction")
    check('touch-action só permite rolar (pan-x pan-y) no corpo e nos botões', ta == 'pan-x pan-y|pan-x pan-y', ta)
    # NOTA: gestos de toque sintetizados (pinça/rolagem por CDP) não têm efeito neste Chromium headless nem numa página de controle;
    # por isso a pinça real só pode ser conferida no aparelho. Aqui testamos o que é verificável: meta/touch-action (acima) e o nosso bloqueio em JS.
    r = pg.evaluate("""() => { const mk = (n) => { const ts = Array.from({length: n}, (_, i) => new Touch({identifier: i, target: document.body, clientX: 50 + i * 80, clientY: 200})); const e = new TouchEvent('touchmove', {touches: ts, targetTouches: ts, changedTouches: ts, cancelable: true, bubbles: true}); document.body.dispatchEvent(e); return e.defaultPrevented; }; return [mk(2), mk(1)]; }""")
    check('bloqueio em JS: touchmove com 2 dedos é cancelado; com 1 dedo (rolagem) não', r == [True, False], r)
    pg = page_for(p, viewport=(390, 520)); pick(pg); tap(pg, '#advBtn'); pg.wait_for_timeout(450)
    h = pg.evaluate('document.documentElement.scrollHeight'); check('conteúdo maior que a tela (há o que rolar)', h > 520, h)
    pg.mouse.move(195, 300); pg.mouse.wheel(0, 260); pg.wait_for_timeout(400)
    sy = pg.evaluate('window.scrollY'); check('a página rola (rolagem não foi travada pelo bloqueio de zoom)', sy > 50, sy)
    check('overflow vertical liberado', pg.evaluate("getComputedStyle(document.body).overflowY") in ('visible', 'auto') and pg.evaluate("getComputedStyle(document.documentElement).overflowY") != 'hidden')
    pg.fill('#vFile', 'abc'); check('digitação nos campos continua funcionando', pg.input_value('#vFile') == 'abc')

    # ---------- 3) seleção de vídeo + configurações avançadas
    pg = page_for(p, VID(durationMs=15000)); pick(pg)
    check('seleção: nome, miniatura, duração e resolução original', pg.is_visible('#vThumb') and 'Meu Clipe 01.mp4' in pg.inner_text('#vName0') and '15 s' in pg.inner_text('#vChips') and '1920×1080' in pg.inner_text('#vChips'), pg.inner_text('#vChips'))
    check('informações do processamento: 288 quadros, limite de 12 s, recorte 16:9, 1280×720', all(x in pg.inner_text('#vNote') for x in ('288 quadros', 'limite de 12 s', 'Recorte central 16:9', '1280×720')), pg.inner_text('#vNote'))
    check('CONFIGURAÇÕES AVANÇADAS começa FECHADA e escondida', pg.get_attribute('#advBtn', 'aria-expanded') == 'false' and not pg.is_visible('#vFps') and not pg.is_visible('#vFile') and 'CONFIGURAÇÕES AVANÇADAS' in pg.inner_text('#advBtn'))
    tap(pg, '#advBtn'); pg.wait_for_timeout(450)
    check('abrir: FPS, resolução, nome do arquivo, nome no Minecraft, descrição e notificações visíveis', all(pg.is_visible(s) for s in ('#vFps', '#vSize', '#vFile', '#vName', '#vDesc', '#swNotif ~ .sw-knob')) and pg.get_attribute('#advBtn', 'aria-expanded') == 'true')
    check('valores padrão mantidos: 24 FPS, 1280×720, nomes do vídeo', pg.input_value('#vFps') == '24' and pg.input_value('#vSize') == '1280x720' and pg.input_value('#vFile') == 'Meu Clipe 01' and pg.input_value('#vName') == 'Meu Clipe 01')
    pg.select_option('#vFps', '12'); check('alterar FPS atualiza a estimativa (144 quadros)', '144 quadros' in pg.inner_text('#vNote'), pg.inner_text('#vNote'))
    tap(pg, '#advBtn'); pg.wait_for_timeout(450); check('fechar de novo esconde os campos', not pg.is_visible('#vFps'))

    # ---------- 4) fluxo completo + progresso real + arquivos corretos
    pg = page_for(p, VID(durationMs=15000)); pick(pg); tap(pg, '#advBtn'); pg.wait_for_timeout(400)
    pg.fill('#vFile', 'Minha_Animacao'); pg.fill('#vName', 'Minha Animação ✨'); pg.fill('#vDesc', 'Feito no BetMC')
    tap(pg, '#btnStart'); pg.wait_for_function("document.getElementById('app').getAttribute('data-mode')==='running'", timeout=5000)
    seen = set()
    for _ in range(40):
        v = pg.evaluate("document.getElementById('bar').getAttribute('aria-valuenow')+'|'+document.getElementById('runPct').textContent"); seen.add(v)
        if pg.get_attribute('#app', 'data-mode') == 'done': break
        pg.wait_for_timeout(10)
    wait_mode(pg, 'done', 60000)
    check('progresso mostra valores reais intermediários (não pula de 0 a 100)', len([v for v in seen if v.split('|')[0] not in ('0', '1', '100')]) >= 2, sorted(seen))
    check('etapa atual descrita durante a conversão', pg.evaluate("window.__mk.state.stage") != '' )
    check('conclusão apresentada: selo, nome, quadros e tamanho', pg.is_visible('.done-badge') and '288 quadros' in pg.inner_text('#doneS') and 'Minha_Animacao.mcpack' in pg.inner_text('#doneS'), pg.inner_text('#doneS'))
    check('botão BAIXAR MCPACK PRONTO habilitado e destacado (pulse)', pg.get_attribute('#btnSave', 'aria-disabled') == 'false' and 'pulse' in cls(pg, '#btnSave'))
    check('validação foi reportada ao nativo (ok) uma vez', pg.evaluate('window.__mk.calls.report') == [True])
    plan = pg.evaluate('window.__mk.lastPlan')
    check('plano nativo: 288 frames, 24 FPS, 1280×720, 12 s, nome do arquivo, pasta externa a remover', plan['N'] == 288 and plan['fps'] == 24 and plan['frameSize'] == [1280, 720] and plan['maxSeconds'] == 12 and plan['outName'] == 'Minha_Animacao.mcpack' and plan['stripRoot'] == 'Rebeca_Animation__FIXado120/', plan.get('stripRoot'))
    m1, z1 = manifest_of(STATE['out']); out1 = os.path.join(TMP, 'export1.mcpack'); shutil.copy(STATE['out'], out1)
    names = z1.namelist(); frames = [n for n in names if n.endswith('.png') and 'ezgif-frame-' in n]
    check('MCPACK: manifest.json direto na RAIZ, sem pasta externa', 'manifest.json' in names and not any(n.startswith('Rebeca_Animation__FIXado120/') for n in names) and len({n.split('/')[0] for n in names if '/' in n} | {''} ) > 1)
    check('MCPACK: ZIP íntegro, 288 PNGs numerados 001..288, textura e ícone na estrutura original', z1.testzip() is None and len(frames) == 288 and 'pack_icon.png' in names and any(n.endswith('betmc_background_static_patch.png') for n in names) and 'contents.json' in names and 'textures/textures_list.json' in names)
    anim = json.loads(z1.read('betmc_ui/betmc_common/betmc_animation_288.json'))
    check('MCPACK: loop (anim_288 → anim_1), duração 1/24, 288 frames', anim['anim_288']['next'].endswith('anim_1') and abs(anim['anim_1']['duration'] - 1 / 24) < 1e-12 and 'frame_289' not in anim)
    check('MCPACK: nome no Minecraft e descrição aplicados', m1['header']['name'] == 'Minha Animação ✨' and m1['header']['description'] == 'Feito no BetMC')
    check('MCPACK: UUIDs v4 válidos, distintos entre si e diferentes do pacote-base', all(UUID_RE.match(u) for u in [m1['header']['uuid']] + [m['uuid'] for m in m1['modules']]) and len({m1['header']['uuid']} | {m['uuid'] for m in m1['modules']}) == 1 + len(m1['modules']) and m1['header']['uuid'] != BASE_HEADER_UUID and m1['modules'][0]['uuid'] != BASE_MODULE_UUID, m1)
    check('MCPACK: versão/min_engine/subpacks preservados', m1['header']['version'] == [0, 0, 4] and 'subpacks' in m1 and 'min_engine_version' in m1['header'])
    tap(pg, '#btnSave'); pg.wait_for_function("document.getElementById('msgSave').className.indexOf('ok')>=0", timeout=5000)
    check('exportação usa o nome escolhido e confere os bytes', pg.evaluate('window.__mk.exportName') == 'Minha_Animacao.mcpack' and 'Salvo' in pg.inner_text('#msgSave'), pg.inner_text('#msgSave'))
    # segunda exportação independente → UUIDs diferentes
    tap(pg, '#btnNew'); wait_mode(pg, 'ready', 5000); pg.evaluate("window.__mk.calls.report.length = 0")
    tap(pg, '#btnStart'); wait_mode(pg, 'done', 60000)
    m2, z2 = manifest_of(STATE['out'])
    u1 = [m1['header']['uuid']] + [m['uuid'] for m in m1['modules']]; u2 = [m2['header']['uuid']] + [m['uuid'] for m in m2['modules']]
    print('   UUIDs export 1:', u1, '\n   UUIDs export 2:', u2)
    check('DUAS exportações: UUIDs de cabeçalho e módulos diferentes entre os pacotes', set(u1).isdisjoint(u2) and all(UUID_RE.match(u) for u in u2))
    check('sem erros de JS no fluxo', not pg.errs, pg.errs)

    # ---------- 5) outros FPS/resoluções/vídeo curto/vertical
    for dur, fps, size, N in ((5000, '12', '960x540', 60), (12000, '30', '640x360', 360), (800, '10', '854x480', 8)):
        pg = page_for(p, VID(durationMs=dur, width=1080, height=1920, rotation=90)); pick(pg)
        check('vertical girado: resolução exibida já girada (1920×1080)', '1920×1080' in pg.inner_text('#vChips'), pg.inner_text('#vChips'))
        tap(pg, '#advBtn'); pg.wait_for_timeout(400); pg.select_option('#vFps', fps); pg.select_option('#vSize', size); tap(pg, '#btnStart'); wait_mode(pg, 'done', 90000)
        check('dur=%dms fps=%s %s → %d frames válidos' % (dur, fps, size, N), pg.evaluate('window.__mk.lastPlan.N') == N and len([n for n in zipfile.ZipFile(STATE['out']).namelist() if 'ezgif-frame-' in n]) == N)

    # ---------- 6) erros organizados e compreensíveis
    for mode, expect in (('extract_fail', 'Não foi possível ler os quadros'), ('write_fail', 'espaço suficiente'), ('space', 'espaço suficiente')):
        pg = page_for(p, mode=mode); pick(pg); tap(pg, '#btnStart'); wait_mode(pg, 'error', 20000)
        t = pg.inner_text('#errMsg')
        check('erro (%s): mensagem simples, sem jargão (%s)' % (mode, expect), expect in t and 'ENOSPC' not in t and 'instante' not in t, t)
        check('erro (%s): botão de baixar oculto; TENTAR NOVAMENTE volta ao início' % mode, not pg.is_visible('#pDone'))
        tap(pg, '#btnRetry'); wait_mode(pg, 'ready', 5000); check('erro (%s): após tentar de novo, vídeo e configurações preservados' % mode, pg.is_visible('#vThumb') and pg.evaluate('window.__mk.calls.reset') == 1)
    pg = page_for(p, mode='missing'); pick(pg); tap(pg, '#btnStart'); wait_mode(pg, 'error', 30000)
    check('verificação reprova PNG faltando: não libera download, erro simples, nativo informado', 'não passou na verificação' in pg.inner_text('#errMsg') and pg.evaluate('window.__mk.calls.report') == [False] and not pg.is_visible('#btnSave'), pg.inner_text('#errMsg'))
    pg = page_for(p, mode='wrapped'); pick(pg); tap(pg, '#btnStart'); wait_mode(pg, 'error', 30000)
    check('montagem com pasta externa é REPROVADA pela verificação (não é só esconder o aviso)', 'não passou na verificação' in pg.inner_text('#errMsg') and pg.evaluate('window.__mk.calls.report') == [False])
    pg = page_for(p, mode='export_cancel'); pick(pg); tap(pg, '#btnStart'); wait_mode(pg, 'done', 30000); tap(pg, '#btnSave'); pg.wait_for_function("document.getElementById('msgSave').textContent.indexOf('cancelado')>=0", timeout=5000)
    check('salvar cancelado: aviso e novo toque permitido', pg.get_attribute('#btnSave', 'aria-disabled') == 'false')
    pg = page_for(p, mode='export_short'); pick(pg); tap(pg, '#btnStart'); wait_mode(pg, 'done', 30000); tap(pg, '#btnSave'); pg.wait_for_function("document.getElementById('msgSave').className.indexOf('err')>=0", timeout=5000)
    check('bytes gravados divergentes → erro (não afirma sucesso)', 'por completo' in pg.inner_text('#msgSave'))
    pg = page_for(p, {'ok': False, 'err': 'Não foi possível ler a duração do vídeo.'}); tap(pg, '#btnPick'); pg.wait_for_timeout(400)
    check('falha ao ler o vídeo: mensagem amigável e tela permanece na seleção', pg.get_attribute('#app', 'data-mode') == 'empty' and pg.inner_text('#msgPick') != '')

    # ---------- 7) cancelamento
    pg = page_for(p, mode='hold'); pick(pg); tap(pg, '#btnStart'); pg.wait_for_function("window.__mk.calls.start===1 && window.__mk.state.progress>0.3", timeout=10000)
    check('durante a conversão: CANCELAR visível e estado "convertendo"', pg.is_visible('#btnCancel') and pg.get_attribute('#app', 'data-mode') == 'running')
    tap(pg, '#btnCancel'); wait_mode(pg, 'ready', 5000)
    check('cancelamento seguro: nativo notificado, interface liberada, sem pacote', pg.evaluate('window.__mk.calls.cancel') == 1 and pg.evaluate("window.__mk.state.status") == 'idle' and not pg.is_visible('#pDone'))
    pg = page_for(p, mode='manual'); pick(pg); tap(pg, '#btnStart'); pg.wait_for_function("window.__mk.calls.start===1", timeout=10000)
    tap(pg, '#btnCancel'); wait_mode(pg, 'ready', 5000) if False else None
    pg.wait_for_function("window.__mk.calls.cancel>=1", timeout=5000)

    # ---------- 8) segundo plano / voltar ao app (estado persistente) — o NATIVO é simulado
    pg = page_for(p, mode='hold'); pick(pg); tap(pg, '#btnStart'); pg.wait_for_function("window.__mk.state.progress>0.3", timeout=10000)
    s = snap(pg); s['state']['status'] == 'running' and None
    pg2 = page_for(p, restore=s, mode='hold')
    pg2.wait_for_function("document.getElementById('app').getAttribute('data-mode')==='running'", timeout=5000)
    check('voltar durante a conversão: tela reconstruída em "convertendo" com o progresso salvo', int(pg2.get_attribute('#bar', 'aria-valuenow')) >= 30 and 'frame' in pg2.inner_text('#runStage'), pg2.inner_text('#runStage'))
    pg2.wait_for_timeout(500)
    check('voltar NÃO inicia segunda conversão', pg2.evaluate('window.__mk.calls.start') == 1)
    pg2.evaluate("window.__mk.mode='ok'"); pg2.evaluate("window.__mk.finishJob(false)"); wait_mode(pg2, 'done', 60000)
    check('conclusão depois de voltar: verifica e mostra o resultado', pg2.get_attribute('#btnSave', 'aria-disabled') == 'false' and pg2.evaluate('window.__mk.calls.report') == [True])
    pg = page_for(p, mode='hold'); pick(pg); tap(pg, '#btnStart'); pg.wait_for_function("window.__mk.state.progress>0.3", timeout=10000)
    pg.evaluate("window.__mk.finishJob(true)"); pg.wait_for_function("window.__mk.state.status==='built'", timeout=30000)   # o nativo terminou SEM a página (silencioso)
    check('pré-condição: nativo gravou o pacote e a página não foi avisada', pg.evaluate('window.__mk.calls.report') == [] and pg.get_attribute('#app', 'data-mode') == 'running')
    pg3 = page_for(p, restore=snap(pg))     # a página foi "destruída" e o nativo terminou sozinho
    wait_mode(pg3, 'done', 30000)
    check('voltar APÓS a conclusão (estado "gravado"): verifica e libera o MCPACK sem converter de novo', pg3.evaluate('window.__mk.calls.start') == 1 and pg3.evaluate('window.__mk.calls.report') == [True] and pg3.get_attribute('#btnSave', 'aria-disabled') == 'false')
    s = snap(pg3); pg4 = page_for(p, restore=s); wait_mode(pg4, 'done', 10000)
    check('voltar com o pacote já pronto: resultado disponível, nenhuma conversão iniciada', pg4.evaluate('window.__mk.calls.start') == 1 and pg4.evaluate('window.__mk.calls.report') == [] and '288 quadros' in pg4.inner_text('#doneS'), pg4.inner_text('#doneS'))
    tap(pg4, '#btnSave'); pg4.wait_for_function("document.getElementById('msgSave').className.indexOf('ok')>=0", timeout=5000)
    check('baixar a partir do estado restaurado', 'Salvo' in pg4.inner_text('#msgSave'))
    pg5 = page_for(p, restore={'state': {'status': 'error', 'error': 'A conversão foi interrompida (o aplicativo foi encerrado).', 'stage': '', 'progress': 0, 'outName': '', 'frames': 0, 'hasFile': False, 'fileSize': 0, 'notifEnabled': True, 'notifAllowed': True, 'video': VID()}, 'plan': None, 'summary': None, 'size': 0, 'video': VID(), 'lastPlan': None, 'start': 0})
    wait_mode(pg5, 'error', 5000)
    check('processo encerrado no meio: erro compreensível, sem reiniciar sozinho', 'interrompida' in pg5.inner_text('#errMsg') and pg5.evaluate('window.__mk.calls.start') == 0)

    # ---------- 9) notificações: permissão e liga/desliga
    pg = page_for(p); pg.evaluate('window.__mk.needsPerm = true'); pick(pg); tap(pg, '#advBtn'); pg.wait_for_timeout(400)
    check('opção de notificações reflete o estado salvo (ligada)', pg.is_checked('#swNotif'))
    pg.evaluate("document.getElementById('swNotif').click()"); pg.wait_for_timeout(100)
    check('desligar notificações: nativo informado', pg.evaluate('window.__mk.calls.setNotif') == [False])
    pg.evaluate("document.getElementById('swNotif').click()"); pg.wait_for_timeout(200)
    check('ligar de novo com permissão pendente: o Android é solicitado', pg.evaluate('window.__mk.calls.setNotif') == [False, True] and pg.evaluate('window.__mk.calls.notifReq') == 1)
    pg = page_for(p); pg.evaluate('window.__mk.needsPerm = true'); pick(pg); tap(pg, '#btnStart'); wait_mode(pg, 'done', 60000)
    check('permissão pedida ao iniciar a conversão e a conversão segue', pg.evaluate('window.__mk.calls.notifReq') == 1 and pg.evaluate('window.__mk.calls.start') == 1)
    pg = page_for(p); pg.evaluate("window.__mk.state.notifEnabled = false"); pick(pg); tap(pg, '#btnStart'); pg.wait_for_function("document.getElementById('app').getAttribute('data-mode')==='running'", timeout=5000)
    check('notificações desligadas: a tela avisa para manter o app aberto', 'aberto' in pg.inner_text('#runNote') or pg.get_attribute('#app', 'data-mode') == 'done')

    # ---------- 10) acesso de desenvolvedor discreto
    pg = page_for(p)
    for i in range(6): tap(pg, '#brand')
    check('6 toques no logotipo NÃO abrem o diagnóstico', not pg.is_visible('#diag'))
    tap(pg, '#brand'); pg.wait_for_timeout(300)
    check('7 toques rápidos abrem o diagnóstico (recursos de coleta preservados)', pg.is_visible('#diag') and 'ativo' in pg.inner_text('#d_js') and 'BetmcCore' in pg.inner_text('#d_core') and pg.is_visible('#d_log') and pg.is_visible('#diagCopy'))
    tap(pg, '#diagToggle'); check('painel de desenvolvedor pode ser fechado', not pg.is_visible('#diag'))
    # ---------- 11) sem ponte Android
    pg = page_for(p, bridge=False); tap(pg, '#btnPick')
    check('sem ponte Android: avisa que é só no app, sem fingir', 'aplicativo' in pg.inner_text('#msgPick') and pg.get_attribute('#app', 'data-mode') == 'empty')

fails = [n for n, ok in res if not ok]
print('\n%d/%d OK' % (len(res) - len(fails), len(res))); shutil.rmtree(TMP, ignore_errors=True)
sys.exit(1 if fails else 0)
