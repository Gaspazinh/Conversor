/*
 * BetMC — interface do conversor VÍDEO → MCPACK (única tela do app).
 * Lógica em video.js (plano/validação, testada em Node) e VideoEngine.kt (extração/ZIP). Aqui: estados, progresso real,
 * reconstrução do estado ao voltar ao app e feedback visual. Nada de progresso fictício: a % vem do processamento.
 */
(function () {
  'use strict';
  var Diag = window.BetmcDiag || { set: function () {}, log: function () {}, error: function () {}, tap: function () {} };
  var $ = function (id) { return document.getElementById(id); };
  var C = window.BetmcCore, V = window.BetmcVideo, B = window.AndroidBridge;
  if (!$('btnPick')) return;
  var hasNative = !!(B && B.pickVideo && B.startVideoBuild && B.baseSize && B.getVideoState);
  var st = { mode: 'empty', video: null, plan: null, outName: '', busy: false, preparing: false, validating: false, saving: false, cancelReq: false, touched: { file: false, name: false } };
  var tick = function () { return new Promise(function (r) { setTimeout(r, 0); }); };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var fmtMB = function (n) { return (n / 1048576).toFixed(n >= 10485760 ? 0 : 1) + ' MB'; };
  function say(id, text, kind) { var e = $(id); e.textContent = text || ''; e.className = 'msg' + (kind ? ' ' + kind : ''); }
  function disable(id, d) { var b = $(id); b.setAttribute('aria-disabled', d ? 'true' : 'false'); }
  function fmtDur(ms) { var s = ms / 1000, m = Math.floor(s / 60); return m ? m + ' min ' + Math.round(s - m * 60) + ' s' : s.toFixed(s < 10 ? 1 : 0) + ' s'; }
  function icon(id) { return '<svg class="ic"><use href="#' + id + '"/></svg>'; }

  /* ---------------------------------------------------------------- mensagens de erro compreensíveis */
  function friendly(raw) {
    var m = String(raw || '');
    if (/decodific|codec|faixa de v[ií]deo|primeiro quadro/i.test(m)) return 'Não foi possível ler os quadros deste vídeo. O formato pode não ser compatível com este aparelho. Tente outro vídeo (de preferência MP4).';
    if (/Espa[cç]o livre|ENOSPC|No space|insuficiente: preciso/i.test(m)) return 'Não há espaço suficiente no aparelho para gerar o pacote. Libere armazenamento ou escolha menos FPS ou uma resolução menor, e tente de novo.';
    if (/Mem[óo]ria insuficiente|OutOfMemory/i.test(m)) return 'O aparelho ficou sem memória durante a conversão. Tente uma resolução menor (960×540 ou 854×480).';
    if (/interrompida/i.test(m)) return 'A conversão foi interrompida antes de terminar (o app foi encerrado ou o sistema parou o processamento). Toque em tentar novamente.';
    if (/reler o v[ií]deo|permiss|selecione-o novamente/i.test(m)) return 'Não foi possível reabrir o vídeo escolhido. Selecione-o de novo.';
    if (/Valida[cç][aã]o|verifica|corrompid|manifest|incompleto/i.test(m)) return 'O pacote gerado não passou na verificação e por isso não foi liberado. Tente de novo; se repetir, use menos FPS ou outra resolução.';
    if (/aleat[óo]rio seguro/i.test(m)) return 'Este aparelho não conseguiu gerar os identificadores do pacote. Atualize o Android System WebView e tente de novo.';
    return 'Algo deu errado durante a conversão. Tente novamente. Se o problema continuar, o suporte pode pedir o diagnóstico (acesso de desenvolvedor).';
  }

  /* ---------------------------------------------------------------- estados da tela */
  function setMode(m) {
    st.mode = m; $('app').setAttribute('data-mode', m);
    var ready = m === 'ready', empty = m === 'empty';
    $('pCard').hidden = !(ready || empty);
    $('vidBox').hidden = !(ready && st.video); $('vNote').hidden = !(ready && st.video);
    $('pAdv').hidden = !ready; $('btnStart').hidden = !ready;
    $('pRun').hidden = m !== 'running'; $('pDone').hidden = m !== 'done'; $('pErr').hidden = m !== 'error';
    disable('btnStart', !(ready && st.video));
    window.scrollTo(0, 0);
  }
  function showError(raw) {
    st.busy = false; st.preparing = false;
    Diag.error('vídeo → mcpack: ' + raw); Diag.set('conv', '✖ ' + String(raw).slice(0, 120), 'bad');
    $('errMsg').textContent = friendly(raw); setMode('error');
  }

  /* ---------------------------------------------------------------- abas inexistentes: só a tela de conversão. Configurações avançadas */
  $('advBtn').addEventListener('click', function () {
    var open = !$('pAdv').classList.contains('open');
    $('pAdv').classList.toggle('open', open); $('advBtn').setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  V.FPS_CHOICES.forEach(function (f) { var o = document.createElement('option'); o.value = String(f); o.textContent = f + ' FPS' + (f === V.DEFAULTS.fps ? ' (padrão)' : ''); if (f === V.DEFAULTS.fps) o.selected = true; $('vFps').appendChild(o); });
  V.SIZE_CHOICES.forEach(function (s) { var o = document.createElement('option'); o.value = s[0] + 'x' + s[1]; o.textContent = s[0] + '×' + s[1] + (s[0] === V.DEFAULTS.outW ? ' (padrão)' : ''); if (s[0] === V.DEFAULTS.outW) o.selected = true; $('vSize').appendChild(o); });
  function cfg() { var wh = $('vSize').value.split('x').map(Number); return { fps: +$('vFps').value, w: wh[0], h: wh[1] }; }
  function updateNote() {
    if (!st.video) return;
    var c = cfg(), n = V.frameCount(st.video.durationMs, c.fps), total = st.video.durationMs / 1000, used = Math.min(total, V.MAX_SECONDS);
    var mb = (n * c.w * c.h * 3 * 0.5) / 1048576;
    $('vNote').innerHTML = '<b>' + n + ' quadros</b> a ' + c.fps + ' FPS · usa <b>' + used.toFixed(used < 10 ? 1 : 0) + ' s</b> do início' + (total > V.MAX_SECONDS ? ' (limite de 12 s)' : '') +
      '<br>Recorte central 16:9 sem distorção · saída ' + c.w + '×' + c.h + ' · pacote de até ~' + Math.round(mb) + ' MB';
  }
  $('vFps').addEventListener('change', updateNote); $('vSize').addEventListener('change', updateNote);
  $('vFile').addEventListener('input', function () { st.touched.file = true; });
  $('vName').addEventListener('input', function () { st.touched.name = true; });

  /* ---------------------------------------------------------------- notificações (ligar/desligar + permissão) */
  function notifOn() { return !!(hasNative && B.notifEnabled && B.notifEnabled()); }
  function ensureNotifPermission() {
    return new Promise(function (resolve) {
      if (!(notifOn() && B.needsNotifPermission && B.needsNotifPermission())) return resolve();
      var done = false;
      window.__onNotifPermission = function (g) { if (done) return; done = true; Diag.log('permissão de notificações: ' + g); resolve(); };
      setTimeout(function () { if (!done) { done = true; resolve(); } }, 60000);
      B.requestNotifPermission();
    });
  }
  $('swNotif').addEventListener('change', function () {
    Diag.tap('notificações ' + this.checked);
    if (!hasNative || !B.setNotifEnabled) return;
    B.setNotifEnabled(this.checked);
    if (this.checked && B.needsNotifPermission && B.needsNotifPermission()) { window.__onNotifPermission = function (g) { Diag.log('permissão de notificações: ' + g); }; B.requestNotifPermission(); }
  });

  /* ---------------------------------------------------------------- 1) seleção do vídeo */
  $('btnPick').addEventListener('click', function () {
    Diag.tap('SELECIONAR VÍDEO');
    if (st.busy) { say('msgPick', 'Aguarde: há uma conversão em andamento.', 'warn'); return; }
    if (!hasNative) { say('msgPick', 'A conversão de vídeo funciona apenas no aplicativo BetMC para Android.', 'err'); return; }
    say('msgPick', '', ''); B.pickVideo();
  });
  function setVideo(info, restoring) {
    st.video = info;
    var rs = V.rotatedSize(info.width, info.height, info.rotation || 0);
    $('vThumb').src = 'data:image/jpeg;base64,' + info.thumb;
    $('vThumbTag').textContent = fmtDur(info.durationMs);
    $('vName0').textContent = info.name || 'Vídeo selecionado';
    $('vChips').innerHTML = '<span class="chip">' + icon('i-clock') + fmtDur(info.durationMs) + '</span><span class="chip">' + icon('i-film') + rs[0] + '×' + rs[1] + '</span>';
    if (!st.touched.file || restoring) { var base = V.videoBaseName(info.name) || 'Animation'; if (!st.touched.file) $('vFile').value = base; if (!st.touched.name) $('vName').value = base; }
    $('dropT').textContent = 'Trocar vídeo';
    updateNote();
    Diag.set('import', (info.name || '?') + ' · ' + fmtDur(info.durationMs) + ' · ' + rs[0] + '×' + rs[1], 'ok');
  }
  window.__onVideoPicked = function (info) {
    if (typeof info === 'string') { try { info = JSON.parse(info); } catch (e) { info = { ok: false, err: 'resposta inválida' }; } }
    if (!info.ok) {
      if (info.err === 'cancelado') { say('msgPick', '', ''); return; }
      say('msgPick', friendly(info.err), 'err'); Diag.error('vídeo: ' + info.err); return;
    }
    say('msgPick', '', ''); setVideo(info, false); setMode('ready');
  };

  /* ---------------------------------------------------------------- progresso REAL */
  function setProgress(frac, stage) {
    var pct = Math.round(Math.max(0, Math.min(1, frac)) * 100);
    $('barFill').style.width = pct + '%'; $('bar').setAttribute('aria-valuenow', String(pct)); $('runPct').textContent = pct + '%';
    if (stage) $('runStage').textContent = stage;
    var step = frac < 0.06 ? 1 : frac < 0.94 ? 2 : 3;
    [].slice.call($('steps').children).forEach(function (li) { var s = +li.getAttribute('data-s'); li.className = s < step ? 'done' : s === step ? 'on' : ''; });
  }
  function runUi(active) { $('bar').classList.toggle('stop', !active); }

  /* ---------------------------------------------------------------- 2) conversão automática */
  function b64ToU8(b64) { var bin = atob(b64), u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
  async function loadBase() {
    var size = B.baseSize();
    if (!(size > 0)) throw new Error('Pacote-base não encontrado dentro do aplicativo (assets/base).');
    var parts = [], got = 0;
    for (var i = 0; got < size; i++) {
      var b64 = B.baseChunk(i);
      if (!b64) throw new Error('Falha ao ler o pacote-base embutido.');
      var u = b64ToU8(b64); parts.push(u); got += u.length; await tick();
    }
    if (got !== size) throw new Error('Pacote-base lido incompleto (' + got + ' de ' + size + ' bytes).');
    return new Blob(parts);
  }
  function backToReady() { st.busy = false; st.preparing = false; setMode(st.video ? 'ready' : 'empty'); }
  $('btnStart').addEventListener('click', async function () {
    Diag.tap('CONVERTER');
    if (st.busy) return;
    if (!hasNative) { say('msgPick', 'A conversão de vídeo funciona apenas no aplicativo BetMC para Android.', 'err'); return; }
    if (!st.video) return;
    var c = cfg(), N = V.frameCount(st.video.durationMs, c.fps);
    if (N < 1) { showError('O vídeo é curto demais para o FPS escolhido.'); return; }
    st.busy = true; st.preparing = true; st.cancelReq = false; st.plan = null;
    $('runTitle').textContent = 'Convertendo'; runUi(true); setProgress(0.01, 'Preparando'); setMode('running'); disable('btnCancel', false);
    $('runNote').textContent = notifOn() ? 'Você pode sair do app: a conversão continua em segundo plano e avisamos quando terminar.' : 'Mantenha o BetMC aberto até concluir (notificações desligadas).';
    Diag.set('conv', 'preparando…', 'warn');
    try {
      await ensureNotifPermission();
      if (notifOn() && B.notifAllowed && !B.notifAllowed()) $('runNote').textContent = 'Você pode sair do app, mas as notificações estão bloqueadas no Android: volte aqui para ver o resultado.';
      setProgress(0.02, 'Carregando o pacote-base'); var base = await loadBase();
      if (st.cancelReq) { backToReady(); return; }
      setProgress(0.04, 'Planejando o pacote');
      var plan = await V.buildPlan(C, base, { N: N, fps: c.fps, outW: c.w, outH: c.h, displayName: V.displayNameOf($('vName').value, st.video.name), description: $('vDesc').value.trim() });
      if (st.cancelReq) { backToReady(); return; }
      plan.warnings.forEach(function (w) { Diag.log('aviso: ' + w); }); // avisos técnicos: só no diagnóstico
      st.plan = plan; st.outName = V.mcpackFileName($('vFile').value, st.video.name);
      setProgress(0.06, 'Iniciando a extração dos quadros');
      var r = B.startVideoBuild(JSON.stringify(V.nativePlan(plan, st.outName)), JSON.stringify(plan));
      if (r !== 'ok') throw new Error(String(r).replace(/^err:/, ''));
      st.preparing = false; Diag.set('conv', 'extraindo quadros…', 'warn');
      if (st.cancelReq && B.cancelVideo) B.cancelVideo();
    } catch (e) { showError(e.message || String(e)); }
  });
  $('btnCancel').addEventListener('click', function () {
    Diag.tap('CANCELAR'); st.cancelReq = true; disable('btnCancel', true); $('runStage').textContent = 'Cancelando…';
    if (!st.preparing && B && B.cancelVideo) B.cancelVideo();
  });

  window.__onVideoProgress = function (frac, stage) { if (st.mode !== 'running') { st.busy = true; setMode('running'); } setProgress(frac, stage); };
  window.__onVideoError = function (msg) { showError(msg); };
  window.__onVideoCancelled = function () { Diag.set('conv', 'cancelada', 'warn'); backToReady(); };
  window.__onVideoBuilt = function (str) {
    try { var S = typeof str === 'string' ? JSON.parse(str) : str; if (st.plan) verifyAndFinish(S, st.plan); else syncFromNative(); }
    catch (e) { showError('Erro ao ler o resultado: ' + (e.message || e)); }
  };

  /* verificação (14 itens) do pacote gravado → libera o download */
  async function verifyAndFinish(S, plan) {
    if (st.validating) return;
    st.validating = true;
    try {
      st.busy = true; if (st.mode !== 'running') setMode('running');
      $('runTitle').textContent = 'Verificando'; setProgress(0.96, 'Verificando o pacote'); await tick();
      var v = V.validatePackage(S, plan);
      v.checks.forEach(function (c) { Diag.log((c.ok ? '✔ ' : '✖ ') + c.label + (c.detail ? ' — ' + c.detail : '')); });
      if (!v.ok) {
        var bad = v.checks.filter(function (x) { return !x.ok; }).map(function (x) { return x.label + (x.detail ? ' — ' + x.detail : ''); }).join(' | ');
        if (B.reportValidation) B.reportValidation(false, 'verificação falhou');
        showError('Validação falhou: ' + bad); return;
      }
      if (B.reportValidation) B.reportValidation(true, '');
      finishDone({ frames: plan.N, fileSize: S.fileSize, outName: st.outName });
    } catch (e) { showError('Erro ao verificar: ' + (e.message || e)); }
    finally { st.validating = false; }
  }
  function finishDone(info) {
    st.busy = false; st.preparing = false; st.outName = info.outName || st.outName;
    setProgress(1, 'Concluído'); runUi(false);
    $('doneS').textContent = (info.frames ? info.frames + ' quadros · ' : '') + (info.fileSize ? fmtMB(info.fileSize) + ' · ' : '') + st.outName;
    say('msgSave', '', ''); $('saveBarWrap').hidden = true; setSave(0); disable('btnSave', false);
    Diag.set('conv', '✔ pacote verificado e pronto', 'ok'); setMode('done');
  }

  /* ---------------------------------------------------------------- 3) exportação */
  function setSave(f) { $('saveBar').style.width = Math.round(Math.max(0, Math.min(1, f)) * 100) + '%'; }
  $('btnSave').addEventListener('click', function () {
    Diag.tap('BAIXAR MCPACK PRONTO');
    if (st.saving) { say('msgSave', 'Gravação em andamento.', 'warn'); return; }
    st.saving = true; setSave(0); $('saveBarWrap').hidden = false; say('msgSave', 'Escolha onde salvar…', 'warn'); B.exportVideoPack(st.outName || 'BetMC.mcpack');
  });
  window.__onVideoExportProgress = function (frac) { setSave(frac); };
  window.__onVideoExported = function (info) {
    st.saving = false;
    if (typeof info === 'string') { try { info = JSON.parse(info); } catch (e) { info = { ok: false, err: 'resposta inválida' }; } }
    if (!info.ok) {
      $('saveBarWrap').hidden = true;
      if (info.err === 'cancelado') { say('msgSave', 'Salvamento cancelado. Toque em baixar para tentar de novo.', 'warn'); return; }
      Diag.error('exportação: ' + info.err); say('msgSave', 'Não foi possível salvar o arquivo. Verifique o espaço livre e tente de novo.', 'err'); return;
    }
    var exp = info.expected;
    var good = info.written === exp && (info.onDisk < 0 || info.onDisk === exp);
    if (!good) { Diag.error('exportação: bytes divergentes (esperado ' + exp + ', gravado ' + info.written + ', disco ' + info.onDisk + ')'); $('saveBarWrap').hidden = true; say('msgSave', 'O arquivo não foi gravado por completo. Tente baixar de novo.', 'err'); return; }
    setSave(1); say('msgSave', '✔ Salvo: ' + (info.name || st.outName) + ' (' + fmtMB(info.written) + '). Abra o arquivo para importar no Minecraft.', 'ok');
    Diag.set('save', '✔ ' + (info.name || st.outName) + ' · ' + info.written + ' bytes', 'ok');
  };
  $('btnNew').addEventListener('click', function () { Diag.tap('NOVA CONVERSÃO'); if (hasNative && B.resetVideo) B.resetVideo(); st.plan = null; backToReady(); });
  $('btnRetry').addEventListener('click', function () { Diag.tap('TENTAR NOVAMENTE'); if (hasNative && B.resetVideo) B.resetVideo(); st.plan = null; backToReady(); });

  /* ---------------------------------------------------------------- reconstrução do estado (voltar ao app / toque na notificação) */
  function applyNativeState(s) {
    if (!s) return;
    $('swNotif').checked = !!s.notifEnabled;
    if (s.video && (!st.video || st.video.name !== s.video.name || st.video.durationMs !== s.video.durationMs)) setVideo(s.video, true);
    switch (s.status) {
      case 'running':
        st.busy = true; st.preparing = false; if (st.mode !== 'running') { $('runTitle').textContent = 'Convertendo'; setMode('running'); }
        runUi(true); setProgress(s.progress || 0, s.stage || 'Convertendo'); break;
      case 'built':
        if (!st.validating) { try { var plan = JSON.parse(s.plan), S = JSON.parse(s.summary); st.plan = plan; st.outName = s.outName; verifyAndFinish(S, plan); } catch (e) { showError('Erro ao reconstruir o resultado: ' + (e.message || e)); } }
        break;
      case 'ready':
        if (st.mode !== 'done') finishDone({ frames: s.frames, fileSize: s.fileSize, outName: s.outName });
        break;
      case 'error':
        if (!st.preparing && st.mode !== 'error') showError(s.error || 'erro desconhecido');
        break;
      default: // idle
        if (st.mode === 'running' && !st.preparing) backToReady();
        else if (st.mode === 'empty' && st.video) setMode('ready');
    }
  }
  function syncFromNative() {
    if (!hasNative) return;
    try { applyNativeState(JSON.parse(B.getVideoState())); } catch (e) { Diag.error('estado: ' + e.message); }
  }
  window.__onVideoResume = syncFromNative;
  document.addEventListener('visibilitychange', function () { if (!document.hidden) syncFromNative(); });

  /* ---------------------------------------------------------------- zoom por pinça bloqueado (reforço ao viewport/touch-action/WebView) */
  document.addEventListener('touchmove', function (e) { if (e.touches && e.touches.length > 1) e.preventDefault(); }, { passive: false });
  document.addEventListener('gesturestart', function (e) { e.preventDefault(); });

  /* ---------------------------------------------------------------- acesso de desenvolvedor: 7 toques rápidos no logotipo */
  (function () {
    var n = 0, t0 = 0;
    $('brand').addEventListener('click', function () {
      var now = Date.now(); if (now - t0 > 5000) n = 0; t0 = t0 && now - t0 <= 5000 ? t0 : now; n++;
      if (n >= 7) { n = 0; t0 = 0; var d = $('diag'); d.hidden = false; d.scrollIntoView({ behavior: 'smooth', block: 'start' }); Diag.log('painel de desenvolvedor aberto'); }
    });
  })();

  /* ---------------------------------------------------------------- diagnóstico (só desenvolvedor) e início */
  Diag.set('core', C ? '✔ BetmcCore carregado' : '✖ BetmcCore ausente', C ? 'ok' : 'bad');
  try {
    if (B && B.ping) { var pi = JSON.parse(B.ping()); Diag.set('bridge', '✔ ativa · Android SDK ' + pi.sdk + ' · WebView ' + pi.webview + (pi.model ? ' · ' + pi.model : ''), 'ok'); }
    else Diag.set('bridge', 'ausente (modo navegador)', 'warn');
  } catch (e) { Diag.set('bridge', '✖ erro na ponte: ' + e.message, 'bad'); }
  if (hasNative && B.notifEnabled) $('swNotif').checked = !!B.notifEnabled();
  setMode('empty');
  syncFromNative();
  window.__betmcAppReady = true; Diag.set('app', '✔ interface pronta', 'ok'); Diag.log('video_ui.js pronto (ponte de vídeo ' + (hasNative ? 'presente' : 'ausente') + ')');
})();
