/*
 * BetMC — VÍDEO → MCPACK · lógica pura (sem DOM, sem Android).
 * Reutiliza o núcleo existente (BetmcCore.analyze/convert) para gerar JSONs/listas do pacote-base e
 * valida o pacote final a partir de um "resumo" produzido pelo lado nativo (Kotlin).
 * Testável em Node:  tests/video_tests.js
 */
(function (global) {
  'use strict';

  const MAX_SECONDS = 12;
  const DEFAULTS = { fps: 24, outW: 1280, outH: 720 };
  const FPS_CHOICES = [10, 12, 15, 20, 24, 25, 30];
  const SIZE_CHOICES = [[1280, 720], [960, 540], [854, 480], [640, 360]];
  const dec = (u8) => new TextDecoder('utf-8').decode(u8);
  const stripBom = (s) => (s.charCodeAt(0) === 0xfeff ? s.slice(1) : s);
  const pad = (n, w) => String(n).padStart(w, '0');
  const escRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const u32 = (n) => n >>> 0;

  /* ----------------------------------------------------------- cálculos puros */
  /** Quantidade de frames: só o início do vídeo, no máximo maxSec, conforme o FPS. */
  function frameCount(durationMs, fps, maxSec) {
    maxSec = maxSec || MAX_SECONDS;
    if (!(durationMs > 0) || !(fps > 0)) return 0;
    const usable = Math.min(durationMs / 1000, maxSec);
    return Math.max(1, Math.floor(usable * fps + 1e-6));
  }
  /** Instante (µs) de cada quadro: k / fps, k = 0..N-1. */
  function frameTimeUs(k, fps) { return Math.round((k * 1e6) / fps); }

  /** Recorte central com proporção tw:th dentro de sw×sh (sem deformar). Retorna [x, y, w, h]. */
  function centerCrop(sw, sh, tw, th) {
    if (sw * th > sh * tw) { // mais largo que o alvo: corta as laterais
      const w = Math.max(1, Math.floor((sh * tw) / th));
      return [Math.floor((sw - w) / 2), 0, w, sh];
    }
    const h = Math.max(1, Math.floor((sw * th) / tw)); // mais alto (ou igual): corta topo/base
    return [0, Math.floor((sh - h) / 2), sw, h];
  }
  /** Dimensões após a rotação do metadado (90/270 trocam largura e altura). */
  function rotatedSize(w, h, rot) { return (((rot % 360) + 360) % 360) % 180 === 90 ? [h, w] : [w, h]; }

  const VIDEO_EXT = /\.(mp4|m4v|mov|mkv|webm|3gp|3g2|avi|ts|mpg|mpeg|wmv|flv)$/i;
  const clean = (s) => String(s || '').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '').replace(/\s+/g, ' ').trim().slice(0, 80);
  function videoBaseName(name) { return clean(String(name || '').replace(VIDEO_EXT, '')); }
  function mcpackFileName(input, videoName) {
    const b = clean(String(input || '').replace(/\.(mcpack|zip)$/i, '')) || videoBaseName(videoName) || 'Animation';
    return b + '.mcpack';
  }
  function displayNameOf(input, videoName) { return clean(input) || videoBaseName(videoName) || 'Animation'; }

  function dumpLike(obj, orig) {
    const m = /\n([ \t]+)\S/.exec(orig);
    let s = m ? JSON.stringify(obj, null, m[1]) : JSON.stringify(obj);
    if (/\n\s*$/.test(orig)) s += '\n';
    return s;
  }
  function setKeyDeep(o, key, val) {
    let hits = 0;
    (function walk(x) { if (x && typeof x === 'object') for (const k of Object.keys(x)) { if (k === key) { x[k] = val; hits++; } else walk(x[k]); } })(o);
    return hits;
  }
  /** Créditos/descrição antigos herdados da base (TikTok @betmc2411). */
  const CREDIT_RE = /tiktok|betmc2411/i;
  const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
  /** UUID v4 aleatório (crypto.getRandomValues; funciona em file:// mesmo sem contexto seguro). */
  function uuidV4() {
    const c = typeof globalThis !== 'undefined' && globalThis.crypto;
    if (!c || !c.getRandomValues) throw new Error('Este aparelho não oferece gerador aleatório seguro para criar os identificadores do pacote.');
    const b = new Uint8Array(16); c.getRandomValues(b);
    b[6] = (b[6] & 0x0f) | 0x40; b[8] = (b[8] & 0x3f) | 0x80;
    const h = Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
    return h.slice(0, 8) + '-' + h.slice(8, 12) + '-' + h.slice(12, 16) + '-' + h.slice(16, 20) + '-' + h.slice(20);
  }
  function ihdr(u8) {
    const sig = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a];
    if (u8.length < 24 || sig.some((b, i) => u8[i] !== b)) return null;
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    return [dv.getUint32(16), dv.getUint32(20)];
  }

  /* ---------------------------------------------------------------- PLANO */
  /**
   * Usa o pacote-base (Blob) + BetmcCore para produzir tudo o que o lado nativo precisa:
   * textos dos JSONs já atualizados, caminhos dos N PNGs, caminhos a descartar, imagens estáticas e tamanhos.
   * o = { N, fps, outW, outH, displayName, description }
   */
  async function buildPlan(C, baseBlob, o) {
    const N = o.N, fps = o.fps;
    if (!Number.isInteger(N) || N < 1) throw new Error('Quantidade de frames inválida.');
    if (!(fps > 0)) throw new Error('FPS inválido.');
    const info = await C.analyze(baseBlob);
    if (!info.physical || !info.physical.length) throw new Error('O pacote-base não contém o PNG de frame esperado.');
    info.duration = 1 / fps; // tempo de cada frame = 1/FPS (usado nos anim_N pelo core)
    const r = await C.convert(info, N);
    const out = await C.openZip(r.blob);
    const base = info.zip;
    const texts = {};
    for (const k of r.stats.modified) {
      const en = out.entries.find((e) => e.norm === k);
      texts[k] = dec(await C.extract(out, en));
    }
    const byDepth = (a, b) => a.norm.split('/').length - b.norm.split('/').length;
    // manifest: só header.name (e header.description, se o usuário informou). UUIDs/versões intactos.
    const mEn = base.entries.filter((e) => !e.isDir && /(^|\/)manifest\.json$/.test(e.norm)).sort(byDepth)[0];
    if (!mEn) throw new Error('manifest.json não encontrado no pacote-base.');
    const mText = stripBom(dec(await C.extract(base, mEn)));
    const man = JSON.parse(mText);
    if (!man.header) throw new Error('manifest.json do pacote-base sem "header".');
    man.header.name = o.displayName;
    // Descrição: campo vazio (ou só espaços) → descrição FINAL vazia; preenchido → exatamente o texto informado.
    // A descrição/créditos que vêm do pacote-base (ex.: TikTok) nunca são reaproveitados.
    const desc = typeof o.description === 'string' && o.description.trim() !== '' ? o.description : '';
    man.header.description = desc;
    (man.modules || []).forEach((m) => { if (typeof m.description === 'string' && CREDIT_RE.test(m.description)) m.description = ''; });
    // UUIDs NOVOS a cada exportação (o Minecraft recusa dois pacotes com o mesmo UUID). Gerados uma única vez aqui
    // e guardados no plano: montagem e validação do mesmo pacote usam sempre os mesmos valores.
    const baseUuids = new Set([man.header.uuid].concat((man.modules || []).map((m) => m.uuid)).filter(Boolean));
    const used = new Set(), fresh = () => { let u; do { u = uuidV4(); } while (used.has(u) || baseUuids.has(u)); used.add(u); return u; };
    const uuids = { header: fresh(), modules: [] };
    man.header.uuid = uuids.header;
    (man.modules || []).forEach((m) => { m.uuid = fresh(); uuids.modules.push(m.uuid); });
    texts[mEn.norm] = dumpLike(man, mText);
    // duração do frame nos configs de subpack (ex.: $betmc_frame_duration)
    const configs = [];
    for (const en of base.entries) {
      if (en.isDir || !/\.json$/i.test(en.norm) || en.usize > 1024 * 1024 || en.norm === mEn.norm || texts[en.norm] !== undefined) continue;
      const t = stripBom(dec(await C.extract(base, en)));
      if (t.indexOf('$betmc_frame_duration') < 0) continue;
      let j; try { j = JSON.parse(t); } catch (e) { continue; }
      if (setKeyDeep(j, '$betmc_frame_duration', 1 / fps) > 0) { texts[en.norm] = dumpLike(j, t); configs.push(en.norm); }
    }
    const warnings = r.warnings.filter((w) => !/^Faltam /.test(w) && !/pasta-raiz|manifest\.json na raiz/i.test(w)); // avisos técnicos: só para o diagnóstico
    if (!configs.length) warnings.push('Nenhum "$betmc_frame_duration" encontrado nos configs; a duração foi aplicada só nos anim_N.');
    // imagens estáticas e ícone (dimensões lidas do próprio pacote-base)
    const findPng = (suffix) => base.entries.filter((e) => !e.isDir && e.norm.endsWith(suffix)).sort(byDepth)[0];
    const iconEn = findPng('pack_icon.png'), statEn = findPng('betmc_background_static_patch.png');
    if (!iconEn) throw new Error('pack_icon.png não encontrado no pacote-base.');
    if (!statEn) throw new Error('betmc_background_static_patch.png não encontrado no pacote-base.');
    const iconSize = ihdr(await C.extract(base, iconEn)), staticSize = ihdr(await C.extract(base, statEn));
    if (!iconSize || !staticSize) throw new Error('pack_icon.png ou betmc_background_static_patch.png do pacote-base não é um PNG válido.');
    const W = Math.max(3, String(N).length);
    const dir = info.physical[0].dir;
    const framePaths = [];
    for (let i = 1; i <= N; i++) framePaths.push(dir + info.texPrefix + pad(i, W) + '.png');
    return {
      N, fps, duration: 1 / fps, frameSize: [o.outW, o.outH], root: mEn.norm.slice(0, -'manifest.json'.length), stripRoot: mEn.norm.slice(0, -'manifest.json'.length), uuids, baseUuids: Array.from(baseUuids), texPrefix: info.texPrefix, texW: W, ns: info.ns,
      iconPath: iconEn.norm, iconSize, staticPath: statEn.norm, staticSize,
      framePaths, dropPaths: info.physical.map((p) => p.entry.norm),
      texts, roles: { anim: info.anim.path, bg: info.bg.path, texList: info.texList && info.texList.norm, contents: info.contents && info.contents.norm, manifest: mEn.norm, configs },
      displayName: o.displayName, description: desc, baseManifest: mText,
      baseEntries: base.entries.filter((e) => !e.isDir).map((e) => ({ p: e.norm, crc: u32(e.crc), size: e.usize })),
      warnings,
    };
  }
  /** Subconjunto enviado ao Kotlin. */
  function nativePlan(plan, outName) {
    return {
      N: plan.N, fps: plan.fps, frameSize: plan.frameSize, maxSeconds: MAX_SECONDS, outName, stripRoot: plan.stripRoot,
      iconPath: plan.iconPath, iconSize: plan.iconSize, staticPath: plan.staticPath, staticSize: plan.staticSize,
      framePaths: plan.framePaths, dropPaths: plan.dropPaths, texts: plan.texts, manifestPath: plan.roles.manifest,
      baseAsset: 'base/Rebeca_Animation_CORRIGIDA.mcpack',
    };
  }

  /* ------------------------------------------------------------- VALIDAÇÃO */
  /**
   * S = resumo do ZIP final (feito pelo Kotlin lendo o arquivo gravado):
   *   { entries:[{p,size,crc,crcOk,png:{ok,w,h}|null,text?}], gen:{iconCrc,staticCrc,frame1Crc}, fileSize }
   */
  function flatView(plan) {
    const R = plan.stripRoot || '';
    const rel = (p) => (p && R && p.startsWith(R) ? p.slice(R.length) : p);
    const mapKeys = (o) => { const r = {}; Object.keys(o).forEach((k) => { r[rel(k)] = o[k]; }); return r; };
    const roles = Object.assign({}, plan.roles, { anim: rel(plan.roles.anim), bg: rel(plan.roles.bg), texList: rel(plan.roles.texList), contents: rel(plan.roles.contents), manifest: rel(plan.roles.manifest), configs: plan.roles.configs.map(rel) });
    return Object.assign({}, plan, {
      root: '', iconPath: rel(plan.iconPath), staticPath: rel(plan.staticPath), framePaths: plan.framePaths.map(rel), dropPaths: plan.dropPaths.map(rel),
      texts: mapKeys(plan.texts), roles, baseEntries: plan.baseEntries.map((b) => ({ p: rel(b.p), crc: b.crc, size: b.size })),
    });
  }
  function validatePackage(S, plan0) {
    const plan = flatView(plan0);
    const checks = [];
    const add = (label, ok, detail, level) => checks.push({ label, ok: !!ok, level: ok ? (level || 'ok') : 'bad', detail: ok ? (detail || '') : (detail || '') });
    const ent = new Map(S.entries.map((e) => [e.p, e]));
    const N = plan.N;
    const J = (p) => {
      const e = ent.get(p);
      if (!e) return { err: 'arquivo ausente' };
      if (typeof e.text !== 'string') return { err: 'sem conteúdo lido' };
      try { return { v: JSON.parse(stripBom(e.text)) }; } catch (x) { return { err: x.message }; }
    };
    const first = (a, n) => a.slice(0, n).join(', ') + (a.length > n ? ' … (+' + (a.length - n) + ')' : '');

    // 1 ZIP válido
    const badCrc = S.entries.filter((e) => !e.crcOk).map((e) => e.p);
    add('ZIP válido: todos os arquivos legíveis e com CRC correto', S.entries.length > 0 && !badCrc.length, badCrc.length ? 'CRC inválido: ' + first(badCrc, 3) : 'Nenhum arquivo no ZIP');

    // 2 manifest + identificação + UUIDs
    const man = J(plan.roles.manifest), bman = (() => { try { return JSON.parse(stripBom(plan.baseManifest)); } catch (e) { return null; } })();
    let manOk = !man.err && bman, manDetail = man.err || '';
    if (manOk) {
      const a = man.v, b = bman;
      const same = (x, y) => JSON.stringify(x) === JSON.stringify(y);
      const noUuid = (ms) => (ms || []).map((m) => Object.assign({}, m, { uuid: undefined }));
      const sameKeys = a.header && same(a.header.version, b.header.version) && same(a.header.min_engine_version, b.header.min_engine_version) &&
        same(noUuid(a.modules), noUuid(b.modules)) && same(a.subpacks, b.subpacks) && same(a.format_version, b.format_version) && same(a.dependencies, b.dependencies);
      const got = [a.header && a.header.uuid].concat((a.modules || []).map((m) => m.uuid));
      const want = [plan.uuids.header].concat(plan.uuids.modules);
      if (!sameKeys) { manOk = false; manDetail = 'versões, módulos ou compatibilidade foram alterados'; }
      else if (a.header.name !== plan.displayName) { manOk = false; manDetail = 'header.name não corresponde ao nome informado'; }
      else if (a.header.description !== plan.description) { manOk = false; manDetail = plan.description ? 'header.description não é exatamente o texto informado' : 'header.description deveria estar vazia'; }
      else if (got.some((u) => typeof u !== 'string' || !UUID_RE.test(u))) { manOk = false; manDetail = 'UUID inválido (não é v4)'; }
      else if (new Set(got).size !== got.length) { manOk = false; manDetail = 'UUID repetido dentro do manifest'; }
      else if (got.some((u) => plan.baseUuids.indexOf(u) >= 0)) { manOk = false; manDetail = 'UUID reaproveitado do pacote-base'; }
      else if (JSON.stringify(got) !== JSON.stringify(want)) { manOk = false; manDetail = 'UUIDs diferentes dos gerados para esta exportação'; }
    }
    add('manifest.json com UUIDs v4 novos e únicos, versões/compatibilidade preservadas e nome atualizado', manOk, manDetail);
    // nenhum crédito/descrição antiga em nenhum metadado textual do pacote (manifest, JSONs, .lang, .txt…)
    const credit = [];
    for (const e of S.entries) {
      if (typeof e.text !== 'string') continue;
      let t = e.text;
      if (plan.description && e.p === plan.roles.manifest) t = t.split(JSON.stringify(plan.description).slice(1, -1)).join(''); // se o USUÁRIO digitou algo assim, é escolha dele
      if (CREDIT_RE.test(t)) credit.push(e.p);
    }
    add('Descrição/créditos do pacote-base (TikTok) não aparecem em nenhum metadado', !credit.length, 'encontrado em: ' + first(credit, 3));
    const topFolders = new Set(S.entries.map((e) => (e.p.indexOf('/') > 0 ? e.p.split('/')[0] : '')));
    const wrapped = S.entries.length > 0 && topFolders.size === 1 && !topFolders.has('');
    add('manifest.json diretamente na raiz do .mcpack (sem pasta externa)', ent.has('manifest.json') && !wrapped && !(plan0.stripRoot && S.entries.some((e) => e.p.indexOf(plan0.stripRoot) === 0)),
      ent.has('manifest.json') ? 'o conteúdo ainda está dentro de uma pasta externa' : 'manifest.json não encontrado na raiz');

    // 3 JSONs válidos
    const jsonBad = [];
    for (const e of S.entries) if (/\.json$/i.test(e.p)) { const r = J(e.p); if (r.err) jsonBad.push(e.p + ' (' + r.err + ')'); }
    add('Todos os JSONs são válidos (' + S.entries.filter((e) => /\.json$/i.test(e.p)).length + ')', !jsonBad.length, first(jsonBad, 3));

    // arquivos de frame físicos no ZIP
    const dir = plan.framePaths[0].slice(0, plan.framePaths[0].lastIndexOf('/') + 1);
    const stem = plan.texPrefix.split('/').pop();
    const frameRe = new RegExp('^' + escRe(dir) + escRe(stem) + '(\\d+)\\.png$');
    const physNums = [];
    for (const e of S.entries) { const m = frameRe.exec(e.p); if (m) physNums.push(+m[1]); }
    physNums.sort((a, b) => a - b);

    // 4 quantidade consistente
    const anim = J(plan.roles.anim), bg = J(plan.roles.bg), tl = plan.roles.texList ? J(plan.roles.texList) : { v: null }, ct = plan.roles.contents ? J(plan.roles.contents) : { v: null };
    const cnt = {};
    if (!anim.err) { cnt.frames = Object.keys(anim.v).filter((k) => /^frame_\d+$/.test(k)).length; cnt.anims = Object.keys(anim.v).filter((k) => /^anim_\d+$/.test(k)).length; }
    if (!bg.err) {
      const panel = Object.values(bg.v).find((v) => v && typeof v === 'object' && Array.isArray(v.controls));
      const ctlRe = new RegExp('^frame_\\d+@' + escRe(plan.ns) + '\\.frame_\\d+$');
      cnt.controls = panel ? panel.controls.filter((c) => c && Object.keys(c).length === 1 && ctlRe.test(Object.keys(c)[0])).length : -1;
    }
    const texRe = new RegExp('^' + escRe(plan.texPrefix) + '\\d+$');
    if (tl.v) cnt.texList = tl.v.filter((s) => typeof s === 'string' && texRe.test(s)).length;
    const relDir = dir.slice(plan.root.length); // contents.json usa caminhos relativos à raiz do pacote (pasta do manifest)
    const contRe = new RegExp('^' + escRe(relDir) + escRe(stem) + '\\d+\\.png$');
    if (ct.v && Array.isArray(ct.v.content)) cnt.contents = ct.v.content.filter((e) => e && contRe.test(e.path)).length;
    cnt.png = physNums.length;
    const cntBad = Object.keys(cnt).filter((k) => cnt[k] !== N).map((k) => k + '=' + cnt[k]);
    add('Quantidade de frames consistente em todos os arquivos (' + N + ')', !cntBad.length && !anim.err && !bg.err, anim.err || bg.err || ('esperado ' + N + '; divergências: ' + cntBad.join(', ')));

    // 5 e 6 referências
    const missingRef = [], badTex = [];
    if (!anim.err) {
      for (let i = 1; i <= N; i++) {
        const f = anim.v['frame_' + i];
        if (!f || f.texture !== plan.texPrefix + pad(i, plan.texW)) { badTex.push('frame_' + i); continue; }
        if (!ent.has(plan.framePaths[i - 1])) missingRef.push(plan.framePaths[i - 1]);
      }
    }
    add('Todos os PNGs referenciados existem no pacote', !anim.err && !missingRef.length && !badTex.length, anim.err || (badTex.length ? 'textura divergente em ' + first(badTex, 3) : 'ausentes: ' + first(missingRef, 3)));
    const dangling = [];
    if (ct.v && Array.isArray(ct.v.content)) for (const e of ct.v.content) if (e && typeof e.path === 'string' && !ent.has(plan.root + e.path)) dangling.push(e.path);
    if (tl.v) for (const s of tl.v) if (typeof s === 'string' && texRe.test(s)) { const n = +s.slice(plan.texPrefix.length); if (!(n >= 1 && n <= N)) dangling.push(s); }
    add('Nenhuma referência (contents.json / textures_list.json) aponta para arquivo inexistente', !dangling.length, first(dangling, 3));

    // 7 numeração contínua
    const seqOk = physNums.length === N && physNums.every((n, i) => n === i + 1);
    add('Numeração contínua dos PNGs (001 … ' + pad(N, plan.texW) + ')', seqOk, 'encontrados ' + physNums.length + ' arquivos; esperado 1..' + N);

    // 8 encadeamento / loop
    let chainBad = '';
    if (anim.err) chainBad = anim.err;
    else for (let i = 1; i <= N; i++) {
      const a = anim.v['anim_' + i];
      const want = '@' + plan.ns + '.anim_' + (i === N ? 1 : i + 1);
      if (!a || a.next !== want) { chainBad = 'anim_' + i + '.next = ' + (a && a.next) + ' (esperado ' + want + ')'; break; }
    }
    add('Encadeamento "next" correto; o último frame volta ao primeiro (loop)', !chainBad, chainBad);

    // 9 duração × FPS
    const dBad = [];
    if (!anim.err) for (let i = 1; i <= N; i++) { const a = anim.v['anim_' + i]; if (!a || Math.abs(a.duration - 1 / plan.fps) > 1e-9) { dBad.push('anim_' + i); if (dBad.length > 3) break; } }
    for (const c of plan.roles.configs) { const r = J(c); let v; if (!r.err) setKeyDeepRead(r.v, (x) => { v = x; }); if (r.err || Math.abs(v - 1 / plan.fps) > 1e-9) dBad.push(c); }
    const total = N / plan.fps;
    add('Duração coerente com o FPS (' + plan.fps + ' FPS ≈ ' + (1 / plan.fps).toFixed(7) + ' s/frame; total ' + total.toFixed(2) + ' s ≤ ' + MAX_SECONDS + ' s)', !dBad.length && total <= MAX_SECONDS + 1e-6, dBad.length ? 'duração divergente: ' + first(dBad, 4) : 'total acima de ' + MAX_SECONDS + ' s');

    // 10 estática, 11 ícone
    const st = ent.get(plan.staticPath), baseSt = plan.baseEntries.find((b) => b.p === plan.staticPath);
    add('betmc_background_static_patch.png substituída pelo primeiro frame (' + plan.staticSize.join('×') + ')',
      st && st.png && st.png.ok && st.png.w === plan.staticSize[0] && st.png.h === plan.staticSize[1] && u32(st.crc) === u32(S.gen.staticCrc) && (!baseSt || u32(baseSt.crc) !== u32(st.crc)),
      !st ? 'ausente' : 'PNG inválido, dimensões diferentes ou conteúdo não substituído');
    const ic = ent.get(plan.iconPath);
    add('pack_icon.png válido e substituído pelo primeiro frame (' + plan.iconSize.join('×') + ')',
      ic && ic.png && ic.png.ok && ic.png.w === plan.iconSize[0] && ic.png.h === plan.iconSize[1] && u32(ic.crc) === u32(S.gen.iconCrc),
      !ic ? 'ausente' : 'PNG inválido, dimensões diferentes ou conteúdo não substituído');

    // 13 PNGs de frame válidos e com a resolução escolhida; frame 1 = fonte da estática
    const pngBad = [];
    for (let i = 1; i <= N; i++) { const e = ent.get(plan.framePaths[i - 1]); if (!e || !e.png || !e.png.ok || e.png.w !== plan.frameSize[0] || e.png.h !== plan.frameSize[1]) { pngBad.push(plan.framePaths[i - 1].split('/').pop()); if (pngBad.length > 3) break; } }
    const f1 = ent.get(plan.framePaths[0]);
    if (f1 && u32(f1.crc) !== u32(S.gen.frame1Crc)) pngBad.push('frame 1 difere do gerado');
    add('Todos os PNGs de frame são válidos e têm ' + plan.frameSize.join('×'), !pngBad.length, first(pngBad, 4));

    // 12 arquivos do pacote-base preservados
    const drop = new Set(plan.dropPaths), lost = [], changed = [];
    for (const b of plan.baseEntries) {
      if (drop.has(b.p)) continue;
      const o = ent.get(b.p);
      if (!o) { lost.push(b.p); continue; }
      const intended = plan.texts[b.p] !== undefined || b.p === plan.iconPath || b.p === plan.staticPath;
      if (!intended && u32(o.crc) !== u32(b.crc)) changed.push(b.p);
    }
    add('Nenhum arquivo do pacote-base removido ou alterado indevidamente', !lost.length && !changed.length, (lost.length ? 'removidos: ' + first(lost, 3) + '. ' : '') + (changed.length ? 'alterados: ' + first(changed, 3) : ''));

    return { ok: checks.every((c) => c.ok), checks };
  }
  function setKeyDeepRead(o, cb) { (function w(x) { if (x && typeof x === 'object') for (const k of Object.keys(x)) { if (k === '$betmc_frame_duration') cb(x[k]); else w(x[k]); } })(o); }

  global.BetmcVideo = {
    MAX_SECONDS, DEFAULTS, FPS_CHOICES, SIZE_CHOICES,
    frameCount, frameTimeUs, centerCrop, rotatedSize, videoBaseName, mcpackFileName, displayNameOf, buildPlan, nativePlan, validatePackage, ihdr, uuidV4, UUID_RE, CREDIT_RE,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = global.BetmcVideo;
})(typeof globalThis !== 'undefined' ? globalThis : this);
