# BetMC Animation Converter

Conversor **100% offline** que muda a quantidade de frames de animações do BetMC UI
(Resource Pack Minecraft Bedrock, `.mcpack`/`.zip`) preservando o resto do pacote.
Sem servidor, sem API, sem CDN: o núcleo é JavaScript puro (ZIP próprio + `CompressionStream` nativo).

## V6 — o que há de novo
- **Recorte manual do vídeo:** linha do tempo com miniaturas, dois marcadores arrastáveis (início/fim), até 12 s de **qualquer** trecho, ajuste fino de 0,1 s e prévia (quadros reduzidos em loop + quadros exatos de início e fim).
- **INSTALAR NO MINECRAFT:** abre o MCPACK gerado pelo Android (FileProvider, permissão temporária de leitura, "Abrir com?"). O botão de salvar/exportar continua.
- **Primeira instalação:** textura-base `BetMC_UI_CORRIGIDO.mcpack` embutida (sem alterações), botão INSTALAR TEXTURA-BASE e tutorial (espaço reservado para a captura real).
- **Atualização pelo GitHub (Releases):** `update.json`, SHA-256, atualização opcional ou obrigatória; o Android sempre pede a confirmação.
- **Regra global:** nunca traduzir identificadores técnicos (`REGRAS_DO_PROJETO.md`).
- **Privacidade:** a conversão continua 100% no aparelho; a internet é usada **só** para verificar/baixar atualizações.
- Tutorial com captura real do Minecraft: `www/img/tutorial_ordem_pacotes.jpg` (original em `docs/img/`; para trocar, substitua o JPG mantendo 1170×540 ou ajuste `width`/`height` no `index.html`).
- Assinatura, Releases e atualização: **`docs/ASSINATURA_E_RELEASES.md`** · teste real de atualização: `docs/PLANO_TESTE_ATUALIZACAO.md`. Relatório da versão: `RELATORIO_V6.md`.
- Testes novos: `node tests/v6_tests.js` e `python3 tests/v6_ui_test.py` (além dos da V5).

## O que foi encontrado no pacote real (análise antes de codar)

| Item | Realidade verificada nos dois `.mcpack` de referência |
|---|---|
| JSON da animação | `betmc_ui/betmc_common/betmc_animation_288.json` (o nome diz 288 mesmo no pacote de 120; o namespace interno é `betmc_animation_288` e **é mantido**, senão as referências quebram) |
| Sistema de animação | `frame_N` (imagem posicionada por `offset` em %) + `anim_N` (`anim_type: offset`, `from`/`to` = **−offset** do frame, `duration` 0,0416667, `next` → próximo; o último aponta para `anim_1`) |
| Grade de offsets | 31 colunas, passo 100%, de −1500% a +1500%; cada linha sobe 100% em Y. Confirmada **frame a frame** nos dois pacotes |
| Controles | `betmc_bg_common.json`: `frame_N@betmc_animation_288.frame_N` dentro de `controls` + `anims: [anim_1]` |
| Listas | `textures/textures_list.json` (caminhos sem extensão) e `contents.json` (caminhos `.png`) listam todos os frames |
| PNGs | `subpacks/720/betmc_background/betmc_background_frame/ezgif-frame-N.png`; **só o frame 1 existe fisicamente** nos dois pacotes |
| Diferenças | pacote de 120: nomes sem zeros (`-1`), `contents.json` desatualizado (79 PNGs listados); pacote de 288: nomes com 3 dígitos e uma pasta-raiz `Rebeca_Animation__FIXado120/` acima do `manifest.json` |

Nada é suposto: o app **descobre** o JSON de animação, o de controles, o prefixo da textura, a grade e a duração a
partir do pacote importado, e **recusa** converter se algo não seguir o padrão detectado (ex.: offset fora da grade).

## Como converter

1. `IMPORTAR TEXTURA` → escolha o `.mcpack`/`.zip` (o app mostra o que reconheceu).
2. Digite a quantidade (qualquer inteiro positivo).
3. `GERAR` → barra de progresso, conversão e validação automática.
4. `SALVAR TEXTURA` (só habilita se **todas** as validações passarem). Nome sugerido: `…_151_Frames.mcpack`.

### O que muda / o que não muda
- **Muda:** o JSON de animação (frames e anims 1..N, `next` do último → `anim_1`), a lista de controles, `textures_list.json`,
  `contents.json` e o nome dos PNGs (renomeados para 3 dígitos; excedentes > N removidos).
- **Frames novos** (N maior que o original): clonados do `frame_1`/`anim_1` do próprio pacote com offset da grade; duração e demais propriedades preservadas.
- **Não muda:** todo o resto é copiado **byte a byte** sem recomprimir (verificado por CRC). `manifest.json` não é tocado
  (o campo `name` ainda mostrará a contagem antiga — é de propósito, para não mexer em manifestos).
- **Nunca** gera imagens. Se faltarem PNGs, o app avisa quais precisam ser adicionados manualmente.
- Formatação dos JSON (indentação, CRLF, BOM, quebra final) é preservada.

### Validações automáticas (bloqueiam o salvamento se falharem)
ZIP abre e todos os CRC conferem · JSONs alterados válidos · estrutura reconhecida de novo no pacote final (grade/encadeamento) ·
N frames / N anims / N controles · nomes com 3 dígitos · nenhuma referência > N em nenhum JSON · último → primeiro ·
sequência contínua · duração igual à original · `textures_list.json` e `contents.json` com N · PNGs presentes válidos ·
arquivos não relacionados idênticos ao original.

## Rodar o protótipo
Abra `www/index.html` no navegador (Chrome/Edge/Firefox recentes). O seletor de arquivos é acionado por um rótulo HTML associado diretamente ao input (mais compatível com navegadores móveis; não depende de `input.click()` em JavaScript). Se o navegador já estava aberto, feche e abra o arquivo novamente após atualizar os arquivos.

## Diagnóstico
O painel no topo do app mostra JS, motor, importação, quantidade, conversão, salvamento, último erro, ambiente e ponte Android. Veja `RELATORIO.md`.

## Testes
```
npm test        # = node tests/run_tests.js && node tests/negative_tests.js && python3 tests/oracle.py
```
Requer Node ≥ 18 e Python 3. Cobre 79/120/151/288 (+1, 31, 32, 200, 1000) a partir dos dois pacotes de referência,
conversão 288→288 idêntica byte a byte, equivalência 1 dígito × 3 dígitos, casos negativos (offset adulterado,
pacote sem animação, ZIP corrompido) e um verificador independente em Python.

## APK Android (Fase 7)
`android/` é um projeto Gradle (Kotlin + WebView) que usa `www/` como assets; **sem permissão de INTERNET** e com `blockNetworkLoads`. A importação e a gravação usam o Storage Access Framework (seletor nativo do Android), portanto **não precisam de `READ_EXTERNAL_STORAGE`, `WRITE_EXTERNAL_STORAGE` nem acesso amplo a todos os arquivos**.
1. Android Studio (Koala+) → *Open* → pasta `android/` (ele cria o Gradle wrapper e baixa o SDK/AGP na primeira vez — única etapa que precisa de internet, e só no PC).
2. *Build > Build APK(s)* (ou `./gradlew assembleDebug` após o wrapper existir) → `android/app/build/outputs/apk/debug/app-debug.apk`.
3. Instale no celular. Importar usa o seletor do Android; salvar usa "Salvar como" (SAF). Se o seletor adicionar outra extensão ao nome, renomeie para `.mcpack`.

## Estrutura
```
www/core.js      ZIP (leitura por Blob.slice, escrita sem recomprimir), análise, conversão, validação, nomes
www/app.js       interface e ponte de salvamento     www/index.html, style.css
android/         casca Kotlin/WebView                 tests/  fixtures + testes + oráculo Python
```


### Correção de botões (mobile)
Os botões GERAR e SALVAR TEXTURA permanecem tocáveis. Se ainda não houver pacote analisado, quantidade válida ou resultado validado, o app informa a etapa que falta em vez de deixar o botão permanentemente cinza. Durante a conversão, GERAR fica temporariamente bloqueado para evitar cliques duplicados.

## BetMC v5 — conversor de vídeo (tela única)
App Android (WebView + Kotlin) que converte vídeo em `.mcpack` para o Minecraft Bedrock, 100% offline.
Escolha o vídeo pela GALERIA (Photo Picker) ou por ARQUIVOS; configurações em "CONFIGURAÇÕES AVANÇADAS"; conversão em Foreground Service com notificações.
Descrição vazia = pacote sem descrição (nenhum crédito é herdado da base). Diagnóstico de desenvolvedor: 7 toques rápidos no logotipo.
Detalhes, testes e limites em `RELATORIO_V5.md`. Testes: `npm test` e `npm run test:ui`.
