# Regras do projeto BETMC

Estas regras valem para quem programa, revisa ou usa uma IA para evoluir o projeto.

## 1. NUNCA traduzir automaticamente identificadores técnicos (regra global)

Preserve **exatamente** os nomes originais de: addons, arquivos, pastas, IDs, UUIDs, variáveis, chaves de JSON,
namespaces, identificadores, nomes de pacotes e de recursos.

- Exemplo: o nome `mommy` **não** vira `mamãe`. `frame_12`, `anim_3`, `betmc_ui` e qualquer caminho dentro do MCPACK ficam como estão.
- Só texto escrito para a **interface do usuário** (rótulos, mensagens, instruções) pode ser traduzido.
- Em código: use `BetmcNames.translate(kind, texto, dicionario)` (`www/names.js`). Para qualquer `kind` diferente de `'ui'` o texto volta intacto.
- A limpeza de caracteres proibidos em **nome de arquivo** (`\ / : * ? " < > |`) não é tradução e continua; ela nunca troca palavras.
- Teste: `node tests/v6_tests.js` (seção "regra de nomes").

## 2. Não alterar o conteúdo interno de MCPACKs recebidos
A textura-base `BetMC_UI_CORRIGIDO.mcpack` (em `www/base/`) é copiada byte a byte. O SHA-256 conferido em `PackInstaller.kt` e nos testes
detecta qualquer mudança. A versão "ORIGINAL" (quebrada) **não** deve ser usada.

## 3. Assinatura e privacidade
- A chave de assinatura definitiva **nunca** entra no repositório (só em GitHub Secrets e em backup do dono). Veja `docs/ASSINATURA_E_RELEASES.md`.
- Vídeos e texturas são processados no aparelho e nunca enviados. A internet é usada só para verificar/baixar atualizações.

## 4. Honestidade nos relatórios
Não declarar teste em aparelho nem compilação que não aconteceram.
