# Relatório — correção "botões não executam ação"

## 1. Causa: o que foi PROVADO e o que NÃO foi

**Provado (Chromium 153 real, não suposição):**
1. O código enviado (`confirm-progress`) funciona de ponta a ponta no navegador: importar → confirmar 151 → GERAR → 16 validações → baixar o `.mcpack`. A lógica de `core.js` (idêntica à que passou nos testes) e os `onclick` estão corretos; **não há erro de JavaScript** na inicialização.
2. **Defeito de layout reproduzido:** após importar, os caminhos longos (`Rebeca_Animation__FIXado120/betmc_ui/...json`) transbordavam do cartão e a página ficava mais larga que a tela (567 px numa tela de 390 px). Nessa condição, em modo celular, **o toque em GERAR foi interceptado por outros elementos** e nada aconteceu. Só corrigindo isso o fluxo por toque passou.
3. **Defeito de design que deixava botões "mudos":** CONFIRMAR e SALVAR ficavam `disabled` (sem nenhuma resposta ao toque) e GERAR, sem confirmação prévia, só escrevia uma frase pequena em outro lugar. Com a página sem JS rodando — ou com precondições não atendidas — o resultado é exatamente "tocar não produz nada perceptível".
4. **Observação sobre os sintomas relatados:** os três itens que "funcionam" (abrir o seletor, digitar, ver a barra) são comportamentos **nativos do HTML**, que funcionam mesmo com JavaScript parado. Só os botões que dependem de JS falham. Isso é compatível com "JS não executou/abortou no aparelho", mas…

**NÃO provado:** a causa exata *no seu aparelho*. Não tenho Android, SDK nem o seu APK, então não consegui reproduzir lá. Hipóteses restantes (todas agora diagnosticáveis no painel): (a) WebView muito antigo (< 80); (b) `core.js` não carregado/bloqueado no APK; (c) APK compilado de uma versão antiga dos assets; (d) erro no JS do aparelho. **O painel DIAGNÓSTICO mostra qual é em um único print** (ver §4).

## 2. Defeitos encontrados e corrigidos
| # | Defeito | Correção |
|---|---|---|
| 1 | Transbordo horizontal (caminhos longos) → página mais larga que a tela, toques interceptados | `overflow-wrap:anywhere`, `min-width:0`, viewport com `minimum-scale=1`; teste automático de largura |
| 2 | Botões `disabled` sem resposta | Nenhum botão fica `disabled`; cada toque mostra mensagem **junto do botão** (erro, aviso ou sucesso) |
| 3 | GERAR sem confirmar quantidade não fazia nada visível | Agora confirma automaticamente o valor digitado e converte (log: "confirmada automaticamente") |
| 4 | Erro real de leitura (WebView sem `DecompressionStream`) virava a mensagem enganosa "Nenhum JSON de animação" | `analyze()` agora repassa o erro verdadeiro ("requer Chrome/WebView 80+…") |
| 5 | Erros de scripts externos em `file://` chegam como "Script error." sem detalhe | Painel explica isso; no Android o console do WebView é encaminhado ao painel e ao Logcat |
| 6 | Salvamento sem confirmação real | Ponte Android retorna bytes gravados **e** tamanho em disco; JS compara com o esperado |
| 7 | Validação da quantidade só com `type=number` (motivo do erro vago) | Campo texto numérico; mensagens específicas (vazio, 0, não inteiro, não numérico, >100000) |

## 3. Arquivos alterados
- `www/index.html` (painel de diagnóstico estático + bootstrap ES5, mensagens por botão, barras de progresso/gravação)
- `www/app.js` (reescrito: fluxo em 5 etapas, sem `disabled`, progresso por etapa, ponte verificada)
- `www/style.css` (layout sem transbordo, estilos do painel/mensagens)
- `www/core.js` (**só** robustez: `features()`, leitura sem depender de `Blob.arrayBuffer`, mensagens de recurso ausente, repasse do erro de leitura; **lógica de conversão/validação intocada**)
- `android/.../MainActivity.kt` (`ping`, `writeChunk` síncrono, `endSave` com conferência, logs/erros → painel, depuração via `chrome://inspect` em build debug)
- `tests/oracle.py` (aceita pasta), **novos:** `tests/ui_test.py`, `tools/build_standalone.js`, `dist/betmc-standalone.html`, este relatório

## 4. Como usar o diagnóstico (30 s)
Abra o app → painel **DIAGNÓSTICO** no topo:
- Linha **JavaScript** continua vermelha "NÃO EXECUTOU" → nenhum script rodou (problema de APK/WebView, não de lógica).
- **Recursos** lista o que falta (ex.: `DecompressionStream` → WebView < 80: atualize "Android System WebView").
- **Motor BetmcCore** vermelho → `core.js` não carregou; **Último erro** diz por quê.
- Toque em **COPIAR DIAGNÓSTICO** e me envie o texto (ou um print).
Teste rápido sem APK: copie `dist/betmc-standalone.html` para o celular e abra no Chrome. Se funcionar lá e não no APK, o problema está no empacotamento/WebView.

## 5. Resultados REAIS dos testes (executados aqui)
- **Motor (Node):** 79, 120, 151, 288, 1, 31, 32, 200, 1000 × 2 pacotes = 18 conversões, todas validadas (56 verificações + 3 casos negativos OK); oráculo Python independente 18/18.
- **Interface (Chromium 153, Playwright): 49/49 OK**: fluxo completo por **clique** e por **toque** (emulação de celular) × 2 pacotes × {79,120,151,288}; mensagens de erro de cada botão; arquivo inválido; GERAR sem importar/confirmar; progresso (25 valores distintos em 1000 frames; 39 em pacote de 85 MB com 288 PNGs); nenhuma tarefa longa (>50 ms) registrada durante a conversão (UI não congela; **sem Web Worker**, pois o processamento é em streams assíncronos); ponte Android **simulada** (ok / cancelado / disco cheio / bytes divergentes); falhas de carregamento (sem `core.js`, `core.js` quebrado, sem `app.js`, JS desligado); navegador sem `DecompressionStream`.
- **Integridade dos arquivos salvos:** 17 `.mcpack` baixados pela interface (clique, toque e ponte simulada) reabertos com `zipfile` (CRC) e conferidos pelo oráculo Python: 17/17.
- Versão `standalone` testada em Chromium: OK.

## 6. O que NÃO foi testado (declaração explícita)
- **Nenhum teste em Android real nem em Android WebView.** A ponte Kotlin↔JS foi testada **apenas com um simulador em JavaScript**; o `MainActivity.kt` foi revisado à mão e **não foi compilado** (sem `kotlinc`/SDK/rede neste ambiente).
- **O APK não foi compilado.** Instruções abaixo.
- Não testei a instalação no Minecraft Bedrock 1.26.60.4; a estrutura dos pacotes não foi alterada além do que já passava nos testes.

## 7. Instalar e testar
1. Android Studio → *Open* → pasta `android/` → *Build > Build APK(s)* (`app-debug.apk`), instale.
2. Abra o app e leia o painel DIAGNÓSTICO. Importe → digite 151 → **CONFIRMAR FRAMES** → **GERAR** → aguarde as 16 verificações → **SALVAR TEXTURA** → escolha a pasta. A mensagem final mostra bytes gravados e tamanho em disco.
3. Em build debug, `chrome://inspect` no PC mostra o console do WebView; o Logcat (tag `BetMC` / `BetMC-JS`) também registra tudo.
4. Testes no PC: `npm test` (Node + Python) e `python3 tests/ui_test.py` (requer `pip install playwright` e Chromium).
