# Relatório — BetMC v4 (refinamento da interface + segundo plano + UUIDs)

## 0. Leia primeiro: limites do que foi verificado
- **O APK NÃO foi compilado e NADA do lado Android foi executado.** Este ambiente não tem Android SDK, `kotlinc` nem rede. O Kotlin novo/alterado (`VideoEngine.kt` refatorado, `VideoService.kt`, `MainActivity.kt`, `AndroidManifest.xml`) foi revisado à mão e só passou numa checagem de balanceamento de chaves. **Pode haver erro de compilação que só o GitHub Actions vai mostrar.**
- **Não foi testado em aparelho (nem no Galaxy M34/Android 16):** Foreground Service, notificações (progresso, conclusão, falha, toque, botão Cancelar), pedido de permissão, minimizar/abrir outro app/voltar durante a conversão, `setSupportZoom(false)` no WebView, decodificação real, exportação SAF, importação no Minecraft.
- O que **foi** executado: toda a lógica em JS (plano, UUIDs, remoção da pasta externa, 14 verificações) e a interface em Chromium. Nesses testes o "nativo" é um **simulador** (mock da ponte + montador em Python no mesmo contrato do Kotlin). Os testes de "voltar ao app" provam que a **interface reconstrói o estado** a partir do que o nativo informa; não provam que o serviço mantém a conversão viva.
- **Pinça de dois dedos:** gestos de toque sintetizados não têm efeito neste Chromium headless (nem numa página de controle), então **o gesto real não foi simulado**. Foram verificados: `viewport` (`user-scalable=no`, `maximum-scale=1`), `touch-action: pan-x pan-y`, e o bloqueio em JS (touchmove de 2 dedos cancelado; 1 dedo não). Confirme no aparelho.

## 1. O que mudou
**Interface (única tela "VÍDEO → MCPACK")** — aba MCPACK → MCPACK removida junto com `app.js`, seus cartões, menus e testes da interface antiga. Mantidos: `core.js` (usado pelo vídeo), `video.js`, ponte Android. Identidade visual própria: dark minimalista, ciano/violeta discretos, grade sutil, cartões com detalhe de canto, ícones SVG embutidos, sem fontes/CDN. Estados com transição (vazio → pronto → convertendo → concluído/erro), botões com feedback ao toque, spinner + barra com % **real** (vem do processamento) + etapa atual + 3 passos, selo de conclusão animado, botão de download com pulso. Respeita `prefers-reduced-motion`.
**Seletor:** miniatura, nome, duração, resolução original (já girada) e nota com o que será processado (quadros, limite de 12 s, recorte 16:9, saída, tamanho estimado).
**CONFIGURAÇÕES AVANÇADAS:** recolhível, começa fechada; FPS, resolução, nome do .mcpack, nome no Minecraft, descrição, opção de notificações. Padrões mantidos (24 FPS, 1280×720).
**Diagnóstico:** oculto; abre com **7 toques rápidos no logotipo** (fecha no botão). A coleta (log, erros, ambiente, ponte, copiar) está intacta. Avisos técnicos (ex.: pasta-raiz) vão só para ele.
**Erros:** mensagens simples em português (sem "ENOSPC", instantes de quadro etc.); o detalhe técnico fica no diagnóstico.
**Zoom:** viewport travado, `touch-action`, bloqueio JS e `setSupportZoom(false)` no WebView.

## 2. manifest.json na raiz (item 11)
Inspeção do pacote-base: 11 arquivos, **todos** dentro de uma única pasta `Rebeca_Animation__FIXado120/`. A montagem agora **remove só essa camada externa** (o `VideoEngine` grava os nomes sem o prefixo; estrutura interna e todos os arquivos preservados; `contents.json` já usa caminhos relativos a essa pasta). A verificação ganhou o item "manifest.json diretamente na raiz do .mcpack" e **reprova** pacote embrulhado (testado) — não é só esconder o aviso. A verificação roda sobre o ZIP **já gravado** (CRC recalculado de cada arquivo).

## 3. UUIDs únicos (item 13)
UUID v4 novo (`crypto.getRandomValues`) para `header.uuid` e cada `modules[].uuid` **a cada exportação**, gerado uma vez no plano e reutilizado na montagem e na verificação. A verificação reprova: UUID inválido (não v4), repetido no manifest, igual ao do pacote-base, ou diferente do gerado. Nome, descrição, versões, `min_engine_version`, módulos (exceto uuid), subpacks e dependências preservados. **Teste dos dois pacotes** (UI, saída real do montador):
Exemplo de uma execução (os valores mudam a cada vez): exportação 1 → `e70fcc59-741d-4840-aa22-c3886eb02960` / `2dc253ef-36f0-4343-b96a-2972f65e39c9`; exportação 2 → `b723e098-dbf1-4e95-8567-2b38a4a9d038` / `8cb2304d-5f95-4510-818d-ad178ab210b0`. Nos testes os 4 UUIDs de dois exports foram sempre distintos entre si e do pacote-base. (Também: 2000 UUIDs gerados, todos válidos e únicos.) **Não foi importado no Minecraft.**

## 4. Segundo plano e notificações (itens 12) — implementado, NÃO testado em aparelho
- **Foreground Service** `VideoService`, tipo **dataSync**. Avaliação: `mediaProcessing` (Android 15+) seria mais específico, mas exige `compileSdk/targetSdk 35` e AGP mais novo (mexer no Gradle/workflow); dataSync funciona com o alvo atual (34) e no Android 16. O serviço mantém o processo vivo e a notificação; o trabalho roda no `VideoEngine` (singleton do processo).
- Notificação persistente: "BetMC · convertendo vídeo", etapa + % real, "Processando em segundo plano", botão **Cancelar**; atualizada em tempo real (≤2×/s). Ao fim: some e, se o app não estiver visível, aparece "MCPACK pronto" (ou "não concluída"); tocar abre o app.
- Texto da notificação final: "gerado — toque para **verificar** e baixar". Motivo: a verificação de 14 itens roda em JS, que só existe com a tela; o nativo faz uma pré-verificação (CRC, manifest na raiz, todos os quadros) antes de avisar.
- Estado em disco (`filesDir`): etapa, progresso, resultado, plano, resumo. Ao voltar (ou tocar na notificação) a interface relê o estado e **nunca inicia conversão**; `busy` impede duplicidade. Pacote pronto fica disponível sem converter de novo.
- **Limpeza:** cancelamento e erro apagam tudo; o pacote concluído **fica no armazenamento interno do app (até ~400 MB)** até "Nova conversão", novo vídeo ou nova conversão. Ao fechar a Activity a conversão **não** é cancelada (antes era).
- Permissão `POST_NOTIFICATIONS` pedida ao iniciar (Android 13+); se negada, a conversão segue (o serviço roda, a notificação fica invisível). Opção ligar/desligar em Avançadas: **desligado = sem serviço e sem notificações; a conversão só é garantida com o app aberto.**
- **Sem promessa após parada forçada/morte do processo:** nesse caso o trabalho se perde; no próximo início o app mostra "A conversão foi interrompida…" e limpa os temporários. Retomar do meio não foi implementado.
- Proteção contra o erro do Android de parar o serviço antes de `startForeground`.

## 5. Testes executados (resultados reais)
| Suíte | Resultado |
|---|---|
| `node tests/video_tests.js` (lógica) | **135/135** — frames, recorte, rotação, plano+montagem+verificação em 7 combinações de N/FPS/resolução, pasta externa removida, UUIDs (2 exports + 2000 gerados), 14 cenários de falha que devem reprovar (inclui embrulhado, UUID reaproveitado/repetido/inválido) |
| `python3 tests/video_ui_test.py` (Chromium, nativo simulado) | **73/73** — somente a tela de conversão; diagnóstico oculto e abre com 7 toques (6 não); viewport/touch-action/bloqueio JS; rolagem (roda do mouse); seleção; avançadas fechada→aberta→fechada; fluxo completo com progresso real; MCPACK de saída correto (288 PNGs, loop, duração, manifest na raiz, UUIDs v4); 2 exportações diferentes; FPS/resoluções; vídeo vertical; erros (extração, escrita, espaço, verificação, pasta externa); cancelar (inclusive antes de o nativo iniciar); salvar cancelado/truncado; **voltar durante/depois/com pacote pronto/após encerramento**; sem 2ª conversão; permissão e liga/desliga de notificações; sem ponte Android |
| Núcleo existente | `run_tests.js` 56/56, `negative_tests.js` 3/3, `oracle.py` 18/18 pacotes — `core.js` idêntico à v3 |
Bugs achados pelos testes e corrigidos nesta rodada: nenhum no pacote; ajustes de teste (mock) apenas.

## 6. Arquivos modificados
**Alterados:** `www/index.html` (reescrito), `www/style.css` (reescrito), `www/video_ui.js` (reescrito), `www/video.js` (UUIDs, remoção da pasta externa, verificação 14 itens), `MainActivity.kt` (ponte, zoom, ciclo de vida), `VideoEngine.kt` (singleton, estado persistente, serviço, nomes sem pasta externa), `AndroidManifest.xml` (permissões + serviço), `package.json`, `README.md`, `tests/video_tests.js`, `tests/video_ui_test.py`.
**Novos:** `VideoService.kt` (serviço + notificações), `res/drawable/ic_stat_betmc.xml`, `RELATORIO_V4.md`.
**Removidos:** `www/app.js`, `tests/ui_test.py` (testes da interface antiga), `tools/` e `dist/` (versão "standalone" para navegador, sem função agora). Ficaram sem uso no Kotlin (inofensivos): `beginSave/writeChunk/endSave` e o seletor de arquivos do WebView.
**Idênticos à v3:** `core.js`, `build.gradle.kts`, `settings.gradle.kts`, pacote-base, ícones.

## 7. Funcionalidades preservadas
Extração por quadro, rotação, recorte central 16:9, redimensionamento, JSONs, grade de 31 colunas e numeração de 3 dígitos, loop, `pack_icon`/textura estática do 1º quadro, `$betmc_frame_duration`, pacote-base embutido, 14 verificações (eram 13), exportação SAF com conferência de bytes, processamento local, **sem permissão de INTERNET**.

## 8. build.yml e GitHub
Não foi alterado e deve continuar compatível: o `compileSdk/targetSdk 34`, `minSdk 24` e as dependências não mudaram; entram só um serviço, três permissões e um drawable. Passos: apague o ZIP antigo da raiz (o workflow pega o primeiro `*.zip`), envie `betmc-animation-converter-v4.zip`, aguarde o Actions; **se falhar, envie o log do passo de compilação** (risco principal: Kotlin não compilado). Depois teste no M34: converter 3 s a 12 FPS, minimizar, abrir outro app, observar a notificação, voltar, baixar.
