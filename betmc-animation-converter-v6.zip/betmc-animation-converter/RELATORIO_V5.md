# Relatório — BetMC v5 (Galeria, descrição sem créditos herdados, identidade roxa)

## 0. Limites do que foi verificado
- **O APK da V5 NÃO foi compilado nem executado em aparelho.** Sem Android SDK/Gradle/rede neste ambiente; o `build.yml` foi preservado e a compilação fica para o GitHub Actions. O Kotlin novo (ponte da Galeria, `onVideoUri`, cor das notificações, leitura de textos no resumo) foi revisado à mão e passou só no balanceamento de chaves/parênteses.
- Recebi o `BetMC_Converter_V4.apk` e o inspecionei apenas como arquivo (contém o pacote-base e o mesmo `video_ui.js` da V4); **não o executei**. Que a V4 funciona no aparelho é informação sua.
- **O Photo Picker real não foi aberto.** Nos testes a ponte Android é simulada (mock JS); eles provam que a interface chama a Galeria, recebe a URI/metadados e converte, não que o seletor do Android abre.

## 1. Inspeção da V4 (antes de mexer)
- **Seletor:** um botão → `OpenDocument("video/*")` (gerenciador de arquivos) → `VideoEngine.probe(uri)` → miniatura/duração/resolução; a mesma URI alimenta a conversão (`MediaMetadataRetriever`).
- **Descrição:** o pacote-base tem o crédito **só em `manifest.json` → `header.description`** ("TikTok: @betmc2411 […]"). Varri todos os arquivos de texto do pacote-base: não há outra ocorrência. O motivo da herança: `buildPlan` só sobrescrevia a descrição **se** o usuário preenchesse; vazio = mantinha a da base. A descrição do módulo (`";-;"`) não é crédito e foi mantida.
- **Identidade visual:** `www/style.css` (tokens), `index.html` (cores do tema, símbolos SVG), `styles.xml` (cor da janela/barras) e a cor das notificações.

## 2. GALERIA
- Botões **GALERIA** (Android Photo Picker: `PickVisualMedia.VideoOnly`) e **ARQUIVOS** (o seletor atual, mantido). Ambos chamam o mesmo `onVideoUri` → `probe` → mesma tela e mesmo processamento. Sem permissão de armazenamento (o Photo Picker não pede). Se a ponte não tiver `pickGallery` (APK antigo) o botão Galeria some em vez de ficar morto.
- Em aparelhos sem o Photo Picker, a biblioteca `activity` cai para o seletor de documentos (a "Galeria" vira o seletor de arquivos filtrado por vídeo).
- Observação técnica: URIs do Photo Picker não admitem permissão persistente; valem enquanto o processo viver (o Foreground Service mantém o processo). Se o processo morrer, o app pede para selecionar o vídeo de novo (mensagem já existente).
- **"Galeria dentro do gerenciador de arquivos":** o gerenciador padrão só lista as origens (provedores de documentos) instaladas no aparelho; um aplicativo de terceiros não consegue acrescentar "Galeria" a essa lista, e se algo assim aparece depende do fabricante/versão do gerenciador (não verifiquei no seu aparelho). A alternativa nativa mais confiável é o Photo Picker, que foi a implementada.

## 3. Descrição sem créditos herdados
Corrigido na **lógica de montagem** (`video.js › buildPlan`), não na tela:
- campo vazio (ou só espaços) → `header.description` **vazio ("")**; preenchido → **exatamente** o texto digitado (não é mais cortado nas pontas);
- o texto da base nunca é reaproveitado; se alguma descrição de módulo casar com o padrão do crédito, é esvaziada;
- nova verificação **"Descrição/créditos do pacote-base não aparecem em nenhum metadado"**: varre manifest, JSONs, `.lang`, `.txt`, `.md` do ZIP já gravado (o `VideoEngine` agora devolve também o texto de `.lang/.txt/.md`). Se o usuário digitar "TikTok…" por conta própria, é escolha dele e passa;
- a verificação do manifest exige descrição **igual** ao esperado (vazia ou o texto).
UUIDs, nome, versões, `min_engine_version`, módulos, subpacks e dependências seguem como antes.

## 4. Identidade visual roxa (estrutura e funcionalidades iguais)
Paleta nova em tokens: roxo claro `#b69cff` (principal) e `#9a7cff`, lavanda `#d6c8ff`, violeta `#7c5cf0`; fundos/superfícies violeta-escuros (`#0b0914`, `#151128`, `#1d1838`), texto `#f2edff`. Aplicada em **tudo**: fundo com brilho e grade sutis, cartões e bordas, logotipo, ícones, chips, botões primários (degradê lavanda→violeta, texto escuro), botões de origem, campos (foco), seletor/setas, chave de notificações, barra de progresso (lavanda→violeta com brilho), passos, selo de conclusão, painel de erro, diagnóstico, cor da janela/barras do Android e cor das notificações. Verdes/amarelo/vermelho de estado foram suavizados para combinar. Transições e animações mantidas, discretas. **Contraste medido (WCAG):** texto/fundo 14,8–17,2:1; texto secundário 6,9–8,0:1; texto fraco 4,8–5,3:1; destaque roxo sobre superfícies 7,4–8,6:1; botão primário 4,5:1+ nas duas pontas do degradê. Bordas de cartões/campos são deliberadamente discretas (baixo contraste de borda; os campos são distinguidos também pelo preenchimento). O ícone do app (launcher) não foi alterado.

## 5. Testes executados (resultados reais)
| Suíte | Resultado |
|---|---|
| `node tests/video_tests.js` | **182/182** — inclui, para descrição: 5 formas de "vazio", 5 textos preenchidos (aspas, acentos, espaços, 700+ caracteres, "TikTok" digitado pelo usuário), preservação dos demais metadados, e 3 cenários em que a verificação **reprova** crédito reintroduzido (manifest, `.lang`, módulo) |
| `python3 tests/video_ui_test.py` (Chromium) | **104/104** — tudo da V4 + Galeria (aciona a Galeria e não os arquivos; miniatura/duração/resolução girada/nome; conversão ponta a ponta; seletor antigo ainda funciona; cancelamento; erro amigável; sem botão morto; sem ponte), descrição (MCPACK exportado vazio e preenchido, inspecionando o ZIP real), paleta/contraste/matizes computados, ausência de ciano, responsivo 360 px e 412×915 sem rolagem horizontal |
| Núcleo existente | `run_tests` 56/56, `negative_tests` 3/3, `oracle` 18/18 |
Capturas de tela da interface em `tests/screenshots_v5/` (vazio, pronto, avançadas, convertendo, concluído, erro, diagnóstico, 360 px, 412 px).
**Regressão da V4** (nativo simulado): UUIDs únicos entre exportações, manifest na raiz, validação, estados convertendo/concluído/erro, cancelar, voltar ao app (durante/depois), notificações liga/desliga, bloqueio de zoom (meta/touch-action/JS), diagnóstico por 7 toques — todos passam.

## 6. NÃO testado (precisa do aparelho)
Photo Picker real e a entrega da URI ao `MediaMetadataRetriever`; Foreground Service/notificações na V5 (código não mudou, exceto a cor); gesto real de pinça; a aparência no AMOLED do M34; compilação do Kotlin.

## 7. Arquivos
**Modificados:** `www/video.js`, `www/video_ui.js`, `www/index.html`, `www/style.css`, `MainActivity.kt`, `VideoEngine.kt`, `VideoService.kt`, `res/values/styles.xml`, `tests/video_tests.js`, `tests/video_ui_test.py`, `README.md`.
**Criados:** `RELATORIO_V5.md`, `tests/screenshots_v5/*.png`.
**Idênticos à V4:** `core.js`, `build.gradle.kts`, `AndroidManifest.xml`, pacote-base, `build.yml` (não está no ZIP, não foi tocado).

## 8. Funcionalidades da V4 preservadas
Conversão vídeo→MCPACK, extração, rotação, recorte 16:9, redimensionamento, FPS/resolução, JSONs, grade de 31 colunas, numeração, loop, `pack_icon`/textura estática, duração, **UUIDs v4 únicos**, **manifest na raiz**, validação (agora 15 itens), exportação SAF com conferência de bytes, processamento 100% local sem INTERNET, Foreground Service, notificações, cancelamento, estado persistente e recuperação da interface, diagnóstico por 7 toques, bloqueio de zoom.

## 9. Compilar pelo GitHub Actions
Sem mudanças no Gradle nem no workflow: `PickVisualMedia` já vem no `activity-ktx 1.9.1` que o projeto usa. Passos: (1) apague o ZIP antigo da raiz do repositório (o workflow usa o primeiro `*.zip`); (2) envie `betmc-animation-converter-v5.zip`; (3) aguarde o Actions; se falhar, envie o log do passo de compilação. No aparelho, teste nesta ordem: GALERIA → converter 3 s a 12 FPS → exportar com descrição vazia e conferir no Minecraft → exportar com descrição → minimizar durante uma conversão.
