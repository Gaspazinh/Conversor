# Relatório da BETMC V6

Base: BETMC V5 (`betmc-animation-converter-v5.zip`, preservada sem alterações). Esta versão está em `betmc-animation-converter-v6.zip`.

## 0. Resumo honesto do que foi (e não foi) verificado
| Item | Estado |
|---|---|
| Lógica em JS/HTML/CSS (recorte, atualização, regra de nomes, interface) | **Testada** em Node e Chromium com a ponte Android **simulada** |
| Código Kotlin novo/alterado | **NÃO compilado e NÃO executado.** Só revisão manual (símbolos e chaves conferidos contra o código existente) |
| `build.yml` / `gerar-keystore.yml` | Sintaxe YAML validada e **auditoria estática** (`tests/workflow_audit.py`, 76/76) + `tests/backup_crypto_test.py` (51/51); **NÃO executados** no GitHub |
| Aparelho Android | **Nada foi testado em aparelho** |
| APK | **NÃO foi compilado** |
| Keystore | **NÃO foi criada** (será criada por você, pelo workflow de uso único) |
| Release | **Nada foi publicado** |

## 1. Diagnóstico da V5 (resumo)
WebView + shell Kotlin. JS: `core.js` (ZIP/conversão), `video.js` (plano/validação), `video_ui.js` (tela). Kotlin: `MainActivity` (ponte), `VideoEngine` (leitura do vídeo, montagem do ZIP, exportação SAF), `VideoService` (serviço em primeiro plano/notificações). Os `assets` são a própria pasta `www/` (arquivo novo em `www/` entra no APK sem mexer no Gradle). A V5 não tinha INTERNET, o `blockNetworkLoads` está ligado e o tempo dos quadros era fixo a partir de 0.
O `build.yml` compila `assembleDebug` (chave de debug nova a cada execução → APKs não se atualizam entre si). `versionCode` estava fixo em 1.

## 2. Alterações por funcionalidade
**A. Recorte manual** — `video.js` (`normalizeSelection`, `moveMarker`, `frameCountForSelection`, `fmtTime`, `frameTimeUs` com início; plano com `startMs/endMs`); `video_ui.js` (cartão, marcadores por Pointer Events/teclado/botões de 0,1 s, prévia, persistência); `VideoEngine.kt` (captura a partir de `startMs`, miniaturas, prévia, seleção persistida); `MainActivity.kt` (ponte). Sem escolha: comportamento idêntico ao da V5 (provado em teste). Limite de 12 s sem restringir ao começo; o limite empurra o outro marcador. Prévia: quadros reduzidos em loop **+ quadros exatos** de início e fim (mesmo método da conversão); a conversão usa sempre o vídeo original.
**B. INSTALAR NO MINECRAFT** — `PackInstaller.kt` (FileProvider em `files/share/`, `ACTION_VIEW`, permissão temporária de leitura, sem seletor forçado para permitir "padrão"); mensagens para Minecraft ausente / sem aplicativo / erro. Botão só habilita após a verificação do MCPACK. SALVAR/BAIXAR preservado.
**C. Textura-base** — `www/base/BetMC_UI_CORRIGIDO.mcpack` (SHA-256 `79b229c5…8b34904`, byte a byte; a "ORIGINAL" quebrada não foi usada). Cartão PRIMEIRA INSTALAÇÃO, INSTALAR TEXTURA-BASE, tutorial com esquema da ordem dos pacotes e a **captura real do Minecraft** (Recursos globais) fornecida por você, em `www/img/tutorial_ordem_pacotes.jpg` (redimensionada de 2340×1080 para 1170×540, sem cortes nem edições; original em `docs/img/`). O espaço reservado só reaparece se a imagem faltar. A legenda cita o pacote-base como o jogo o mostra (“BetMC UI — Menu Inicial”, igual ao manifest).
**D. Atualização** — `update.js` (validação e decisão, testável), `Updater.kt` (rede só aqui: update.json, download, SHA-256, tamanho, assinatura igual à instalada, pedido de instalação do Android), `v6_ui.js` (telas opcional/obrigatória, bloqueio, erros, cancelar). Obrigatória bloqueia as funções principais e a exigência fica guardada (vale offline). Links só de `github.com/Gaspazinh/Conversor/releases/download/`. Modelo `update.json` na raiz.
**E. Nomes técnicos** — `names.js` (`translate`, `assertUnchanged`), `REGRAS_DO_PROJETO.md`, testes (ex.: `mommy` fica `mommy` no manifest e no nome do arquivo). A V5 não tinha camada de tradução.
**Assinatura/Releases** — `build.yml` (passos originais intactos + passos só para tags `vX.Y.Z`), `gerar-keystore.yml` (uso único; uma execução por vez, checagem dupla contra sobrescrita, backup **cifrado e autenticado** (AES-256 + HMAC-SHA256) feito por `tools/betmc_backup.py`, que o workflow **executa do ZIP do projeto** (única cópia do código; nunca sobrescreve arquivos), com autoteste de adulteração e reabertura conferida antes de publicar, só o `.bkp` no artefato, publicado antes de gravar o Secret). O `build.yml` agora tem dois jobs: `build` com permissão só de leitura (compila, assina, confere) e `publicar`, o único com `contents: write`, que só baixa o artefato, reconfere e cria o rascunho; `BETMC_CERT_SHA256` é **obrigatória** para qualquer Release), Gradle (versão MAJOR.MINOR.PATCH → `versionCode` 60000; assinatura lida do ambiente; debug como antes), manifest (INTERNET, REQUEST_INSTALL_PACKAGES, FileProvider, `<queries>`), privacidade reescrita. Veja `docs/ASSINATURA_E_RELEASES.md`.

## 3. Arquivos
**Modificados (9):** `README.md`, `android/app/build.gradle.kts`, `android/app/src/main/AndroidManifest.xml`, `…/MainActivity.kt`, `…/VideoEngine.kt`, `www/index.html`, `www/style.css`, `www/video.js`, `www/video_ui.js`.
**Criados (17):** `REGRAS_DO_PROJETO.md`, `RELATORIO_V6.md`, `update.json`, `docs/ASSINATURA_E_RELEASES.md`, `…/PackInstaller.kt`, `…/Updater.kt`, `android/app/src/main/res/xml/file_paths.xml`, `www/base/BetMC_UI_CORRIGIDO.mcpack`, `www/names.js`, `www/update.js`, `www/v6_ui.js`, `tests/v6_tests.js`, `tests/v6_ui_test.py`, `tests/screenshots_v6/`, `www/img/tutorial_ordem_pacotes.jpg`, `docs/img/captura_original_minecraft_1001852262.jpg`, `docs/PLANO_TESTE_ATUALIZACAO.md`.
**Fora do ZIP (vão em `.github/workflows/` do repositório):** `build.yml` (modificado; linhas originais todas preservadas na mesma ordem) e `gerar-keystore.yml` (novo). Cópias de referência dentro do ZIP em `github-workflows/`. Também criados: `tests/workflow_audit.py`, `tests/backup_crypto_test.py`, `tools/betmc_backup.py`, `tests/fixtures_workflow/build.original.yml`.

## 4. Testes executados (nesta máquina)
| Suíte | Resultado |
|---|---|
| Núcleo `run_tests.js` / `negative_tests.js` / `oracle.py` | 56/56 · 3/3 · 18/18 (V5, sem regressão) |
| `video_tests.js` (V5) | 182/182 |
| `video_ui_test.py` (V5, Chromium) | 104/104 |
| `v6_tests.js` (novo, Node) | 96/96: recorte, atualização, nomes, textura-base, manifest/Gradle/Kotlin (conferência textual) |
| `v6_ui_test.py` (novo, Chromium, ponte simulada) | 67/67: marcadores, 12 s, prévia, persistência, instalar, primeira instalação, atualização opcional/obrigatória/offline/erros, layout 360 px |
Observação: `video_tests.js` precisa da pasta `tests/out_video/` (está no `.gitignore`); criei-a só no meu ambiente.

## 5. Problemas encontrados / decisões a confirmar
1. O ZIP da V5 não trazia `.github`; o `build.yml` veio depois. A V5 gera APKs de debug com chave diferente a cada build (ver docs) → desinstalação única na transição.
2. Tipo MIME do `ACTION_VIEW` do `.mcpack`: usei `application/octet-stream` com o nome `.mcpack`. **Não consegui confirmar o que o Minecraft registra**; se o aparelho não abrir, o ajuste é trocar o MIME/pacote em `PackInstaller.kt`.
3. Teste do botão: o pulso animado permanece em SALVAR (um teste da V5 o exige); INSTALAR é primário sem pulso.
4. `lint { checkReleaseBuilds = false }` no release, para o `lintVital` (que a V5 nunca rodou) não derrubar a Release por motivo alheio à assinatura.
5. Não adicionei `paths-ignore` ao `push`: cada commit do `update.json` dispara um build de debug (inofensivo) e evita mexer no gatilho.
6. Download de atualização não é retomável: se cair, apaga o parcial e recomeça.
7. Sem internet e sem exigência já conhecida, o app **não bloqueia** (falha aberta).
8. A limpeza de caracteres proibidos em nome de arquivo (`clean()` da V5) foi mantida; não é tradução.
9. A captura real mostra o caminho **Opções → Recursos globais**; o passo 2 do tutorial agora diz "Em Opções → Recursos globais (ou nas configurações do mundo)". No celular a imagem fica pequena (o texto do jogo mal se lê); a legenda e os passos carregam a informação.
10. Cartão "Primeira instalação" aparece na tela inicial e com vídeo escolhido; some durante/depois da conversão.

## 6. O que ainda precisa de teste em Android
Compilação do Kotlin e do APK no Actions · miniaturas e arrastar com o dedo em tela real · captura de quadros a partir de `startMs` em vários codecs/rotações (inclui vídeo vertical e o fim exato do vídeo) · tempo de geração da prévia · INSTALAR NO MINECRAFT (MIME, "Abrir com?", definir como padrão, Minecraft ausente) · INSTALAR TEXTURA-BASE e o resultado dentro do jogo · atualização completa (download real, SHA-256, tela de permissão "instalar apps", confirmação do Android, assinatura) · bloqueio obrigatório e offline · regressão de serviço em primeiro plano, notificações, cancelamento, exportação SAF · primeira Release assinada e conferência do certificado.

## 7. Compilar pelo GitHub Actions
1. Siga `docs/ASSINATURA_E_RELEASES.md` (4 Secrets: `BETMC_KEYSTORE_PASSWORD`, `BETMC_BACKUP_PASSPHRASE` (diferente), `BETMC_KEY_ALIAS`, `BETMC_ADMIN_TOKEN`; `gerar-keystore.yml`; variável `BETMC_CERT_SHA256`; **backup cifrado**; **remover o token**; como restaurar).
2. Troque o ZIP da raiz por `betmc-animation-converter-v6.zip` (**só um `.zip`** na raiz) e envie `.github/workflows/build.yml`.
3. Cada `push` continua gerando o APK de **debug** (`BetMC-APK`), como na V5 (assinatura de teste: não instalar por cima do oficial).
4. Para a versão assinada: tag `v6.0.0` → rascunho da Release com `BetMC-6.0.0.apk` e `update.json` → publicar → copiar o `update.json` para a `main`.

## 8. Instalar e testar
1. Desinstale a V5 (uma vez). 2. Instale o `BetMC-6.0.0.apk` da Release. 3. Teste na ordem da seção 6. 4. Para testar a atualização, publique depois uma 6.0.1 com `notes` e veja a tela opcional; depois marque `mandatory: true` para ver o bloqueio.
