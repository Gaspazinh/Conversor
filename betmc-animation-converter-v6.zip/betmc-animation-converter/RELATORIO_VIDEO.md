# Relatório — VÍDEO → MCPACK (função adicional)

## 0. Leia primeiro: o que foi e o que NÃO foi testado
- **O APK NÃO foi compilado e a função NÃO foi executada em Android.** Este ambiente não tem Android SDK, `kotlinc` nem rede. O código Kotlin (`VideoEngine.kt` e o trecho novo do `MainActivity.kt`) foi revisado à mão e passou só numa checagem de balanceamento de chaves/parênteses; **nunca foi compilado**. Pode haver erro de compilação que só o GitHub Actions vai revelar.
- **Nenhum vídeo real foi decodificado.** `MediaMetadataRetriever`, rotação, velocidade, uso de memória no Galaxy M34 e a gravação via SAF **não foram medidos nem observados**.
- **O `.mcpack` gerado não foi importado no Minecraft.**
- O que foi testado de verdade: toda a lógica em JavaScript (plano, JSONs, grade de offsets, validação) e a interface em Chromium, com o lado nativo **simulado** (ver §4).

## 1. O que foi feito (aditivo)
Nova aba **CONVERTER VÍDEO** ao lado do fluxo antigo, que ficou intacto. Fluxo: selecionar vídeo → ajustar FPS/resolução/nomes → **CONVERTER** (automático, sem confirmações) → barra de progresso real → 13 validações → **BAIXAR MCPACK PRONTO**.

| Parte | Arquivo | Função |
|---|---|---|
| Lógica pura | `www/video.js` | nº de frames, instantes, recorte central 16:9, plano a partir do pacote-base (reusa `BetmcCore.analyze/convert`), validação |
| Interface | `www/video_ui.js`, `index.html`, `style.css` | aba, cartões, progresso, cancelar, exportar |
| Nativo | `VideoEngine.kt` | lê vídeo, extrai quadros, rotação→recorte→escala, grava o ZIP em streaming, resume o ZIP gravado |
| Ponte | `MainActivity.kt` | `pickVideo`, `startVideoBuild`, `cancelVideo`, `exportVideoPack`, `baseChunk`… + `onDestroy` |
| Pacote-base | `www/base/Rebeca_Animation_CORRIGIDA.mcpack` | embutido no APK (usuário não escolhe nada) |

Comportamento conforme pedido: máx. 12 s (começa do início), 24 FPS padrão, PNG numerado com 3 dígitos (`ezgif-frame-001`…), loop (último `next` → `anim_1`), nomes de arquivo/exibição/descrição editáveis (vazios = nome do vídeo). **Rotação → recorte central 16:9 → 1280×720**, sem esticar. `pack_icon.png` (256×256) e `betmc_background_static_patch.png` (1920×1080) vêm do primeiro quadro, recortados para a proporção de cada um, **a partir do quadro em resolução cheia** (não do 720p).

Arquitetura do pacote-base preservada: namespace `betmc_animation_288`, grade de 31 colunas, `frame_N`/`anim_N`, subpacks `0` e `720`, UUIDs/versões. Além dos JSONs de animação, `$betmc_frame_duration` em `subpacks/720/betmc_config/config.json` também é atualizado para 1/FPS (o pedido não citava esse arquivo, mas ele controla a duração no jogo). Só `header.name` (e `header.description`, **apenas se você preencher**) muda no manifest; sem descrição, o crédito do pacote-base é mantido.

### Desvio consciente do pedido
Os PNGs **não são gravados em uma pasta temporária e depois compactados**: cada quadro é extraído e já entra no ZIP (em cache do app), um por vez. Isso evita dobrar o uso de disco (~400 MB) e a RAM fica em ~1 quadro. O resultado final é o mesmo.

## 2. Arquivos
**Novos:** `www/video.js`, `www/video_ui.js`, `www/base/Rebeca_Animation_CORRIGIDA.mcpack`, `android/.../VideoEngine.kt`, `tests/video_tests.js`, `tests/video_ui_test.py`, `tests/fixtures_video/…mcpack`, este relatório.
**Modificados (somente adições):** `www/index.html` (abas, 4 cartões, 2 `<script>`), `www/style.css` (estilos ao final), `MainActivity.kt` (launchers, métodos da ponte, `onDestroy`), `package.json` (scripts de teste), `tools/build_standalone.js`, `dist/betmc-standalone.html` (regenerado), `.gitignore`.
**Byte a byte idênticos ao original (verificado com `cmp`):** `www/core.js`, `www/app.js`, `android/app/build.gradle.kts`, `AndroidManifest.xml` (continua sem permissão INTERNET), `settings.gradle.kts`, ícones.

## 3. As 13 validações (todas bloqueiam a exportação)
ZIP legível com CRC recalculado de todos os arquivos · manifest na raiz do pacote-base com UUIDs/versões/`min_engine_version`/módulos intactos e nome atualizado · todos os JSONs válidos · quantidade de frames igual a N em `frame_N`, `anim_N`, controles, `textures_list`, `contents.json` e PNGs · todos os PNGs referenciados existem · nenhuma referência a arquivo inexistente · numeração contínua 1..N · `next` encadeado e último → primeiro · duração = 1/FPS (anim e config) e total ≤ 12 s · estática substituída (dimensões + CRC do gerado) · ícone válido e substituído · todos os frames PNG com a resolução escolhida · nenhum arquivo do pacote-base removido/alterado indevidamente. Se qualquer uma falhar: a exportação é interrompida, o arquivo temporário é apagado e a mensagem diz qual.

## 4. Testes executados (resultados reais)
| Suíte | Resultado | O que cobre |
|---|---|---|
| `node tests/video_tests.js` | **110/110** | frames (12 s, >12 s, curto), instantes, recorte 16:9 (vertical, quadrado, ultrawide, 4K), rotação, nomes; plano + montagem + validação para N=1/10/60/120/200/288/360 com FPS 10–30 e resoluções 640×360…1280×720; 288@24 gera JSONs **idênticos** aos do pacote-base; 11 cenários de falha que **devem reprovar** (PNG faltando/sobrando, ícone inválido, estática com tamanho errado, loop quebrado, duração errada, JSON inválido, arquivo do pacote removido, UUID alterado, frame com resolução errada, CRC ruim) |
| `python3 tests/video_ui_test.py` (Chromium, toque) | **34/34** | aba, prévia/duração, padrões, fluxo completo sem confirmações, vídeo >12 s → 288 frames, outros FPS/resoluções, vídeo vertical girado, falha de extração, falha de escrita, validação reprovando, cancelar (inclusive antes de o nativo iniciar), salvar cancelado, bytes divergentes, sem ponte Android, e **o fluxo MCPACK → MCPACK ainda funcionando** |
| Testes **existentes** | **todos continuam OK:** `run_tests.js` 56/56, `negative_tests.js` 3/3, `oracle.py` 27/27 pacotes, `ui_test.py` 49/49 | confirma que nada do conversor atual quebrou |

Nesses testes o "nativo" é um **simulador** (mock JS da ponte + montador em Python que segue o contrato do Kotlin). Eles provam a interface, o plano e a validação; **não provam o Kotlin**.
Bugs reais achados e corrigidos por esses testes: caminho dos PNGs sem as pastas `betmc_background/betmc_background_frame/`; `contents.json` usa caminhos relativos à pasta do manifest; cancelar durante a preparação era ignorado.

**Não testado (precisa do seu aparelho):** compilação do Kotlin; decodificação real (H.264/HEVC/HDR); a rotação (o app gira o quadro só se o Android o entregar sem girar — **rotação 180° e vídeos quadrados não dá para distinguir por dimensões; assumi que o Android já girou**); **velocidade** (`getFrameAtTime` quadro a quadro pode levar de ~1 a vários minutos para 288 quadros, sobretudo com GOP longo; se for lento, o próximo passo é decodificação sequencial com `MediaCodec`); RAM em vídeos 4K; espaço livre (há checagem prévia); exportação SAF; importação no Minecraft.

## 5. Riscos e observações
- **Tamanho:** ~1,4 MB/frame a 1280×720 → ~400 MB para 288 frames (opções 960×540, 854×480 e 640×360 reduzem). O pacote-base original já é 720p24.
- O manifest do pacote-base fica numa **pasta dentro do ZIP** (`Rebeca_Animation__FIXado120/`); mantive como está, conforme a instrução de preservar a estrutura.
- O nome do subpack ("720p24 Quality") e do pacote-base não são alterados; com FPS ≠ 24 o rótulo do subpack fica impreciso (a duração real está correta).
- Vídeo sem faixa de vídeo, codec não suportado ou quadro ilegível: a conversão **para** com erro específico; nada é duplicado nem inventado.

## 6. build.yml
Não foi alterado e continua compatível: ele descompacta o **primeiro** `*.zip` da raiz do repositório, localiza `settings.gradle.kts` e roda `gradle assembleDebug`. A estrutura `android/` e o `assets.srcDirs("../../www")` não mudaram (os novos `video*.js` e `base/` entram como assets automaticamente); não há dependência nova no Gradle, logo não há download extra no build.

## 7. Como atualizar no GitHub
1. No repositório, **apague o ZIP antigo** da raiz (`betmc-animation-converter-v2-icon.zip`). Importante: o workflow usa `ls *.zip | head -1` e pegaria o antigo (ordem alfabética).
2. Envie `betmc-animation-converter-v3-video.zip` para a raiz (Add file → Upload files) e faça commit.
3. O Actions compila sozinho (`push`). Se falhar, **envie o log do passo "Compilar"**: o ponto mais provável de erro é o Kotlin, que não pôde ser compilado aqui.
4. Instale `BetMC-APK`, abra **CONVERTER VÍDEO**, teste primeiro com um vídeo de ~3 s a 12 FPS e meça o tempo antes do de 12 s.
