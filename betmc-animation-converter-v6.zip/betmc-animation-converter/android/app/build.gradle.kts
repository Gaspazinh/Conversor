plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
// Versão: MAJOR.MINOR.PATCH → versionCode = MAJOR*10000 + MINOR*100 + PATCH (sempre crescente; o atualizador compara este número).
// A tag do GitHub Release deve ser "v" + versionName (o workflow confere).
val vMajor = 6; val vMinor = 0; val vPatch = 1
// Assinatura definitiva (release): lida de variáveis de ambiente, que o workflow preenche com GitHub Secrets. Nada de senha ou chave neste código.
val ksPath: String? = System.getenv("BETMC_KEYSTORE_PATH")
val ksPass: String? = System.getenv("BETMC_KEYSTORE_PASSWORD")
val ksAlias: String? = System.getenv("BETMC_KEY_ALIAS")
val hasReleaseKey = !ksPath.isNullOrBlank() && !ksPass.isNullOrBlank() && !ksAlias.isNullOrBlank()

android {
    namespace = "com.betmc.converter"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.betmc.converter"
        minSdk = 24            // WebView do Android 7+ (CompressionStream exige WebView/Chrome 80+; há fallback sem compressão)
        targetSdk = 34
        versionCode = vMajor * 10000 + vMinor * 100 + vPatch
        versionName = "$vMajor.$vMinor.$vPatch"
    }
    signingConfigs {
        if (hasReleaseKey) create("release") {
            storeFile = file(ksPath!!); storeType = "PKCS12"
            storePassword = ksPass; keyAlias = ksAlias; keyPassword = ksPass
        }
    }
    buildTypes {
        // debug: continua como na V5 (chave de debug do ambiente). release: chave definitiva, só quando as variáveis existem.
        release { isMinifyEnabled = false; if (hasReleaseKey) signingConfig = signingConfigs.getByName("release") }
    }
    // Evita que a verificação "lintVital" do build release (nunca usada na V5, que só compila debug) quebre a Release por motivos alheios à assinatura.
    lint { checkReleaseBuilds = false }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    // Os mesmos arquivos de ../www viram os assets do app (sem duplicar código).
    sourceSets { getByName("main") { assets.srcDirs("../../www") } }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
}
