package com.betmc.converter

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest

/** Resultado do preparo de uma abertura: com [intent] ela será disparada na thread da interface; sem [intent] só relata o erro. */
class Prepared(val intent: Intent?, val ok: Boolean, val code: String, val msg: String) {
    fun json(): String = JSONObject().put("ok", ok).put("code", code).put("msg", msg).toString()
}

/**
 * INSTALAR NO MINECRAFT: entrega um .mcpack ao Android por URI de conteúdo (FileProvider) com permissão TEMPORÁRIA de leitura.
 * Não instala nada em silêncio e não contorna confirmações: o Android mostra "Abrir com?" quando preciso; se o usuário marcar o
 * Minecraft como padrão, as próximas aberturas são diretas. Só as pastas files/share e files/update são expostas (res/xml/file_paths.xml).
 * Divisão: [prepareOpen]/[prepareBase] copiam arquivos (thread de fundo); [launch] dispara o Intent (thread da interface).
 */
object PackInstaller {
    const val MINECRAFT_PKG = "com.mojang.minecraftpe"
    /** Textura-base embutida (assets/base): copiada byte a byte; o SHA-256 confere que o arquivo do APK não foi alterado. */
    const val BASE_ASSET = "base/BetMC_UI_CORRIGIDO.mcpack"
    const val BASE_NAME = "BetMC_UI_CORRIGIDO.mcpack"
    const val BASE_SHA256 = "79b229c56abf09e315d857a8b8d0dcffcf53dcf13f98625511a08bdf78b34904"

    fun authority(c: Context) = c.packageName + ".fileprovider"
    private fun shareDir(c: Context) = File(c.filesDir, "share").apply { mkdirs() }
    private fun fail(code: String, msg: String) = Prepared(null, false, code, msg)

    @Suppress("DEPRECATION")
    fun minecraftInstalled(c: Context): Boolean = try {
        if (android.os.Build.VERSION.SDK_INT >= 33) c.packageManager.getPackageInfo(MINECRAFT_PKG, PackageManager.PackageInfoFlags.of(0L))
        else c.packageManager.getPackageInfo(MINECRAFT_PKG, 0)
        true
    } catch (_: Exception) { false }

    /** Copia o pacote para files/share/<nome>.mcpack (o Minecraft reconhece o arquivo pela extensão do nome) e monta o Intent de abertura. */
    fun prepareOpen(c: Context, source: File, displayName: String): Prepared {
        if (!minecraftInstalled(c)) return fail("no_minecraft", "O Minecraft não foi encontrado neste aparelho. Instale o Minecraft (Bedrock) e tente de novo. Se você usa outra edição, use SALVAR e abra o arquivo por ela.")
        val name = if (displayName.endsWith(".mcpack", true)) displayName else "$displayName.mcpack"
        val dest = File(shareDir(c), name)
        try {
            shareDir(c).listFiles()?.forEach { if (it.name != name) it.delete() }   // mantém só o pacote atual
            if (source.absolutePath != dest.absolutePath) {
                FileInputStream(source).use { i -> FileOutputStream(dest).use { o -> i.copyTo(o, 1 shl 16) } }
            }
            if (dest.length() != source.length()) { dest.delete(); return fail("copy", "Não foi possível preparar o arquivo para abrir. Verifique o espaço livre e tente de novo.") }
        } catch (e: Exception) { return fail("copy", "Não foi possível preparar o arquivo para abrir: ${e.message}") }
        val uri = try { FileProvider.getUriForFile(c, authority(c), dest) } catch (e: Exception) { return fail("provider", "O Android não liberou o arquivo para outro aplicativo.") }
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/octet-stream")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)       // permissão temporária só de leitura
            clipData = ClipData.newRawUri(name, uri)              // garante o repasse da permissão em versões antigas
        }
        return Prepared(i, true, "launched", "Abrindo no Minecraft. Confirme a importação no jogo.")
    }

    /** Textura-base: copia o asset e confere o SHA-256 antes de abrir. */
    fun prepareBase(c: Context): Prepared {
        val dest = File(shareDir(c), BASE_NAME)
        try {
            val md = MessageDigest.getInstance("SHA-256")
            shareDir(c).listFiles()?.forEach { if (it.name != BASE_NAME) it.delete() }
            c.assets.open(BASE_ASSET).use { i -> FileOutputStream(dest).use { o -> val b = ByteArray(1 shl 16); while (true) { val r = i.read(b); if (r < 0) break; o.write(b, 0, r); md.update(b, 0, r) } } }
            val got = md.digest().joinToString("") { "%02x".format(it) }
            if (got != BASE_SHA256) { dest.delete(); return fail("base_corrupt", "A textura-base dentro do aplicativo está diferente do esperado. Reinstale o BetMC.") }
        } catch (e: Exception) { return fail("base_missing", "A textura-base não foi encontrada dentro do aplicativo: ${e.message}") }
        return prepareOpen(c, dest, BASE_NAME)
    }

    /** Dispara o Intent preparado. Chamar na thread da interface. Retorna o JSON {ok, code, msg} para a página. */
    fun launch(a: Activity, p: Prepared): String {
        val i = p.intent ?: return p.json()
        return try { a.startActivity(i); p.json() }
        catch (_: ActivityNotFoundException) { Prepared(null, false, "no_handler", "Nenhum aplicativo deste aparelho conseguiu abrir o arquivo. Use SALVAR e abra o arquivo pelo gerenciador de arquivos.").json() }
        catch (e: SecurityException) { Prepared(null, false, "security", "O Android recusou abrir o arquivo (${e.message}).").json() }
    }
}
