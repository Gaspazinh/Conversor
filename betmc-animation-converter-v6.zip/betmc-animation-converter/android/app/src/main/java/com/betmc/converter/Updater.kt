package com.betmc.converter

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Atualização da BetMC pelo GitHub (rede usada SOMENTE aqui; vídeos e texturas nunca são enviados).
 *  - consulta update.json (raw.githubusercontent.com/Gaspazinh/Conversor/main) por HTTPS;
 *  - baixa o APK de GitHub Releases para files/update/ (pasta privada do app: nenhum arquivo do usuário é tocado);
 *  - confere tamanho e SHA-256 ANTES de liberar a instalação, e confere se a assinatura do APK é a mesma do app instalado;
 *  - pede ao Android a confirmação de instalação (nunca instala em silêncio).
 * A decisão (versão mais nova / mínima / obrigatória) é tomada em www/update.js e testada em Node; aqui só há rede, arquivos e Android.
 */
object Updater {
    const val UPDATE_URL = "https://raw.githubusercontent.com/Gaspazinh/Conversor/main/update.json"
    private const val APK_PREFIX = "https://github.com/Gaspazinh/Conversor/releases/download/"
    private const val MAX_JSON = 64 * 1024
    private const val MAX_APK = 250L * 1024 * 1024
    private val SHA_RE = Regex("^[0-9a-f]{64}$")

    private fun updDir(c: Context) = File(c.filesDir, "update").apply { mkdirs() }
    private fun result(ok: Boolean, code: String, msg: String) = JSONObject().put("ok", ok).put("code", code).put("msg", msg)

    @Suppress("DEPRECATION")
    fun current(c: Context): Pair<Long, String> {
        val pi = if (Build.VERSION.SDK_INT >= 33) c.packageManager.getPackageInfo(c.packageName, PackageManager.PackageInfoFlags.of(0L))
        else c.packageManager.getPackageInfo(c.packageName, 0)
        return Pair(PackageInfoCompat.getLongVersionCode(pi), pi.versionName ?: "?")
    }

    private fun hostAllowed(u: URL): Boolean {
        val h = u.host.lowercase()
        return u.protocol == "https" && (h == "github.com" || h == "raw.githubusercontent.com" || h.endsWith(".githubusercontent.com"))
    }

    private fun open(url: String): HttpURLConnection {
        val u = URL(url)
        if (!hostAllowed(u)) throw IllegalStateException("endereço não permitido")
        val cn = u.openConnection() as HttpURLConnection
        cn.connectTimeout = 10_000; cn.readTimeout = 20_000; cn.instanceFollowRedirects = true
        cn.setRequestProperty("Cache-Control", "no-cache"); cn.setRequestProperty("User-Agent", "BetMC-Updater")
        return cn
    }

    /** Baixa o update.json e devolve {ok, code, msg, text, currentCode, currentName}. Não decide nada. */
    fun fetch(c: Context): String {
        val cur = current(c)
        val o = result(true, "fetched", "").put("currentCode", cur.first).put("currentName", cur.second)
        return try {
            val cn = open(UPDATE_URL)
            try {
                if (cn.responseCode != 200) return o.put("ok", false).put("code", "http").put("msg", "O servidor respondeu ${cn.responseCode}.").toString()
                if (!hostAllowed(cn.url)) return o.put("ok", false).put("code", "host").put("msg", "Resposta de endereço não permitido.").toString()
                val out = java.io.ByteArrayOutputStream()
                cn.inputStream.use { i -> val b = ByteArray(8192); var n: Int; while (i.read(b).also { n = it } >= 0) { out.write(b, 0, n); if (out.size() > MAX_JSON) throw IllegalStateException("arquivo de atualização grande demais") } }
                o.put("text", String(out.toByteArray(), Charsets.UTF_8)).toString()
            } finally { cn.disconnect() }
        } catch (e: java.io.IOException) { o.put("ok", false).put("code", "network").put("msg", "Sem conexão com a internet ou o GitHub não respondeu.").toString() }
        catch (e: Exception) { o.put("ok", false).put("code", "error").put("msg", e.message ?: e.toString()).toString() }
    }

    /**
     * Baixa o APK. Retorna o arquivo verificado (tamanho e SHA-256 conferem) ou lança IllegalStateException com a mensagem para o usuário.
     * Download interrompido: o arquivo parcial é apagado e o usuário tenta de novo (não há retomada).
     */
    fun download(c: Context, url: String, sha256: String, size: Long, fileName: String, progress: (Double) -> Unit, cancelled: () -> Boolean): File {
        if (!url.startsWith(APK_PREFIX)) throw IllegalStateException("Endereço do APK não permitido.")
        if (!SHA_RE.matches(sha256.lowercase())) throw IllegalStateException("O arquivo de atualização não traz um SHA-256 válido.")
        val safe = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifEmpty { "BetMC-update.apk" }
        val dir = updDir(c)
        dir.listFiles()?.forEach { it.delete() }                     // só apaga o que é nosso (files/update)
        val part = File(dir, "$safe.part"); val apk = File(dir, safe)
        try {
            val cn = open(url)
            try {
                if (cn.responseCode != 200) throw IllegalStateException("O download falhou (resposta ${cn.responseCode}).")
                if (!hostAllowed(cn.url)) throw IllegalStateException("O download foi redirecionado para um endereço não permitido.")
                val total = cn.contentLengthLong.let { if (it > 0) it else size }
                if (total > MAX_APK || size > MAX_APK) throw IllegalStateException("O arquivo de atualização é grande demais.")
                if (dir.usableSpace < maxOf(total, size) + 16L * 1024 * 1024) throw IllegalStateException("Espaço insuficiente para baixar a atualização.")
                val md = MessageDigest.getInstance("SHA-256"); var got = 0L
                cn.inputStream.use { i -> FileOutputStream(part).use { o ->
                    val b = ByteArray(1 shl 16)
                    while (true) {
                        if (cancelled()) throw IllegalStateException("Download cancelado.")
                        val n = i.read(b); if (n < 0) break
                        o.write(b, 0, n); md.update(b, 0, n); got += n
                        if (total > 0) progress(got.toDouble() / total)
                    }
                    o.flush()
                } }
                if (size > 0 && got != size) throw IllegalStateException("O download ficou incompleto ($got de $size bytes). Tente de novo.")
                val hex = md.digest().joinToString("") { "%02x".format(it) }
                if (hex != sha256.lowercase()) throw IllegalStateException("O arquivo baixado não confere com o SHA-256 publicado. Ele foi descartado por segurança.")
            } finally { cn.disconnect() }
            if (!part.renameTo(apk)) throw IllegalStateException("Não foi possível guardar o arquivo baixado.")
            return apk
        } catch (e: IllegalStateException) { part.delete(); apk.delete(); throw e }
        catch (e: java.io.IOException) { part.delete(); apk.delete(); throw IllegalStateException("A conexão foi interrompida durante o download. Tente de novo.") }
    }

    @Suppress("DEPRECATION")
    private fun certs(pi: android.content.pm.PackageInfo): Set<String> {
        val sigs: Array<android.content.pm.Signature>? =
            if (Build.VERSION.SDK_INT >= 28) pi.signingInfo?.apkContentsSigners else pi.signatures
        return (sigs ?: emptyArray()).map { MessageDigest.getInstance("SHA-256").digest(it.toByteArray()).joinToString("") { b -> "%02x".format(b) } }.toSet()
    }

    /** Confere pacote, versão e assinatura do APK baixado contra o app instalado. Retorna null se estiver tudo certo, senão a mensagem. */
    @Suppress("DEPRECATION")
    fun checkCompatible(c: Context, apk: File): String? {
        val pm = c.packageManager
        val flag = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        val arc = pm.getPackageArchiveInfo(apk.absolutePath, flag) ?: return "O arquivo baixado não é um APK válido."
        if (arc.packageName != c.packageName) return "O APK baixado é de outro aplicativo."
        val cur = current(c)
        if (PackageInfoCompat.getLongVersionCode(arc) <= cur.first) return "O APK baixado não é mais novo que a versão instalada."
        val mine = certs(pm.getPackageInfo(c.packageName, flag)); val theirs = certs(arc)
        if (mine.isEmpty() || theirs.isEmpty() || mine != theirs)
            return "A assinatura do APK novo é diferente da versão instalada, então o Android não permitiria atualizar por cima. Desinstale o BetMC uma vez e instale a versão nova (veja o guia de atualização)."
        return null
    }

    /** Prepara o pedido de confirmação de instalação ao Android (nunca instala em silêncio). Códigos: launched | needs_permission | incompatible | missing | error. */
    fun prepareInstall(c: Context, apk: File): Prepared {
        if (!apk.exists()) return Prepared(null, false, "missing", "O arquivo da atualização não está mais disponível. Baixe de novo.")
        checkCompatible(c, apk)?.let { return Prepared(null, false, "incompatible", it) }
        if (Build.VERSION.SDK_INT >= 26 && !c.packageManager.canRequestPackageInstalls())
            return Prepared(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + c.packageName)), false, "needs_permission", "Permita que o BetMC instale aplicativos e volte para continuar.")
        return try {
            val uri = FileProvider.getUriForFile(c, PackInstaller.authority(c), apk)
            val i = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                clipData = android.content.ClipData.newRawUri(apk.name, uri)
            }
            Prepared(i, true, "launched", "O Android vai pedir a confirmação da instalação.")
        } catch (e: Exception) { Prepared(null, false, "error", "Não foi possível abrir o instalador: ${e.message}") }
    }

    /** Arquivo da atualização já baixado e verificado, se existir (para reinstalar sem baixar de novo). */
    fun downloaded(c: Context): File? = updDir(c).listFiles()?.firstOrNull { it.name.endsWith(".apk") }

    fun cleanup(c: Context) { updDir(c).listFiles()?.forEach { it.delete() } }
}
