package com.betmc.converter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Motor NATIVO de VÍDEO → MCPACK (100% offline, sem bibliotecas externas).
 *
 * Divisão de trabalho (contrato com www/video.js):
 *  - JS decide TUDO que é lógica do pacote (JSONs, caminhos, quantidade de frames) a partir do pacote-base e do core.js;
 *  - Kotlin só faz o que o WebView não faz bem: decodificar o vídeo, recortar/redimensionar, gravar o ZIP em streaming
 *    (um quadro por vez, memória baixa) e devolver um RESUMO do ZIP gravado para o JS validar.
 *
 * Ordem geométrica de cada quadro (conforme pedido): rotação → recorte central 16:9 → redimensionamento.
 */
class VideoEngine private constructor(private val ctx: Context) {
    companion object {
        @Volatile private var inst: VideoEngine? = null
        /** Instância única por processo: sobrevive ao fechamento da Activity (o Foreground Service mantém o processo vivo). */
        fun get(c: Context): VideoEngine = inst ?: synchronized(this) { inst ?: VideoEngine(c.applicationContext).also { inst = it } }
        @Volatile var appVisible = false
    }

    private val tag = "BetMC-Video"
    private val exec = Executors.newSingleThreadExecutor()
    private val cancelled = AtomicBoolean(false)
    private val busy = AtomicBoolean(false)
    @Volatile var listener: ((String) -> Unit)? = null   // executa JS na página (null quando a Activity não existe)
    private var baseCache: ByteArray? = null
    @Volatile private var serviceOn = false
    private var lastNotifAt = 0L
    private var lastPersistAt = 0L

    // ---- estado persistente (reconstrói a interface depois que o usuário volta)
    private var status = "idle"          // idle | running | built (gravado, aguardando verificação) | ready (verificado) | error
    private var stage = ""
    private var progress = 0.0
    private var outName = ""
    private var errorMsg = ""
    private var frames = 0
    private var videoJson: JSONObject? = null
    private var uriStr = ""
    private var selStart = -1L           // recorte manual (ms); -1 = não escolhido (padrão: início do vídeo, até 12 s)
    private var selEnd = -1L

    private fun f(name: String) = File(ctx.filesDir, name)
    private val outFile: File get() = f("video_out.mcpack")

    private class Stop : RuntimeException()
    private class Fail(msg: String) : RuntimeException(msg)

    private fun q(s: String) = JSONObject.quote(s)
    private fun post(code: String) { listener?.invoke(code) }
    private fun call(fn: String, arg: String) = post("window.$fn&&window.$fn($arg)")

    init { loadState() }

    @Synchronized private fun persist() {
        lastPersistAt = System.currentTimeMillis()
        try {
            val o = JSONObject().put("status", status).put("stage", stage).put("progress", progress).put("outName", outName)
                .put("error", errorMsg).put("frames", frames).put("uri", uriStr)
                .put("selStart", selStart).put("selEnd", selEnd)
            videoJson?.let { o.put("video", it) }
            val tmp = f("video_state.json.tmp")
            tmp.writeText(o.toString())
            if (!tmp.renameTo(f("video_state.json"))) { f("video_state.json").writeText(o.toString()); tmp.delete() }
        } catch (e: Exception) { Log.w(tag, "não salvou o estado", e) }
    }

    @Synchronized private fun loadState() {
        try {
            val sf = f("video_state.json")
            if (!sf.exists()) return
            val o = JSONObject(sf.readText())
            status = o.optString("status", "idle"); stage = o.optString("stage"); progress = o.optDouble("progress", 0.0)
            outName = o.optString("outName"); errorMsg = o.optString("error"); frames = o.optInt("frames"); uriStr = o.optString("uri")
            selStart = o.optLong("selStart", -1L); selEnd = o.optLong("selEnd", -1L)
            videoJson = o.optJSONObject("video")
            if (status == "running") { // o processo morreu no meio: o trabalho em andamento NÃO pode ser retomado
                cleanupFiles()
                status = "error"
                errorMsg = "A conversão foi interrompida (o aplicativo foi encerrado ou o sistema parou o processamento). Toque em CONVERTER para tentar de novo."
                persist()
            } else if ((status == "built" || status == "ready") && !outFile.exists()) {
                status = "idle"; persist()
            }
        } catch (e: Exception) { Log.w(tag, "estado ilegível; reiniciando", e); status = "idle" }
    }

    private fun cleanupFiles() { outFile.delete(); f("video_plan.json").delete(); f("video_summary.json").delete() }
    private fun currentUri(): Uri? = if (uriStr.isEmpty()) null else Uri.parse(uriStr)

    /** Estado para a interface (chamado ao abrir/voltar ao app). Nunca inicia nada. */
    @Synchronized fun stateJson(): String {
        val o = JSONObject().put("status", status).put("stage", stage).put("progress", progress).put("outName", outName)
            .put("error", errorMsg).put("frames", frames).put("selStart", selStart).put("selEnd", selEnd).put("hasFile", outFile.exists()).put("fileSize", if (outFile.exists()) outFile.length() else 0L)
            .put("notifEnabled", VideoNotifier.enabled(ctx)).put("notifAllowed", VideoNotifier.canPost(ctx))
        videoJson?.let { o.put("video", it) }
        if (status == "built") {
            try { o.put("plan", f("video_plan.json").readText()); o.put("summary", f("video_summary.json").readText()) } catch (e: Exception) { Log.w(tag, "sem plano/resumo", e) }
        }
        return o.toString()
    }

    /** A interface verificou o pacote (14 verificações em JS). ok=false → apaga o arquivo e guarda o motivo. */
    @Synchronized fun reportValidation(ok: Boolean, msg: String) {
        if (status != "built") return
        if (ok) { status = "ready"; progress = 1.0; stage = "Pronto" }
        else { cleanupFiles(); status = "error"; errorMsg = msg }
        persist()
    }

    /** Guarda o trecho escolhido (ms) para a interface ser reconstruída ao voltar ao app. */
    @Synchronized fun setSelection(startMs: Long, endMs: Long) { selStart = startMs; selEnd = endMs; persist() }

    /** "Nova conversão": descarta o pacote pronto (só se não houver conversão em andamento). */
    @Synchronized fun reset() {
        if (busy.get()) return
        cleanupFiles(); status = "idle"; stage = ""; progress = 0.0; errorMsg = ""; persist()
    }

    /* ------------------------------------------------------------------ pacote-base (asset) */
    @Synchronized private fun base(asset: String): ByteArray {
        val c = baseCache
        if (c != null) return c
        val b = ctx.assets.open(asset).use { it.readBytes() }
        baseCache = b
        return b
    }
    fun baseSize(asset: String): Int = base(asset).size
    fun baseChunk(asset: String, index: Int, chunk: Int): String {
        val b = base(asset)
        val from = index * chunk
        if (from >= b.size) return ""
        val to = minOf(b.size, from + chunk)
        return Base64.encodeToString(b, from, to - from, Base64.NO_WRAP)
    }

    /* ------------------------------------------------------------------ geometria (espelha centerCrop de video.js) */
    private object Geo {
        /** [x, y, w, h] do recorte central com proporção tw:th, sem deformar. */
        fun centerCrop(sw: Int, sh: Int, tw: Int, th: Int): IntArray =
            if (sw.toLong() * th > sh.toLong() * tw) {
                val w = maxOf(1L, (sh.toLong() * tw) / th).toInt()
                intArrayOf((sw - w) / 2, 0, w, sh)
            } else {
                val h = maxOf(1L, (sw.toLong() * th) / tw).toInt()
                intArrayOf(0, (sh - h) / 2, sw, h)
            }
    }

    /** Lê quadros e entrega sempre na orientação correta (rotação aplicada exatamente uma vez). */
    private class Grabber(private val r: MediaMetadataRetriever, rawW: Int, rawH: Int, private val rot: Int) {
        private val swap = rot % 180 == 90
        private val expW = if (swap) rawH else rawW
        private val expH = if (swap) rawW else rawH
        /** sync=true usa o keyframe mais próximo (rápido; só para miniaturas). A conversão e as imagens de início/fim usam o quadro exato. */
        fun at(timeUs: Long, sync: Boolean = false): Bitmap? {
            val raw = (if (sync) r.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) else r.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST))
                ?: r.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: return null
            return upright(raw)
        }

        /**
         * O Android costuma entregar o quadro JÁ girado (API recente). Se vier nas dimensões "cruas" de um vídeo
         * com rotação 90/270, giramos aqui. Rotação 180 e vídeos quadrados não são distinguíveis por dimensão:
         * assume-se que o framework já aplicou (limitação documentada).
         */
        private fun upright(b: Bitmap): Bitmap {
            if (swap && expW != expH && b.width == expH && b.height == expW) {
                val m = Matrix().apply { postRotate(rot.toFloat()) }
                val g = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
                if (g !== b) b.recycle()
                return g
            }
            return b
        }
    }

    private fun scaleTo(src: Bitmap, w: Int, h: Int): Bitmap {
        var cur = src
        while (cur.width >= w * 2 && cur.height >= h * 2) { // reduz em passos de 1/2: evita serrilhado
            val n = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (cur !== src) cur.recycle()
            cur = n
        }
        if (cur.width != w || cur.height != h) {
            val n = Bitmap.createScaledBitmap(cur, w, h, true)
            if (cur !== src) cur.recycle()
            cur = n
        }
        return cur
    }

    private fun cropTo(src: Bitmap, tw: Int, th: Int): Bitmap {
        val c = Geo.centerCrop(src.width, src.height, tw, th)
        return if (c[0] == 0 && c[1] == 0 && c[2] == src.width && c[3] == src.height) src
        else Bitmap.createBitmap(src, c[0], c[1], c[2], c[3])
    }

    private fun pngBytes(b: Bitmap, opaque: Boolean): ByteArray {
        if (opaque) b.setHasAlpha(false) // PNG RGB (sem canal alfa), como os frames do pacote-base
        val bo = ByteArrayOutputStream(1 shl 20)
        if (!b.compress(Bitmap.CompressFormat.PNG, 100, bo)) throw Fail("Falha ao codificar PNG.")
        return bo.toByteArray()
    }

    private fun crcOf(b: ByteArray): Long { val c = CRC32(); c.update(b); return c.value }

    /** Imagem derivada do quadro já recortado em 16:9 (full-res): recorta para a proporção do alvo e redimensiona. */
    private fun derived(cropped16x9: Bitmap, w: Int, h: Int, opaque: Boolean): ByteArray {
        val c = cropTo(cropped16x9, w, h)
        val s = scaleTo(c, w, h)
        try { return pngBytes(s, opaque) } finally {
            if (s !== cropped16x9) s.recycle()
            if (c !== cropped16x9 && c !== s) c.recycle()
        }
    }

    private class FirstAssets(val icon: ByteArray, val stat: ByteArray, val frame1: ByteArray)

    /** Do primeiro quadro (já girado): recorte 16:9 → frame 1, imagem estática e ícone. Libera o bitmap recebido. */
    private fun firstFrameAssets(first: Bitmap, outW: Int, outH: Int, iconW: Int, iconH: Int, statW: Int, statH: Int): FirstAssets {
        val c16 = cropTo(first, 16, 9)
        try {
            val stat = derived(c16, statW, statH, false)
            val icon = derived(c16, iconW, iconH, false)
            val s = scaleTo(c16, outW, outH)
            val f1 = try { pngBytes(s, true) } finally { if (s !== c16) s.recycle() }
            return FirstAssets(icon, stat, f1)
        } finally {
            if (c16 !== first) c16.recycle()
            first.recycle()
        }
    }

    /* ------------------------------------------------------------------ 1) seleção/leitura do vídeo */
    fun probe(u: Uri) {
        if (busy.get()) { call("__onVideoPicked", JSONObject().put("ok", false).put("err", "Aguarde: há uma conversão em andamento.").toString()); return }
        exec.execute {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, u)
                val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                val mime = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: ""
                if (w <= 0 || h <= 0) throw Fail("O arquivo escolhido não parece ter faixa de vídeo legível.")
                if (dur <= 0L) throw Fail("Não foi possível ler a duração do vídeo.")
                val g = Grabber(r, w, h, rot)
                val f0 = g.at(0) ?: throw Fail("Não foi possível decodificar o primeiro quadro (codec não suportado neste aparelho?).")
                val th = scaleTo(f0, minOf(360, f0.width), maxOf(1, f0.height * minOf(360, f0.width) / f0.width))
                val jb = ByteArrayOutputStream()
                th.compress(Bitmap.CompressFormat.JPEG, 80, jb)
                if (th !== f0) th.recycle()
                f0.recycle()
                var name = ""
                try { ctx.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: "" } } catch (_: Exception) {}
                val o = JSONObject().put("ok", true).put("name", name).put("durationMs", dur).put("width", w).put("height", h)
                    .put("rotation", rot).put("mime", mime).put("thumb", Base64.encodeToString(jb.toByteArray(), Base64.NO_WRAP))
                synchronized(this) {
                    cleanupFiles()                       // novo vídeo: descarta pacote/erro anterior
                    uriStr = u.toString(); videoJson = o; selStart = -1L; selEnd = -1L; status = "idle"; stage = ""; progress = 0.0; errorMsg = ""; outName = ""
                    persist()
                }
                call("__onVideoPicked", o.toString())
            } catch (e: Throwable) {
                Log.e(tag, "probe falhou", e)
                call("__onVideoPicked", JSONObject().put("ok", false).put("err", e.message ?: e.toString()).toString())
            } finally { try { r.release() } catch (_: Exception) {} }
        }
    }

    /* ------------------------------------------------------------------ 1b) recorte manual: linha do tempo e prévia */
    private val thumbExec = Executors.newSingleThreadExecutor()
    @Volatile private var timelineGen = 0
    @Volatile private var previewGen = 0
    private fun jpegB64(b: Bitmap, q: Int): String { val bo = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, q, bo); return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP) }
    private fun scaledH(b: Bitmap, h: Int): Bitmap = scaleTo(b, maxOf(1, (b.width.toLong() * h / maxOf(1, b.height)).toInt()), h)

    /** Miniaturas igualmente espaçadas (keyframes, rápidas) para a linha do tempo. Chegam uma a uma em window.__onTimelineThumb(i, b64). */
    fun requestTimeline(count: Int, heightPx: Int): Int {
        val u = currentUri()
        val gen = ++timelineGen
        if (u == null || busy.get()) { call("__onTimelineDone", "$gen,false"); return gen }
        val n = count.coerceIn(2, 24); val hh = heightPx.coerceIn(24, 240)
        thumbExec.execute {
            val r = MediaMetadataRetriever()
            var ok = false
            try {
                r.setDataSource(ctx, u)
                val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (dur > 0 && w > 0 && h > 0) {
                    val g = Grabber(r, w, h, rot)
                    for (i in 0 until n) {
                        if (gen != timelineGen) return@execute
                        val t = ((i + 0.5) * dur * 1000.0 / n).toLong()
                        val b = g.at(t, true) ?: continue
                        val s = scaledH(b, hh)
                        val b64 = jpegB64(s, 70)
                        if (s !== b) s.recycle(); b.recycle()
                        call("__onTimelineThumb", "$gen,$i,${q(b64)}")
                    }
                    ok = true
                }
            } catch (e: Throwable) { Log.w(tag, "linha do tempo falhou", e) }
            finally { try { r.release() } catch (_: Exception) {} }
            if (gen == timelineGen) call("__onTimelineDone", "$gen,$ok")
        }
        return gen
    }

    /**
     * Prévia do trecho [startMs, endMs]: quadros EXATOS (mesmo método da conversão) do primeiro e do último instante, mais uma sequência
     * reduzida (previewFps) para repetir em loop. A prévia só mostra; o recorte da conversão usa o vídeo original, não estes quadros.
     * Chegam: __onPreviewFrame(gen, kind, idx, total, b64) com kind = "start" | "end" | "seq", e __onPreviewDone(gen, ok).
     */
    fun requestPreview(startMs: Long, endMs: Long, previewFps: Int, heightPx: Int): Int {
        val u = currentUri()
        val gen = ++previewGen
        if (u == null || busy.get() || endMs <= startMs) { call("__onPreviewDone", "$gen,false"); return gen }
        val hh = heightPx.coerceIn(60, 360); val pf = previewFps.coerceIn(2, 12)
        thumbExec.execute {
            val r = MediaMetadataRetriever()
            var ok = false
            try {
                r.setDataSource(ctx, u)
                val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (dur > 0 && w > 0 && h > 0) {
                    val g = Grabber(r, w, h, rot)
                    val lastUs = dur * 1000L - 1L
                    fun emit(kind: String, idx: Int, total: Int, tUs: Long): Boolean {
                        val b = g.at(minOf(tUs, lastUs)) ?: return false
                        val c = cropTo(b, 16, 9)               // o mesmo recorte 16:9 que a conversão aplica
                        val s = scaledH(c, hh)
                        val b64 = jpegB64(s, 75)
                        if (s !== c) s.recycle(); if (c !== b) c.recycle(); b.recycle()
                        call("__onPreviewFrame", "$gen,${q(kind)},$idx,$total,${q(b64)}")
                        return true
                    }
                    val sUs = startMs * 1000L; val eUs = endMs * 1000L
                    if (emit("start", 0, 1, sUs) && gen == previewGen && emit("end", 0, 1, eUs)) {
                        val total = maxOf(1, ((eUs - sUs) * pf / 1_000_000L).toInt()).coerceAtMost(96)
                        var all = true
                        for (i in 0 until total) {
                            if (gen != previewGen) return@execute
                            if (!emit("seq", i, total, sUs + i * 1_000_000L / pf)) { all = false; break }
                        }
                        ok = all
                    }
                }
            } catch (e: Throwable) { Log.w(tag, "prévia falhou", e) }
            finally { try { r.release() } catch (_: Exception) {} }
            if (gen == previewGen) call("__onPreviewDone", "$gen,$ok")
        }
        return gen
    }
    fun cancelPreview() { previewGen++ }

    /* ------------------------------------------------------------------ 2) extração + montagem do pacote */
    fun isBusy(): Boolean = busy.get()

    fun cancel() { cancelled.set(true); if (!busy.get() && serviceOn) { serviceOn = false; VideoService.stop(ctx) } }

    /** Progresso GERAL (0..1): a preparação em JS ocupa 0–6 %, a extração/gravação 6–94 %, a verificação em JS o restante. */
    private fun progress(frac: Double, st: String) = report(0.06 + 0.88 * frac, st)

    private fun report(overall: Double, st: String) {
        val now = System.currentTimeMillis()
        var changed = false
        synchronized(this) { changed = st != stage; progress = overall; stage = st }
        post("window.__onVideoProgress&&window.__onVideoProgress($overall,${q(st)})")
        if (serviceOn && (changed || now - lastNotifAt >= 500)) { lastNotifAt = now; VideoNotifier.updateProgress(ctx, st, (overall * 100).toInt()) }
        if (now - lastPersistAt >= 1000) synchronized(this) { persist() }
    }

    /** Retorna "ok" ou "err:<motivo>". Resultado/progresso: window.__onVideo* (se a página existir) e getVideoState(). */
    fun build(planJson: String, fullPlanJson: String): String {
        val u = currentUri() ?: return "err:Nenhum vídeo selecionado."
        val plan = try { JSONObject(planJson) } catch (e: Exception) { return "err:Plano inválido: ${e.message}" }
        if (!busy.compareAndSet(false, true)) return "err:Já existe uma conversão em andamento."
        cancelled.set(false)
        try {
            cleanupFiles()
            f("video_plan.json").writeText(fullPlanJson)
        } catch (e: Exception) { busy.set(false); return "err:Não foi possível preparar a pasta temporária: ${e.message}" }
        synchronized(this) {
            status = "running"; stage = "Preparando"; progress = 0.06; outName = plan.optString("outName"); errorMsg = ""; frames = plan.optInt("N"); persist()
        }
        serviceOn = false
        if (VideoNotifier.enabled(ctx)) {
            try { VideoNotifier.ensureChannels(ctx); VideoService.start(ctx); serviceOn = true }
            catch (e: Exception) { Log.w(tag, "Foreground Service não iniciou; a conversão segue só com o app aberto", e) }
        }
        exec.execute {
            try {
                val summary = runBuild(u, plan)
                finishOk(summary)
            } catch (e: Stop) {
                finishCancel()
            } catch (e: OutOfMemoryError) {
                finishError("Memória insuficiente. Tente uma resolução menor (960×540 ou 854×480) ou menos FPS.")
            } catch (e: Throwable) {
                Log.e(tag, "build falhou", e)
                finishError(e.message ?: e.toString())
            }
        }
        return "ok"
    }

    private fun endService() { if (serviceOn) { serviceOn = false; VideoService.stop(ctx) } }

    private fun finishOk(summary: JSONObject) {
        try { f("video_summary.json").writeText(summary.toString()) } catch (e: Exception) { finishError("Não foi possível guardar o resultado: ${e.message}"); return }
        synchronized(this) { status = "built"; stage = "Verificando"; progress = 0.94; errorMsg = ""; persist() }
        endService()
        busy.set(false)
        if (!appVisible) VideoNotifier.done(ctx, true, "MCPACK gerado. Toque para verificar e baixar.")
        call("__onVideoBuilt", q(summary.toString()))
    }

    private fun finishError(msg: String) {
        cleanupFiles()
        synchronized(this) { status = "error"; errorMsg = msg; persist() }
        endService()
        busy.set(false)
        if (!appVisible) VideoNotifier.done(ctx, false, "A conversão não foi concluída. Toque para ver o motivo.")
        call("__onVideoError", q(msg))
    }

    private fun finishCancel() {
        cleanupFiles()
        synchronized(this) { status = "idle"; stage = ""; progress = 0.0; errorMsg = ""; persist() }
        endService()
        busy.set(false)
        VideoNotifier.clearResult(ctx)
        call("__onVideoCancelled", "")
    }

    private fun checkStop() { if (cancelled.get()) throw Stop() }

    private fun runBuild(u: Uri, plan: JSONObject): JSONObject {
        val n = plan.getInt("N")
        val fps = plan.getDouble("fps")
        val outW = plan.getJSONArray("frameSize").getInt(0)
        val outH = plan.getJSONArray("frameSize").getInt(1)
        val iconPath = plan.getString("iconPath"); val iconW = plan.getJSONArray("iconSize").getInt(0); val iconH = plan.getJSONArray("iconSize").getInt(1)
        val statPath = plan.getString("staticPath"); val statW = plan.getJSONArray("staticSize").getInt(0); val statH = plan.getJSONArray("staticSize").getInt(1)
        val manifestPath = plan.getString("manifestPath")
        val framePaths = plan.getJSONArray("framePaths")
        val drop = HashSet<String>().also { s -> plan.getJSONArray("dropPaths").let { a -> for (i in 0 until a.length()) s.add(a.getString(i)) } }
        val texts = plan.getJSONObject("texts")
        val strip = plan.optString("stripRoot", "")
        // a pasta externa do pacote-base é removida: manifest.json fica direto na raiz do .mcpack
        fun outName(n: String): String = if (strip.isNotEmpty() && n.startsWith(strip)) n.substring(strip.length) else n
        if (framePaths.length() != n) throw Fail("Plano inconsistente: ${framePaths.length()} caminhos para $n frames.")

        progress(0.0, "Verificando espaço e abrindo o vídeo")
        val need = (n.toLong() * outW * outH * 3 * 6 / 10) + 64L * 1024 * 1024
        val free = ctx.filesDir.usableSpace
        if (free < need) throw Fail("Espaço livre insuficiente: preciso de cerca de ${need / 1048576} MB e há ${free / 1048576} MB. Libere espaço ou reduza FPS/resolução.")
        outFile.delete()

        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, u)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (w <= 0 || h <= 0 || dur <= 0L) throw Fail("Não foi possível reler o vídeo (arquivo movido ou permissão perdida). Selecione-o novamente.")
            val maxMs = (plan.optDouble("maxSeconds", 12.0) * 1000).toLong()
            // recorte manual: o trecho começa em startMs (0 = comportamento da V5) e tem no máximo maxSeconds
            val startMs = plan.optLong("startMs", 0L)
            if (startMs < 0L || startMs >= dur) throw Fail("O trecho escolhido começa depois do fim do vídeo. Ajuste o recorte e tente de novo.")
            if (n.toDouble() / fps > minOf(dur - startMs, maxMs) / 1000.0 + 1e-6) throw Fail("Plano pede $n frames a $fps FPS, mais do que o trecho permitido do vídeo.")
            val startUs = startMs * 1000L
            val lastUs = dur * 1000L - 1L
            val grab = Grabber(r, w, h, rot)

            // ---- primeiro quadro do trecho: vira frame 1, ícone e imagem estática
            progress(0.01, "Extraindo o primeiro quadro")
            val first = grab.at(startUs) ?: throw Fail("Falha ao decodificar o primeiro quadro do vídeo.")
            val assets = firstFrameAssets(first, outW, outH, iconW, iconH, statW, statH)
            val iconBytes = assets.icon
            val statBytes = assets.stat
            val frame1 = assets.frame1
            checkStop()

            // ---- pacote-base (somente leitura): tudo que não é frame/ícone/estática é copiado ou substituído pelo texto do plano
            progress(0.03, "Lendo o pacote-base")
            val baseEntries = LinkedHashMap<String, ByteArray?>() // null = diretório
            ZipInputStream(base(plan.getString("baseAsset")).inputStream()).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    val name = e.name.replace('\\', '/')
                    if (e.isDirectory) baseEntries[name] = null
                    else if (!drop.contains(name) && name != iconPath && name != statPath) baseEntries[name] = zin.readBytes()
                    e = zin.nextEntry
                }
            }

            // ---- ZIP final em streaming
            ZipOutputStream(BufferedOutputStream(FileOutputStream(outFile), 1 shl 16)).use { zos ->
                zos.setLevel(6)
                fun deflated(name: String, data: ByteArray) {
                    zos.putNextEntry(ZipEntry(name).apply { method = ZipEntry.DEFLATED })
                    zos.write(data); zos.closeEntry()
                }
                fun stored(name: String, data: ByteArray) { // PNG já é comprimido: grava sem recomprimir
                    val e = ZipEntry(name)
                    e.method = ZipEntry.STORED; e.size = data.size.toLong(); e.compressedSize = data.size.toLong(); e.crc = crcOf(data)
                    zos.putNextEntry(e); zos.write(data); zos.closeEntry()
                }
                fun putBase(name: String) {
                    val o = outName(name)
                    if (o.isEmpty()) return // a própria pasta externa
                    when {
                        baseEntries[name] == null && baseEntries.containsKey(name) -> { zos.putNextEntry(ZipEntry(o)); zos.closeEntry() }
                        else -> deflated(o, baseEntries[name]!!)
                    }
                }
                fun emit(name: String) {
                    when {
                        texts.has(name) -> deflated(outName(name), texts.getString(name).toByteArray(Charsets.UTF_8))
                        else -> putBase(name)
                    }
                }
                progress(0.04, "Gravando arquivos do pacote")
                if (baseEntries.containsKey(manifestPath) || texts.has(manifestPath)) emit(manifestPath)
                for (name in baseEntries.keys) if (name != manifestPath) emit(name)
                // ícone e estática: mesmos caminhos do pacote-base
                stored(outName(iconPath), iconBytes)
                stored(outName(statPath), statBytes)

                // ---- frames: um por vez; nada de imagens falsas ou duplicadas
                for (k in 0 until n) {
                    checkStop()
                    progress(0.05 + 0.90 * k / n, "Extraindo e gravando frame ${k + 1} de $n")
                    val bytes: ByteArray = if (k == 0) frame1 else {
                        val t = minOf(startUs + Math.round(k * 1_000_000.0 / fps), lastUs)
                        val raw = grab.at(t) ?: throw Fail("Falha ao decodificar o quadro ${k + 1} (instante ${"%.2f".format(t / 1e6)} s). O codec deste vídeo pode não ser suportado.")
                        val c16 = cropTo(raw, 16, 9)
                        val s = scaleTo(c16, outW, outH)
                        try { pngBytes(s, true) } finally {
                            if (s !== c16) s.recycle()
                            if (c16 !== raw) c16.recycle()
                            raw.recycle()
                        }
                    }
                    stored(outName(framePaths.getString(k)), bytes)
                }
            }

            checkStop()
            progress(0.96, "Lendo o pacote gravado para validação")
            val gen = JSONObject().put("iconCrc", crcOf(iconBytes)).put("staticCrc", crcOf(statBytes)).put("frame1Crc", crcOf(frame1))
            val summary = summarize(outFile, gen)
            // pré-verificação nativa (a verificação completa de 14 itens roda em JS quando a interface estiver disponível)
            val names = HashSet<String>(); var badCrc = 0
            val ents = summary.getJSONArray("entries")
            for (i in 0 until ents.length()) { val e = ents.getJSONObject(i); names.add(e.getString("p")); if (!e.getBoolean("crcOk")) badCrc++ }
            if (badCrc > 0) throw Fail("O arquivo gravado ficou corrompido. Tente converter de novo.")
            if (!names.contains(outName(manifestPath))) throw Fail("O pacote gerado não tem o manifest.json na raiz.")
            for (k in 0 until n) if (!names.contains(outName(framePaths.getString(k)))) throw Fail("O pacote gerado está incompleto (faltam quadros).")
            progress(1.0, "Pacote gravado")
            return summary
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    /** Resumo do ZIP gravado: lê o arquivo de verdade (CRC recalculado) e devolve ao JS para a validação. */
    private fun summarize(f: File, gen: JSONObject): JSONObject {
        val arr = JSONArray()
        ZipFile(f).use { z ->
            val en = z.entries()
            val buf = ByteArray(1 shl 16)
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (e.isDirectory) continue
                checkStop()
                val name = e.name.replace('\\', '/')
                val isJson = name.endsWith(".json", ignoreCase = true) || name.endsWith(".lang", ignoreCase = true) || name.endsWith(".txt", ignoreCase = true) || name.endsWith(".md", ignoreCase = true) // metadados textuais
                val isPng = name.endsWith(".png", ignoreCase = true)
                val crc = CRC32()
                val head = ByteArray(32); var headLen = 0
                val text = if (isJson) ByteArrayOutputStream() else null
                var size = 0L
                z.getInputStream(e).use { ins ->
                    while (true) {
                        val r = ins.read(buf)
                        if (r < 0) break
                        crc.update(buf, 0, r); size += r
                        if (headLen < head.size) { val c = minOf(head.size - headLen, r); System.arraycopy(buf, 0, head, headLen, c); headLen += c }
                        text?.write(buf, 0, r)
                    }
                }
                val o = JSONObject().put("p", name).put("size", size).put("crc", crc.value).put("crcOk", e.crc == crc.value)
                if (isPng) {
                    val sig = intArrayOf(0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)
                    var ok = headLen >= 24
                    if (ok) for (i in sig.indices) if ((head[i].toInt() and 0xFF) != sig[i]) ok = false
                    fun be(p: Int) = ((head[p].toInt() and 0xFF) shl 24) or ((head[p + 1].toInt() and 0xFF) shl 16) or ((head[p + 2].toInt() and 0xFF) shl 8) or (head[p + 3].toInt() and 0xFF)
                    o.put("png", JSONObject().put("ok", ok).put("w", if (ok) be(16) else 0).put("h", if (ok) be(20) else 0))
                }
                if (text != null) o.put("text", String(text.toByteArray(), Charsets.UTF_8))
                arr.put(o)
            }
        }
        return JSONObject().put("entries", arr).put("gen", gen).put("fileSize", f.length())
    }

    /** Pacote verificado e pronto (status "ready"), ou null. Usado pelo instalador (INSTALAR NO MINECRAFT). */
    @Synchronized fun readyPack(): File? = if (status == "ready" && outFile.exists()) outFile else null
    @Synchronized fun readyName(): String = outName

    /* ------------------------------------------------------------------ 3) exportação (SAF) */
    fun export(dest: Uri) {
        exec.execute {
            try {
                if (status != "ready") throw Fail("O pacote ainda não foi verificado. Converta o vídeo de novo.")
                val f = outFile
                if (!f.exists()) throw Fail("O pacote gerado não está mais disponível. Converta o vídeo novamente.")
                val total = f.length()
                var done = 0L
                val os = ctx.contentResolver.openOutputStream(dest, "wt") ?: throw Fail("Android não abriu o destino escolhido.")
                os.use { out ->
                    FileInputStream(f).use { ins ->
                        val buf = ByteArray(1 shl 20)
                        var lastPct = -1
                        while (true) {
                            val r = ins.read(buf)
                            if (r < 0) break
                            out.write(buf, 0, r); done += r
                            val pct = (done * 100 / maxOf(1L, total)).toInt()
                            if (pct != lastPct) { lastPct = pct; call("__onVideoExportProgress", (done.toDouble() / total).toString()) }
                        }
                        out.flush()
                    }
                }
                var onDisk = -1L
                try { ctx.contentResolver.openFileDescriptor(dest, "r")?.use { onDisk = it.statSize } } catch (_: Exception) {}
                var name = ""
                try { ctx.contentResolver.query(dest, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) name = it.getString(0) ?: "" } } catch (_: Exception) {}
                call("__onVideoExported", JSONObject().put("ok", true).put("name", name).put("written", done).put("onDisk", onDisk).put("expected", total).toString())
            } catch (e: Throwable) {
                Log.e(tag, "export falhou", e)
                call("__onVideoExported", JSONObject().put("ok", false).put("err", e.message ?: e.toString()).toString())
            }
        }
    }

}
