package com.betmc.converter

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * Foreground Service que mantém o processo do BetMC vivo (e com prioridade alta) enquanto o vídeo é convertido,
 * mesmo com o app minimizado. O trabalho em si roda no [VideoEngine] (singleton do processo); o serviço só segura
 * a notificação persistente e permite cancelar pela notificação.
 *
 * Tipo: dataSync (existe desde o Android 10 e funciona com compileSdk/targetSdk 34).
 * O tipo "mediaProcessing" (Android 15+) seria o mais específico, mas exige compileSdk/targetSdk 35 e AGP mais novo.
 * Não promete continuidade após "Forçar parada" pelo usuário ou encerramento do processo pelo sistema.
 */
class VideoService : Service() {
    companion object {
        const val ACTION_CANCEL = "com.betmc.converter.action.CANCEL_VIDEO"
        fun start(c: Context) {
            val i = Intent(c, VideoService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }
        @Volatile var foregroundOn = false
        /**
         * Só para o serviço depois que ele chamou startForeground(): parar antes disso, logo após startForegroundService(),
         * faz o Android derrubar o app (ForegroundServiceDidNotStartInTime). Tenta por até ~5 s.
         */
        fun stop(c: Context, tries: Int = 0) {
            if (foregroundOn || tries >= 25) { c.stopService(Intent(c, VideoService::class.java)); return }
            Handler(Looper.getMainLooper()).postDelayed({ stop(c, tries + 1) }, 200)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            val eng = VideoEngine.get(this)
            eng.cancel()
            if (!eng.isBusy()) stopSelf()
            return START_NOT_STICKY
        }
        VideoNotifier.ensureChannels(this)
        val n = VideoNotifier.progressNotification(this, "Preparando", 6)
        if (Build.VERSION.SDK_INT >= 29) startForeground(VideoNotifier.ID_PROGRESS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else startForeground(VideoNotifier.ID_PROGRESS, n)
        foregroundOn = true
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    override fun onDestroy() {
        foregroundOn = false
        stopForeground(true)
        super.onDestroy()
    }
}

/** Canais, notificações de progresso/resultado e preferência "notificações ligadas/desligadas". */
object VideoNotifier {
    const val CH_PROGRESS = "betmc_progress"
    const val CH_RESULT = "betmc_result"
    const val ID_PROGRESS = 4101
    const val ID_RESULT = 4102

    private fun prefs(c: Context) = c.getSharedPreferences("betmc", Context.MODE_PRIVATE)
    fun enabled(c: Context): Boolean = prefs(c).getBoolean("notif", true)
    fun setEnabled(c: Context, v: Boolean) { prefs(c).edit().putBoolean("notif", v).apply() }

    /** Android 13+ exige a permissão POST_NOTIFICATIONS para as notificações aparecerem. */
    fun canPost(c: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 33) c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        else true

    private fun nm(c: Context) = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun ensureChannels(c: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val m = nm(c)
        m.createNotificationChannel(NotificationChannel(CH_PROGRESS, "Conversão em andamento", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Progresso da conversão de vídeo"; setShowBadge(false)
        })
        m.createNotificationChannel(NotificationChannel(CH_RESULT, "Conversão concluída", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Aviso quando o MCPACK fica pronto ou a conversão falha"
        })
    }

    @Suppress("DEPRECATION")
    private fun builder(c: Context, channel: String): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, channel) else Notification.Builder(c)

    private fun openApp(c: Context): PendingIntent {
        val i = Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(c, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun progressNotification(c: Context, stage: String, pct: Int): Notification {
        val cancel = PendingIntent.getService(c, 2, Intent(c, VideoService::class.java).setAction(VideoService.ACTION_CANCEL), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = builder(c, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat_betmc)
            .setColor(0xFFB69CFF.toInt())
            .setContentTitle("BetMC · convertendo vídeo")
            .setContentText("$stage · $pct%")
            .setSubText("Processando em segundo plano")
            .setProgress(100, pct.coerceIn(0, 100), false)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(c))
            .addAction(Notification.Action.Builder(Icon.createWithResource(c, R.drawable.ic_stat_betmc), "Cancelar", cancel).build())
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        return b.build()
    }

    fun updateProgress(c: Context, stage: String, pct: Int) {
        try { nm(c).notify(ID_PROGRESS, progressNotification(c, stage, pct)) } catch (_: Exception) {}
    }

    /** Notificação final (substitui a de progresso). Só aparece se o usuário deixou as notificações ligadas e o Android permite. */
    fun done(c: Context, ok: Boolean, text: String) {
        if (!enabled(c) || !canPost(c)) return
        try {
            ensureChannels(c)
            val n = builder(c, CH_RESULT)
                .setSmallIcon(R.drawable.ic_stat_betmc)
                .setColor(0xFFB69CFF.toInt())
                .setContentTitle(if (ok) "BetMC · MCPACK pronto" else "BetMC · conversão não concluída")
                .setContentText(text)
                .setAutoCancel(true)
                .setContentIntent(openApp(c))
                .build()
            nm(c).notify(ID_RESULT, n)
        } catch (_: Exception) {}
    }

    fun clearResult(c: Context) { try { nm(c).cancel(ID_RESULT) } catch (_: Exception) {} }
}
