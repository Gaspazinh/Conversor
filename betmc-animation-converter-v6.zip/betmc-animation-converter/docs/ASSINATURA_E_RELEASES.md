# Assinatura, Releases e atualização da BETMC

## 1. Situação encontrada na V5 (por que isto é necessário)
O `build.yml` da V5 compila `assembleDebug`. Nada no projeto define chave de assinatura, então o Gradle usa a chave de **debug**, que o
GitHub Actions cria de novo em cada execução (o ambiente é descartado). Resultado provável: **cada APK sai com uma assinatura diferente**
e o Android recusa instalar um por cima do outro ("aplicativo não instalado / conflito"). Não existe chave anterior a preservar.
Por isso a V6 passa a ter **uma chave definitiva única**; todas as versões futuras assinadas com ela atualizam umas às outras.

> **Atenção, uma única vez:** quem tem a V5 (ou qualquer build de debug) instalada precisa **desinstalar** antes de instalar a primeira
> versão assinada com a chave definitiva. Veja a seção 8.

## 2. Como a chave é criada (nada é gerado por mim nem fica no repositório)
Você executa o workflow de uso único `gerar-keystore.yml` no seu GitHub. Ele:
1. exige digitar `GERAR`, rodar na `main`, senha com 24+ caracteres, alias válido e recusa-se a rodar se o Secret `BETMC_KEYSTORE_B64` já existir;
2. roda `keytool -genkeypair` (RSA 4096, PKCS12, ~30 anos). A senha entra por **variável de ambiente** (`-storepass:env`), nunca em argumento, e o GitHub a mascara nos logs;
3. grava a chave (em base64) no Secret `BETMC_KEYSTORE_B64` com `gh secret set` por entrada padrão (nunca impressa);
4. imprime só a **impressão digital SHA-256 do certificado** (pública);
5. publica um **artefato de backup** (`.p12` + `.base64.txt`) com validade de **1 dia**.
A chave privada nunca aparece no código nem nos logs. O Gradle só a lê de variáveis de ambiente (`BETMC_KEYSTORE_PATH`, `BETMC_KEYSTORE_PASSWORD`, `BETMC_KEY_ALIAS`).

## 3. Passo a passo (use um computador ou o site do GitHub no navegador)
1. **Senha:** gere uma senha aleatória de 24+ caracteres no seu gerenciador de senhas. Guarde-a lá.
2. **Token temporário:** GitHub → Settings → Developer settings → Personal access tokens → *Fine-grained tokens* → Generate. Expiração 7 dias; *Only select repositories* → `Conversor`; Repository permissions → **Secrets: Read and write**.
3. **Secrets:** repositório → Settings → Secrets and variables → Actions → *New repository secret*:
   - `BETMC_KEYSTORE_PASSWORD` = a senha do passo 1
   - `BETMC_KEY_ALIAS` = `betmc` (ou outro nome simples)
   - `BETMC_ADMIN_TOKEN` = o token do passo 2
4. **Workflows:** envie para `.github/workflows/` o novo `build.yml` e o `gerar-keystore.yml` (arquivos entregues junto com a V6).
5. **Gerar:** aba Actions → "Gerar keystore (USO ÚNICO…)" → *Run workflow* → digite `GERAR`.
6. **Impressão digital:** no log do passo "Criar a keystore" copie a linha `SHA256:` e crie a variável (Settings → Secrets and variables → Actions → **Variables**) `BETMC_CERT_SHA256`. O build de release passa a recusar qualquer APK com outro certificado.
7. **Backup (faça na hora, veja a seção 4)**, depois apague o token e desative o workflow.

## 4. Backup seguro da keystore
- Na página da execução (aba *Summary*, seção *Artifacts*) baixe `BETMC-KEYSTORE-BACKUP-BAIXE-E-APAGUE`. Contém `betmc-release.p12` (a chave) e `betmc-release.p12.base64.txt` (a mesma chave em texto, para colar num Secret).
- Guarde **em dois lugares independentes** (por exemplo, um armazenamento na nuvem privado e um pendrive/PC). Guarde a **senha e o alias** no gerenciador de senhas.
- **Apague o artefato** logo depois de baixar (botão da lixeira ao lado dele). Em repositório público, qualquer conta logada no GitHub consegue baixar artefatos enquanto existirem; a senha forte é a proteção enquanto isso.
- Apague o Secret e o token `BETMC_ADMIN_TOKEN` (e revogue o token em Developer settings) e remova/desative `gerar-keystore.yml`.
- **Nunca** coloque o `.p12`, a senha ou o `.base64.txt` no repositório, em issues, ou em conversas.
- **Restaurar** (se o Secret se perder): crie o Secret `BETMC_KEYSTORE_B64` com o conteúdo do `.base64.txt` (ou `base64 -w0 betmc-release.p12`), com a **mesma** senha e alias.
- **Se a chave e todos os backups forem perdidos:** não há como atualizar instalações existentes; os usuários precisariam desinstalar e instalar de novo, e a V6 nunca mais poderia ser atualizada pelo app.

## 5. Publicar uma versão (nada é publicado sozinho)
1. Aumente a versão em `android/app/build.gradle.kts` (`vMajor`, `vMinor`, `vPatch`). `versionCode = MAJOR*10000 + MINOR*100 + PATCH` (6.0.0 → 60000). **Sempre maior que a anterior.**
2. Edite o `update.json` (modelo, na raiz do projeto): só `notes` (novidades), `minVersionCode` e `mandatory`. O workflow preenche versão, link, tamanho e SHA-256.
3. Gere o ZIP do projeto, deixe **só um `.zip`** na raiz do repositório (o workflow usa o primeiro `*.zip`), faça commit na `main`. (Cada commit gera um APK de *debug* como antes.)
4. Envie a tag `vX.Y.Z` igual à versão (ex.: `v6.0.0`): `git tag v6.0.0 && git push origin v6.0.0`. Se preferir o site: Releases → *Draft a new release* → crie a tag `v6.0.0` e publique; o workflow anexará os arquivos à Release.
5. O workflow confere tag × versão, assina com a chave definitiva, confere o certificado, calcula o SHA-256, valida o `update.json` e cria uma **Release em rascunho** com `BetMC-X.Y.Z.apk` e `update.json`. Nada é público ainda.
6. Confira o rascunho, **publique a Release** e só depois copie o `update.json` anexo para a raiz da `main`. É esse arquivo (`https://raw.githubusercontent.com/Gaspazinh/Conversor/main/update.json`) que os aplicativos consultam; o GitHub pode demorar alguns minutos para refletir a mudança.
7. APKs de *debug* (artefato `BetMC-APK`) **não** devem ser instalados por cima da versão oficial: têm outra assinatura.

## 6. Como o aplicativo atualiza
- Ao abrir (e no botão VERIFICAR ATUALIZAÇÕES) baixa o `update.json`. Só aceita links `https://github.com/Gaspazinh/Conversor/releases/download/…`.
- **Opcional:** mostra novidades; o usuário pode atualizar ou continuar. **Obrigatória** (`mandatory: true` ou versão instalada < `minVersionCode`): tela de atualização e funções principais bloqueadas; a exigência fica guardada no aparelho (vale mesmo sem internet).
- Baixa para uma pasta privada do app (nenhum arquivo do usuário é tocado), confere tamanho e **SHA-256** e só então chama o instalador do Android; antes, confere que o APK é o mesmo aplicativo, mais novo e **com a mesma assinatura**. O usuário sempre confirma a instalação no Android; nunca é silenciosa.

## 7. Permissões
- `INTERNET`: só o Kotlin verifica/baixa atualizações (o WebView continua sem acesso à rede). Vídeos e texturas nunca são enviados.
- `REQUEST_INSTALL_PACKAGES`: para abrir o instalador. Na primeira atualização o Android pode pedir "permitir instalar apps deste app".

## 8. Aviso para usuários da V5 (desinstalação única)
> **Antes de instalar a BETMC V6 pela primeira vez, desinstale a versão anterior (V5 ou qualquer build de teste).**
> Os APKs anteriores foram assinados com chaves de teste diferentes e o Android não permite instalar um por cima do outro.
> Depois dessa única desinstalação, todas as próximas versões atualizam por cima, direto pelo aplicativo.
> Seus MCPACKs já salvos em outras pastas não são apagados; apenas o estado temporário do aplicativo é perdido.
