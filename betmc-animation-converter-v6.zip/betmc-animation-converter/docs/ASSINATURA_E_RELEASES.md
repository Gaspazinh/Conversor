# Assinatura, Releases e atualização da BETMC

## 1. Situação encontrada na V5 (por que isto é necessário)
O `build.yml` da V5 compila `assembleDebug`. Nada no projeto define chave de assinatura, então o Gradle usa a chave de **debug**, que o
GitHub Actions cria de novo em cada execução (o ambiente é descartado). Resultado provável: **cada APK sai com uma assinatura diferente**
e o Android recusa instalar um por cima do outro ("aplicativo não instalado / conflito"). Não existe chave anterior a preservar.
Por isso a V6 passa a ter **uma chave definitiva única**; todas as versões futuras assinadas com ela atualizam umas às outras.

> **Atenção, uma única vez:** quem tem a V5 (ou qualquer build de debug) instalada precisa **desinstalar** antes de instalar a primeira
> versão assinada com a chave definitiva. Veja a seção 8.

## 2. Como a chave é criada (nada é gerado por mim nem fica no repositório)
Você executa o workflow de uso único `gerar-keystore.yml` no seu GitHub. Ele:
1. exige digitar `GERAR`, rodar na `main`, **duas** frases/senhas diferentes com 24+ caracteres, alias válido (minúsculas, números, `_`, `-`) e recusa-se a rodar se o Secret `BETMC_KEYSTORE_B64` já existir. Só uma execução por vez (`concurrency`); a existência do Secret é conferida de novo imediatamente antes de gravar;
2. roda `keytool -genkeypair` (RSA 4096, PKCS12, ~30 anos). A senha entra por **variável de ambiente** (`-storepass:env`), nunca em argumento, e o GitHub a mascara nos logs;
3. confere que a keystore abre, que o base64 decodifica idêntico e que cabe num Secret (limite 48 KB);
4. **cifra o backup** com `openssl` (AES-256, PBKDF2, 600 mil iterações) usando a frase `BETMC_BACKUP_PASSPHRASE` e publica **somente o arquivo `.enc`** como artefato de 1 dia. Nenhum `.p12` nem base64 sem cifra é publicado;
5. **só depois** de o backup subir, grava a chave (base64) no Secret `BETMC_KEYSTORE_B64` por entrada padrão (nunca impressa) e confere que ele aparece na lista;
6. imprime só a **impressão digital SHA-256 do certificado** (pública).
A chave privada nunca aparece no código, nos logs nem em artefato sem cifra. O Gradle só a lê de variáveis de ambiente (`BETMC_KEYSTORE_PATH`, `BETMC_KEYSTORE_PASSWORD`, `BETMC_KEY_ALIAS`).
> Opção ainda mais segura: gerar a chave **no seu computador** com `keytool` (sem artefato e sem token) e colar o base64 no Secret `BETMC_KEYSTORE_B64` você mesmo. O workflow é a alternativa de conveniência.

## 3. Passo a passo
1. **Duas senhas diferentes** no gerenciador de senhas, cada uma aleatória com 24+ caracteres: a **senha da keystore** e a **frase do backup**. A frase do backup nunca deve ser igual à senha da keystore.
2. **Token temporário:** GitHub → Settings → Developer settings → Personal access tokens → *Fine-grained tokens* → Generate. Expiração 7 dias; *Only select repositories* → `Conversor`; Repository permissions → **Secrets: Read and write** (nada mais).
3. **Secrets:** repositório → Settings → Secrets and variables → Actions → *New repository secret*:
   - `BETMC_KEYSTORE_PASSWORD` = a senha da keystore
   - `BETMC_BACKUP_PASSPHRASE` = a frase do backup (diferente da anterior)
   - `BETMC_KEY_ALIAS` = `betmc` (só minúsculas, números, `_` ou `-`)
   - `BETMC_ADMIN_TOKEN` = o token do passo 2
4. **Workflows:** envie para `.github/workflows/` o `build.yml` e o `gerar-keystore.yml` (cópias de referência em `github-workflows/`).
5. **Gerar:** aba Actions → "Gerar keystore (USO ÚNICO…)" → *Run workflow* → digite `GERAR`.
6. **Impressão digital:** no log do passo "Criar a keystore" copie a linha `SHA256:` e crie a variável (Settings → Secrets and variables → Actions → **Variables**) `BETMC_CERT_SHA256`. O build de release passa a recusar qualquer APK com outro certificado.
7. **Backup (seção 4)** e depois **remoção do token** (seção 4.2).

## 4. Backup, remoção do token e restauração
### 4.1 Backup
- Na página da execução (aba *Summary*, seção *Artifacts*) baixe `BETMC-KEYSTORE-BACKUP-CIFRADO-BAIXE-E-APAGUE`. Contém **só** `betmc-release.p12.enc`.
- Guarde o `.enc` **em dois lugares independentes** (por exemplo, nuvem privada e pendrive/PC). Guarde no gerenciador de senhas: a frase do backup, a senha da keystore e o alias.
- **Apague o artefato** logo depois de baixar (lixeira ao lado dele). Em repositório público qualquer conta logada consegue baixar artefatos enquanto existirem; por isso o arquivo só existe cifrado.
- **Confira o backup uma vez** (seção 4.3, passos 1 e 2) e compare a impressão digital com a do log. Só então considere o procedimento concluído.
- Nunca coloque `.p12`, senhas ou base64 da chave no repositório, em issues ou em conversas.
- Se uma execução falhar **depois** do upload do backup e **antes** de o Secret ser gravado, o backup daquela execução é de uma chave que nunca foi usada: apague-o e rode de novo. O backup válido é o da execução que terminou com "Secret BETMC_KEYSTORE_B64 gravado".
### 4.2 Remover o token (obrigatório)
Depois de baixar o backup e criar a variável `BETMC_CERT_SHA256`:
1. GitHub → Settings → Developer settings → Personal access tokens → **revogue/apague** o token.
2. Repositório → Settings → Secrets and variables → Actions → **apague** `BETMC_ADMIN_TOKEN` e `BETMC_BACKUP_PASSPHRASE` (a frase continua guardada no seu gerenciador de senhas; sem ela o backup não abre).
3. Desative ou apague `gerar-keystore.yml` (o Secret `BETMC_KEYSTORE_B64` já existente impede uma segunda chave de qualquer forma).
Se a senha `BETMC_KEYSTORE_PASSWORD` for alterada depois, a chave deixa de abrir: não a mude.
### 4.3 Restaurar a keystore a partir do backup
Precisa de um computador (ou Termux) com `openssl` e Java (`keytool`).
1. **Decifrar** (pede a frase do backup; não a digite na linha de comando):
   `openssl enc -d -aes-256-cbc -pbkdf2 -iter 600000 -in betmc-release.p12.enc -out betmc-release.p12`
   Se aparecer `bad decrypt`, a frase está errada.
2. **Conferir:** `keytool -list -v -keystore betmc-release.p12` (pede a senha da keystore). A linha `SHA256:` deve ser **igual** à variável `BETMC_CERT_SHA256`.
3. **Recriar o Secret** (se `BETMC_KEYSTORE_B64` sumiu): gere o base64 sem quebra de linha com `base64 -w0 betmc-release.p12` (no macOS: `base64 -i betmc-release.p12 | tr -d '\n'`) e crie o Secret `BETMC_KEYSTORE_B64` com esse texto. Mantenha **a mesma** `BETMC_KEYSTORE_PASSWORD` e `BETMC_KEY_ALIAS` (o alias aparece em `keytool -list`).
4. Teste criando uma tag de teste no fluxo da seção 5 (a Release fica em rascunho) e confira que o certificado confere com `BETMC_CERT_SHA256`.
5. Apague o `.p12` descriptografado do computador quando terminar (ou guarde-o apenas em local cifrado).
**Nunca rode o `gerar-keystore.yml` para "recuperar" a chave:** ele criaria uma chave diferente. **Se a chave e todos os backups forem perdidos**, não há como atualizar instalações existentes; os usuários precisariam desinstalar e instalar de novo, e a V6 nunca mais poderia ser atualizada pelo app.

## 5. Publicar uma versão (nada é publicado sozinho)
1. Aumente a versão em `android/app/build.gradle.kts` (`vMajor`, `vMinor`, `vPatch`). `versionCode = MAJOR*10000 + MINOR*100 + PATCH` (6.0.0 → 60000). **Sempre maior que a anterior.**
2. Edite o `update.json` (modelo, na raiz do projeto): só `notes` (novidades), `minVersionCode` e `mandatory`. O workflow preenche versão, link, tamanho e SHA-256.
3. Gere o ZIP do projeto, deixe **só um `.zip`** na raiz do repositório (o workflow usa o primeiro `*.zip`), faça commit na `main`. (Cada commit gera um APK de *debug* como antes.)
4. Envie a tag `vX.Y.Z` igual à versão (ex.: `v6.0.0`): `git tag v6.0.0 && git push origin v6.0.0`. Se preferir o site: Releases → *Draft a new release* → crie a tag `v6.0.0` e publique; o workflow anexará os arquivos à Release.
5. O workflow confere tag × versão, assina com a chave definitiva, confere o certificado, calcula o SHA-256, valida o `update.json` e cria uma **Release em rascunho** com `BetMC-X.Y.Z.apk` e `update.json`. Nada é público ainda.
6. Confira o rascunho, **publique a Release** e só depois copie o `update.json` anexo para a raiz da `main`. É esse arquivo (`https://raw.githubusercontent.com/Gaspazinh/Conversor/main/update.json`) que os aplicativos consultam; o GitHub pode demorar alguns minutos para refletir a mudança.
7. APKs de *debug* (artefato `BetMC-APK`) **não** devem ser instalados por cima da versão oficial: têm outra assinatura.

> O teste real da atualização (duas versões assinadas com a mesma keystore, positivos e negativos) está em `docs/PLANO_TESTE_ATUALIZACAO.md`.

## 6. Como o aplicativo atualiza
- Ao abrir (e no botão VERIFICAR ATUALIZAÇÕES) baixa o `update.json`. Só aceita links `https://github.com/Gaspazinh/Conversor/releases/download/…`.
- **Opcional:** mostra novidades; o usuário pode atualizar ou continuar. **Obrigatória** (`mandatory: true` ou versão instalada < `minVersionCode`): tela de atualização e funções principais bloqueadas; a exigência fica guardada no aparelho (vale mesmo sem internet).
- Baixa para uma pasta privada do app (nenhum arquivo do usuário é tocado), confere tamanho e **SHA-256** e só então chama o instalador do Android; antes, confere que o APK é o mesmo aplicativo, mais novo e **com a mesma assinatura**. O usuário sempre confirma a instalação no Android; nunca é silenciosa.

## 7. Permissões
- `INTERNET`: só o Kotlin verifica/baixa atualizações (o WebView continua sem acesso à rede). Vídeos e texturas nunca são enviados.
- `REQUEST_INSTALL_PACKAGES`: para abrir o instalador. Na primeira atualização o Android pode pedir "permitir instalar apps deste app".

## 8. Aviso para usuários da V5 (desinstalação única)
> **Antes de instalar a BETMC V6 pela primeira vez, desinstale a versão anterior (V5 ou qualquer build de teste).**
> Os APKs anteriores foram assinados com chaves de teste diferentes e o Android não permite instalar um por cima do outro.
> Depois dessa única desinstalação, todas as próximas versões atualizam por cima, direto pelo aplicativo.
> Seus MCPACKs já salvos em outras pastas não são apagados; apenas o estado temporário do aplicativo é perdido.
