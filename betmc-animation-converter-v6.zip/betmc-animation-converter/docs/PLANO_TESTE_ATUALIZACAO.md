# Plano: teste real de atualização automática (duas versões assinadas com a mesma keystore)

**Status: plano. Nada disto foi executado.** Só começa depois da sua autorização para criar a keystore e para publicar Releases.

## Objetivo
Provar, em aparelho real, que uma versão assinada com a chave definitiva atualiza a anterior **por cima, pelo próprio aplicativo**, e que as travas funcionam (SHA-256, assinatura, obrigatória, offline).

## Versões usadas
| | Versão A | Versão B |
|---|---|---|
| `versionName` / `versionCode` | 6.0.0 / 60000 | 6.0.1 / 60001 |
| Conteúdo | a V6 completa | **igual à A**, só com a versão aumentada e `notes` novas (assim, qualquer diferença observada vem da atualização, não de código) |
| Tag | `v6.0.0` | `v6.0.1` |
Ambas saem do `build.yml` (passo de Release) com a **mesma** keystore. Em cada Release confira no log a impressão digital e compare com `BETMC_CERT_SHA256`.

## Preparação (uma vez)
1. Keystore criada pelo `gerar-keystore.yml`, backup cifrado baixado e conferido, token removido, variável `BETMC_CERT_SHA256` criada (guia: `ASSINATURA_E_RELEASES.md`).
2. Aparelho de teste com a V5/qualquer build de debug **desinstalada**. Opcional: PC com `adb` para `adb logcat` e `apksigner`.
3. Baixar `BetMC-6.0.0.apk` e `BetMC-6.0.1.apk` das Releases (rascunho → baixar como dono) e conferir: `sha256sum` igual ao do `update.json`; `apksigner verify --print-certs` com o **mesmo** SHA-256 de certificado nos dois.

## Casos de teste
| # | Cenário | Como fazer | Resultado esperado |
|---|---|---|---|
| T1 | Linha de base | Instalar A. `update.json` da `main` aponta para A. Abrir o app; tocar VERIFICAR ATUALIZAÇÕES | "Você já usa a versão mais recente (6.0.0)"; nenhuma tela de atualização |
| T2 | Rascunho não vaza | Criar a Release B em rascunho **sem** copiar o `update.json` para a `main` | O app em A não vê atualização |
| T3 | Atualização opcional | Publicar a Release B; copiar o `update.json` de B para a `main` (`mandatory: false`, `minVersionCode: 60000`); esperar alguns minutos (cache do GitHub); abrir A | Tela "Atualização disponível" com versões e novidades; AGORA NÃO funciona e o app segue usável |
| T4 | Download e instalação | Tocar BAIXAR ATUALIZAÇÃO | Barra de progresso → "Download conferido (SHA-256)" → Android pede permissão de "instalar apps" (1ª vez) e depois confirmação → o app vira 6.0.1 **sem desinstalar** (Configurações → Apps) |
| T5 | Após atualizar | Abrir B; VERIFICAR ATUALIZAÇÕES | "Versão mais recente (6.0.1)"; converter um vídeo curto e instalar no Minecraft (regressão) |
| T6 | Obrigatória | Reinstalar A (desinstalar B e instalar A). Editar o `update.json` da `main`: `minVersionCode: 60001` (ou `mandatory: true`) | Tela "Atualização obrigatória", funções principais bloqueadas, sem "agora não"; atualizar libera o app |
| T7 | Bloqueio offline | Com A e T6 já visto, ativar modo avião e reabrir | Continua bloqueado ("Conecte-se à internet…"); ao reconectar e VERIFICAR DE NOVO, volta ao fluxo |
| T8 | SHA-256 errado | Em A, editar o `update.json` da `main` com um `sha256` incorreto (uma letra trocada) | Download termina e o app **recusa** ("não confere… descartado"); nada é instalado; arquivo apagado |
| T9 | Download interrompido | Iniciar o download e ligar o modo avião no meio | Erro claro e TENTAR DE NOVO; ao reconectar, o download recomeça e conclui |
| T10 | Assinatura diferente | Instalar o APK de **debug** (artefato `BetMC-APK`) com versão 6.0.0 e deixar o app tentar atualizar para B | O app recusa antes do Android ("assinatura diferente… desinstale uma vez"); nada é instalado |
| T11 | Link fora do repositório | Colocar um `apkUrl` de outro endereço no `update.json` | O app ignora o arquivo (nenhuma tela) e continua utilizável |
| T12 | `update.json` quebrado | Colocar JSON inválido | Ignorado em silêncio; verificação manual avisa "arquivo inválido" |
Após T6–T12: **restaurar** o `update.json` correto na `main` (`minVersionCode: 60000`, `mandatory: false`).

## Registro
Para cada caso: aparelho/Android, versão do app, resultado (passou/falhou), captura de tela e, se houver PC, o trecho do `adb logcat -s BetMC-Video BetMC-Updater`. Falha em T4, T8 ou T10 **bloqueia** divulgar a V6.

## Riscos e observações
- O raw.githubusercontent.com pode demorar ~5 minutos para refletir o `update.json`.
- Nunca é possível voltar de B para A por atualização (versão menor). Para voltar, desinstale.
- Publicar B é publicar uma versão real: use uma numeração que você queira manter (6.0.1).
- O teste usa o `update.json` da **branch main**; evite fazê-lo enquanto houver usuários reais em A, ou use uma conta/aparelho próprio e restaure o arquivo logo depois.
