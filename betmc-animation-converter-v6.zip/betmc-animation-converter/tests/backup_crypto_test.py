"""Teste do script de backup cifrado+autenticado (tools/betmc_backup.py). Usa DADOS ALEATORIOS DE TESTE, nunca uma chave real.
Uso: python3 tests/backup_crypto_test.py"""
import os, re, shutil, stat, subprocess, sys, tempfile
H = os.path.dirname(os.path.abspath(__file__)); S = os.path.join(H, '..', 'tools', 'betmc_backup.py')
res = []
def check(n, ok, d=''):
    res.append((n, bool(ok))); print(('PASS ' if ok else 'FAIL ') + n + ('' if ok else '  -> %s' % (d,)))
PW = 'frase-de-teste-aleatoria-0123456789-ABC'
def run(*a, pw=PW, extra_env=None):
    env = dict(os.environ); env.pop('BETMC_BK_PASS', None)
    if pw is not None: env['BETMC_BK_PASS'] = pw
    if extra_env: env.update(extra_env)
    return subprocess.run([sys.executable, S] + list(a), env=env, capture_output=True, text=True, stdin=subprocess.DEVNULL)
d = tempfile.mkdtemp(prefix='bkp-test-')
try:
    P = lambda n: os.path.join(d, n)
    for size in (1, 15, 16, 17, 3500, 100000):
        plain = os.urandom(size); open(P('p.bin'), 'wb').write(plain)
        for f in ('s.bkp', 'o.bin'):
            if os.path.exists(P(f)): os.remove(P(f))
        r1 = run('selar', P('p.bin'), P('s.bkp')); r2 = run('abrir', P('s.bkp'), P('o.bin'))
        check('ida e volta idênticas (%d bytes)' % size, r1.returncode == 0 and r2.returncode == 0 and open(P('o.bin'), 'rb').read() == plain, (r1.stderr, r2.stderr))
    plain = os.urandom(3500); open(P('p.bin'), 'wb').write(plain)
    if os.path.exists(P('s.bkp')): os.remove(P('s.bkp'))      # selar nunca sobrescreve: começa de um destino livre
    r0 = run('selar', P('p.bin'), P('s.bkp')); check('selar cria o backup em destino livre', r0.returncode == 0, r0.stderr); sealed = open(P('s.bkp'), 'rb').read(); n = len(sealed)
    check('arquivo selado criado só com permissão do dono (0600)', stat.S_IMODE(os.stat(P('s.bkp')).st_mode) == 0o600)
    check('formato: começa com BETMCBK1 e o openssl vem em seguida (Salted__)', sealed[:8] == b'BETMCBK1' and sealed[8:16] == b'Salted__')
    check('o texto claro não aparece no arquivo selado', plain[:32] not in sealed)
    s2 = P('s2.bkp'); run('selar', P('p.bin'), s2); check('cada selagem é diferente (sal aleatório)', open(s2, 'rb').read() != sealed)
    # --- integridade: qualquer alteração é recusada e NADA é escrito
    def opens(data, pw=PW, tag='x'):
        open(P('t.bkp'), 'wb').write(data); out = P('t.out')
        if os.path.exists(out): os.remove(out)
        r = run('abrir', P('t.bkp'), out, pw=pw); return r.returncode == 0, os.path.exists(out), r
    ok0, _, _ = opens(sealed); check('o original abre', ok0)
    regions = {'magic': 0, 'Salted__': 8, 'sal': 12, 'início do cifrado': 16, 'meio do cifrado': n // 2, 'fim do cifrado': n - 33, 'início da tag': n - 32, 'fim da tag': n - 1}
    for name, pos in regions.items():
        for bit in (0x01, 0x80):
            b = bytearray(sealed); b[pos] ^= bit; ok, wrote, r = opens(bytes(b))
            check('adulteração de 1 bit em "%s" (byte %d, 0x%02x) é detectada e nada é gravado' % (name, pos, bit), (not ok) and (not wrote) and 'ADULTERADO' in r.stderr, r.stderr)
    for name, data in {'1 byte a menos': sealed[:-1], 'sem a tag': sealed[:-32], 'metade': sealed[:n // 2], '1 byte a mais': sealed + b'\x00', 'tag duplicada': sealed + sealed[-32:], 'vazio': b'', 'só o magic': b'BETMCBK1'}.items():
        ok, wrote, r = opens(data); check('truncamento/extensão "%s" detectado' % name, (not ok) and (not wrote), r.stderr)
    other = P('other.bkp'); run('selar', P('p.bin'), other); o = open(other, 'rb').read()
    ok, wrote, r = opens(sealed[:-32] + o[-32:]); check('tag de OUTRO backup colada neste é recusada', (not ok) and (not wrote))
    ok, wrote, r = opens(sealed, pw=PW + 'x'); check('frase errada é recusada sem decifrar', (not ok) and (not wrote) and 'ADULTERADO' in r.stderr)
    ok, wrote, r = opens(sealed, pw=''); check('frase vazia é recusada', (not ok) and (not wrote))
    # --- regras de uso
    # --- nunca sobrescreve (selar e abrir)
    keep = open(P('s.bkp'), 'rb').read(); r = run('selar', P('p.bin'), P('s.bkp'))
    check('selar recusa sobrescrever um backup existente e o deixa intacto', r.returncode != 0 and 'ja existe' in r.stderr and open(P('s.bkp'), 'rb').read() == keep, r.stderr)
    open(P('outro.txt'), 'wb').write(b'importante'); r = run('selar', P('p.bin'), P('outro.txt'))
    check('selar recusa qualquer arquivo existente (não só .bkp) e o deixa intacto', r.returncode != 0 and open(P('outro.txt'), 'rb').read() == b'importante')
    os.symlink(P('outro.txt'), P('link.bkp')); r = run('selar', P('p.bin'), P('link.bkp'))
    check('selar não segue link simbólico para sobrescrever o alvo', r.returncode != 0 and open(P('outro.txt'), 'rb').read() == b'importante')
    os.symlink(P('inexistente'), P('quebrado.bkp')); r = run('selar', P('p.bin'), P('quebrado.bkp'))
    check('selar recusa até link simbólico quebrado', r.returncode != 0 and not os.path.exists(P('inexistente')))
    r = run('abrir', P('s.bkp'), P('link.bkp')); check('abrir também recusa destino que é link simbólico', r.returncode != 0 and open(P('outro.txt'), 'rb').read() == b'importante')
    r = run('selar', P('p.bin'), P('curta.bkp'), pw='curta'); check('frase com menos de 24 caracteres é recusada ao selar (e nada é criado)', r.returncode != 0 and not os.path.exists(P('curta.bkp')))
    open(P('ja.out'), 'wb').write(b'importante'); r = run('abrir', P('s.bkp'), P('ja.out')); check('não sobrescreve arquivo existente', r.returncode != 0 and open(P('ja.out'), 'rb').read() == b'importante')
    r = run('autoteste', P('s.bkp')); check('autoteste do script passa no arquivo bom', r.returncode == 0 and 'detectados' in r.stdout, r.stderr)
    bad = bytearray(sealed); bad[n // 2] ^= 1; open(P('bad.bkp'), 'wb').write(bytes(bad)); r = run('autoteste', P('bad.bkp')); check('autoteste falha em arquivo adulterado', r.returncode != 0)
    r = run('abrir', P('s.bkp'), P('x.out'), extra_env={'BETMC_BK_PASS': PW}); check('opera com a frase só por variável de ambiente (sem tty)', r.returncode == 0)
    # --- compatibilidade: o miolo é openssl padrão (restauração de emergência sem o script, SEM verificação de integridade)
    open(P('e.bin'), 'wb').write(sealed[8:-32])
    r = subprocess.run(['openssl', 'enc', '-d', '-aes-256-cbc', '-pbkdf2', '-iter', '600000', '-md', 'sha256', '-pass', 'env:PWX', '-in', P('e.bin'), '-out', P('e.out')], env=dict(os.environ, PWX=PW), capture_output=True)
    check('o miolo abre com openssl puro (plano B de emergência)', r.returncode == 0 and open(P('e.out'), 'rb').read() == plain)
    # --- segredos fora de argv e do código
    src = open(S, encoding='utf-8').read()
    check('a frase nunca vai em argumento (só env:/getpass) e não há senha literal no script', "-pass\", \"env:\" + ENV" in src and not re.search(r'-pass\W+pass:|passin|sys\.argv\[\d\]\s*[,)]\s*pw', src) and 'frase-de-teste' not in src)
    # --- argv de verdade: nenhuma execução pode expor a frase na lista de processos
    code = "import subprocess,sys,os\nimport builtins\nreal=subprocess.run\nseen=[]\ndef spy(cmd,*a,**k):\n    seen.append(list(cmd)); return real(cmd,*a,**k)\nsubprocess.run=spy\nIN,OUT=sys.argv[1],sys.argv[2]\nsys.argv=['x','selar',IN,OUT]\nexec(compile(open(%r).read(),'s','exec'),{'__name__':'__main__','__file__':%r})\nopen(OUT+'.argv','w').write(repr(seen))" % (S, S)
    run_env = dict(os.environ, BETMC_BK_PASS=PW)
    subprocess.run([sys.executable, '-c', code, P('p.bin'), P('spy.bkp')], env=run_env, capture_output=True)
    argv_dump = open(P('spy.bkp.argv')).read() if os.path.exists(P('spy.bkp.argv')) else ''
    check('na chamada real ao openssl a frase NÃO aparece nos argumentos', 'openssl' in argv_dump and PW not in argv_dump, argv_dump[:200])
finally:
    shutil.rmtree(d, ignore_errors=True)
bad = [n for n, ok in res if not ok]
print('\n%d/%d OK' % (len(res) - len(bad), len(res))); sys.exit(1 if bad else 0)
