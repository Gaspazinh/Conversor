// Casos negativos: o conversor deve recusar/alertar em vez de entregar pacote "aparentemente funcional".
const fs = require('fs'), path = require('path'), cp = require('child_process'), os = require('os');
const C = require('../www/core.js');
const src = path.join(__dirname, 'fixtures', 'Hoshino_Animation_120_Frames-2.mcpack');
let pass = 0, fail = 0;
const ok = (c, m) => { c ? pass++ : (fail++, console.log('FALHOU:', m)); };
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'neg-'));
const py = (code) => cp.execFileSync('python3', ['-c', code], { stdio: 'inherit' });
(async () => {
  // 1) offset adulterado -> análise deve recusar
  py(`import zipfile,json;zi=zipfile.ZipFile(${JSON.stringify(src)});zo=zipfile.ZipFile(${JSON.stringify(tmp + '/off.mcpack')},'w',zipfile.ZIP_DEFLATED)
for i in zi.infolist():
    d=zi.read(i.filename)
    if i.filename.endswith('animation_288.json'):
        o=json.loads(d);o['frame_50']['offset']=['5%','5%'];d=json.dumps(o,indent=2).encode()
    zo.writestr(i,d)
zo.close()`);
  let msg = ''; try { await C.analyze(new Blob([fs.readFileSync(tmp + '/off.mcpack')])); } catch (e) { msg = e.message; }
  ok(/grade regular/.test(msg), 'offset adulterado deve ser recusado: ' + msg);
  // 2) JSON de animação ausente
  py(`import zipfile;zi=zipfile.ZipFile(${JSON.stringify(src)});zo=zipfile.ZipFile(${JSON.stringify(tmp + '/noanim.mcpack')},'w')
for i in zi.infolist():
    if 'animation_288' not in i.filename: zo.writestr(i,zi.read(i.filename))
zo.close()`);
  msg = ''; try { await C.analyze(new Blob([fs.readFileSync(tmp + '/noanim.mcpack')])); } catch (e) { msg = e.message; }
  ok(/Nenhum JSON de animação/.test(msg), 'pacote sem animação: ' + msg);
  // 3) dado corrompido no ZIP -> a validação final precisa reprovar
  const buf = Buffer.from(fs.readFileSync(src));
  const info = await C.analyze(new Blob([buf]));
  const png = info.physical[0].entry;
  buf[png.lho + 30 + png.name.length + 5000] ^= 0xff; // flipa um byte dentro do PNG
  const info2 = await C.analyze(await C.openZip(new Blob([buf])));
  const r = await C.convert(info2, 100);
  const v = await C.validate(r.blob, 100, info2, r);
  ok(!v.ok && v.checks.some((c) => c.id === 'zip' && !c.ok), 'ZIP corrompido deve reprovar na validação');
  console.log(`${pass} OK, ${fail} falhas (casos negativos)`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
