"""Verificador independente (Python puro) dos pacotes gerados pelo teste Node.
Reimplementa a regra da animação do zero e compara com a saída do conversor.
Uso: node tests/run_tests.js && python3 tests/oracle.py"""
import glob, json, os, re, sys, zipfile

bad = 0
files = sorted(glob.glob(os.path.join(os.path.dirname(__file__), sys.argv[1] if len(sys.argv) > 1 else 'out', '*.mcpack')))
for f in files:
    N = int(re.search(r'__(\d+)\.mcpack$', f).group(1))
    z = zipfile.ZipFile(f)
    assert z.testzip() is None, 'CRC'
    names = z.namelist()
    root = next(n for n in names if n.endswith('manifest.json'))[:-len('manifest.json')]
    A = json.loads(z.read(root + 'betmc_ui/betmc_common/betmc_animation_288.json'))
    B = json.loads(z.read(root + 'betmc_ui/betmc_common/betmc_bg_common.json'))
    T = json.loads(z.read(root + 'textures/textures_list.json'))
    C = [e['path'] for e in json.loads(z.read(root + 'contents.json'))['content']]
    W = max(3, len(str(N)))
    err = []
    exp_keys = [f'frame_{i}' for i in range(1, N + 1)] + [f'anim_{i}' for i in range(1, N + 1)] + ['namespace']
    if list(A.keys()) != exp_keys: err.append('ordem/chaves do JSON')
    for i in range(1, N + 1):
        c, r = (i - 1) % 31, (i - 1) // 31
        x, y = -1500 + 100 * c, -1500 + 100 * r
        fr = A[f'frame_{i}']
        if fr != {'texture': f'betmc_background/betmc_background_frame/ezgif-frame-{i:0{W}d}', 'fill': True, 'size': ['100%', '100%'], 'offset': [f'{x}%', f'{y}%'], 'type': 'image'}: err.append(f'frame_{i}')
        an = A[f'anim_{i}']
        nxt = 1 if i == N else i + 1
        if an != {'next': f'@betmc_animation_288.anim_{nxt}', 'anim_type': 'offset', 'from': [f'{-x}%', f'{-y}%'], 'duration': 0.041666666666666664, 'to': [f'{-x}%', f'{-y}%']}: err.append(f'anim_{i}')
    ctl = B['betmc_animation_background_frame@betmc_common.empty_panel']['controls']
    if ctl != [{f'frame_{i}@betmc_animation_288.frame_{i}': {}} for i in range(1, N + 1)]: err.append('controls')
    if [t for t in T if 'frame-' in t] != [f'betmc_background/betmc_background_frame/ezgif-frame-{i:0{W}d}' for i in range(1, N + 1)]: err.append('textures_list')
    fc = [p for p in C if 'ezgif-frame-' in p]
    if fc != [f'subpacks/720/betmc_background/betmc_background_frame/ezgif-frame-{i:0{W}d}.png' for i in range(1, N + 1)]: err.append('contents')
    pngs = [n for n in names if 'ezgif-frame' in n]
    if pngs != [root + f'subpacks/720/betmc_background/betmc_background_frame/ezgif-frame-{1:0{W}d}.png']: err.append('png físico ' + str(pngs))
    print(('OK   ' if not err else 'ERRO ') + os.path.basename(f), err[:3])
    bad += bool(err)
print('\nOráculo Python:', len(files) - bad, '/', len(files), 'pacotes corretos')
sys.exit(1 if bad else 0)
