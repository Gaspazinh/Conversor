// Testes automatizados (Node >= 18):  node tests/run_tests.js
const fs = require('fs'), path = require('path'), assert = require('assert');
const C = require('../www/core.js');
const FIX = path.join(__dirname, 'fixtures');
const OUT = path.join(__dirname, 'out');
fs.mkdirSync(OUT, { recursive: true });
const SIZES = [79, 120, 151, 288, 1, 31, 32, 200, 1000];
const blobOf = (f) => new Blob([fs.readFileSync(path.join(FIX, f))]);
const txt = async (zip, name) => new TextDecoder().decode(await C.extract(zip, zip.entries.find((e) => e.norm.endsWith(name))));
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log('  FALHOU:', m); } };

(async () => {
  const fixtures = fs.readdirSync(FIX).filter((f) => f.endsWith('.mcpack'));
  const results = {};
  for (const f of fixtures) {
    const info = await C.analyze(blobOf(f));
    console.log(`\n== ${f}\n   raiz="${info.root}" frames=${info.n} grade=${JSON.stringify(info.grid)} dígitos=${info.widths} png físicos=${info.physical.length}`);
    for (const N of SIZES) {
      const r = await C.convert(info, N);
      const v = await C.validate(r.blob, N, info, r);
      const bad = v.checks.filter((c) => !c.ok);
      console.log(`   N=${String(N).padStart(4)}: ${v.ok ? 'OK ' : 'ERRO'} (${v.checks.length} verificações, ${(r.blob.size / 1e6).toFixed(2)} MB)` + (bad.length ? ' -> ' + bad.map((b) => b.label + ': ' + b.detail).join(' | ') : ''));
      ok(v.ok, `${f} N=${N} validação`);
      const buf = Buffer.from(await r.blob.arrayBuffer());
      fs.writeFileSync(path.join(OUT, `${f.replace(/\.mcpack$/, '')}__${N}.mcpack`), buf);
      results[`${f}|${N}`] = await C.openZip(r.blob);
    }
  }
  // identidade: converter para a mesma quantidade não pode alterar nada além da numeração
  const b = fixtures.find((x) => /288/.test(x));
  if (b) {
    const src = await C.openZip(blobOf(b));
    const out = results[`${b}|288`];
    for (const e of src.entries) {
      const o = out.entries.find((x) => x.norm === e.norm);
      ok(o && o.crc === e.crc && o.usize === e.usize, `288→288 idêntico: ${e.norm}`);
    }
    ok(src.entries.length === out.entries.length, '288→288 mesmo nº de arquivos');
    console.log('\n288 → 288: todos os arquivos idênticos byte a byte (CRC).');
  }
  // equivalência entre pacotes de origem diferentes (1 dígito vs 3 dígitos)
  if (fixtures.length === 2) {
    const [fa, fb] = fixtures;
    for (const N of [79, 120, 151, 288]) {
      for (const nm of ['betmc_animation_288.json', 'betmc_bg_common.json', 'textures_list.json', 'contents.json']) {
        const x = await txt(results[`${fa}|${N}`], nm), y = await txt(results[`${fb}|${N}`], nm);
        const nx = JSON.parse(x), ny = JSON.parse(y);
        if (nm === 'contents.json') { const f = (o) => o.content.map((e) => e.path).sort(); ok(JSON.stringify(f(nx)) === JSON.stringify(f(ny)), `${nm} N=${N}: mesmo conjunto de arquivos`); }
        else ok(JSON.stringify(nx) === JSON.stringify(ny), `${nm} N=${N}: origem 1 dígito == origem 3 dígitos`);
      }
    }
    console.log('Origem 1 dígito vs 3 dígitos: JSONs equivalentes para 79/120/151/288.');
  }
  // erros esperados
  for (const bad of ['0', '-5', '12.5', 'abc', '', '  ']) ok(C.validateCount(bad) === null, 'valor inválido rejeitado: "' + bad + '"');
  ok(C.validateCount(' 151 ') === 151, 'valor válido aceito');
  ok(C.suggestName('Hoshino_Animation_288_Frames.mcpack', 151) === 'Hoshino_Animation_151_Frames.mcpack', 'nome sugerido');
  ok(C.suggestName('x.zip', 10) === 'x_10_Frames.mcpack', 'nome sugerido sem padrão');
  let threw = false; try { await C.analyze(new Blob([Buffer.from('not a zip at all, definitely not')])); } catch (e) { threw = true; }
  ok(threw, 'arquivo que não é ZIP gera erro');
  console.log(`\n${pass} verificações OK, ${fail} falhas`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
