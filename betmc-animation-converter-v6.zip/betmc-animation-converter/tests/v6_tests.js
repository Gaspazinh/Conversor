// Testes da V6 em Node:  node tests/v6_tests.js
// Cobre: recorte manual (cálculo), atualização (lógica pura), regra de nomes técnicos e verificações cruzadas dos arquivos
// (Kotlin/manifest/Gradle/assets). NÃO executa Kotlin nem Android: isso depende de compilação e de teste em aparelho.
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const ROOT = path.join(__dirname, '..');
const C = require('../www/core.js'), V = require('../www/video.js'), U = require('../www/update.js'), N = require('../www/names.js');
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log('  FALHOU:', m); } };
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const KT = 'android/app/src/main/java/com/betmc/converter/';
const BASE = path.join(ROOT, 'tests', 'fixtures_video', 'Rebeca_Animation_CORRIGIDA.mcpack');

(async () => {
  /* ================= A) recorte manual: cálculo ================= */
  let s = V.normalizeSelection(23000, 6000, 18000);
  ok(s.startMs === 6000 && s.endMs === 18000 && s.lenMs === 12000, 'exemplo do pedido: vídeo de 23 s, de 06 s a 18 s');
  s = V.normalizeSelection(23000); ok(s.startMs === 0 && s.endMs === 12000, 'padrão (sem escolha) = início até 12 s, como na V5');
  s = V.normalizeSelection(8000); ok(s.startMs === 0 && s.endMs === 8000, 'vídeo curto: trecho inteiro');
  s = V.normalizeSelection(23000, 5000, 30000); ok(s.endMs === 17000 && s.lenMs === 12000, 'fim além do limite é encurtado para 12 s');
  s = V.normalizeSelection(23000, 22900, 23000); ok(s.lenMs === 500 && s.endMs === 23000 && s.startMs === 22500, 'mínimo de 0,5 s respeitado no fim do vídeo');
  s = V.normalizeSelection(23000, -50, 4000); ok(s.startMs === 0, 'início negativo vira 0');
  s = V.normalizeSelection(300, 0, 300); ok(s.lenMs === 300, 'vídeo menor que o mínimo: usa o vídeo inteiro');
  ok(V.normalizeSelection(0).lenMs === 0 && V.normalizeSelection(NaN).lenMs === 0, 'duração inválida não quebra');
  // marcadores
  let m = V.moveMarker({ startMs: 6000, endMs: 18000 }, 'start', 2000, 23000, 12, 100);
  ok(m.startMs === 2000 && m.endMs === 14000, 'arrastar o início para a esquerda empurra o fim (janela de 12 s acompanha)');
  m = V.moveMarker({ startMs: 6000, endMs: 18000 }, 'end', 22990, 23000, 12, 100);
  ok(m.endMs === 23000 && m.startMs === 11000, 'arrastar o fim até o final do vídeo empurra o início');
  m = V.moveMarker({ startMs: 6000, endMs: 12000 }, 'start', 11900, 23000, 12, 100);
  ok(m.endMs - m.startMs >= 500 && m.startMs === 11500, 'início não passa do fim (mínimo 0,5 s)');
  m = V.moveMarker({ startMs: 6000, endMs: 12000 }, 'end', 6100, 23000, 12, 100);
  ok(m.startMs === 6000 && m.endMs === 6500, 'fim não passa do início (mínimo 0,5 s)');
  m = V.moveMarker({ startMs: 0, endMs: 12000 }, 'end', 99999, 23000, 12, 1); ok(m.endMs === 23000 && m.startMs === 11000, 'fim limitado à duração');
  m = V.moveMarker({ startMs: 0, endMs: 12000 }, 'end', 11900, 23450, 12, 1); ok(m.endMs === 11900, 'passo fino (1 ms) não arredonda para 0,1 s');
  // propriedade: qualquer sequência de movimentos mantém as invariantes
  let seed = 12345; const rnd = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296;
  for (const dur of [900, 3000, 12000, 12001, 23450, 61000]) {
    let cur = V.normalizeSelection(dur), bad = 0;
    for (let i = 0; i < 400; i++) { cur = V.moveMarker(cur, rnd() < 0.5 ? 'start' : 'end', rnd() * dur * 1.2 - dur * 0.1, dur, 12, rnd() < 0.5 ? 100 : 1); const minMs = Math.min(500, dur); if (!(cur.startMs >= 0 && cur.endMs <= dur && cur.endMs - cur.startMs >= minMs && cur.endMs - cur.startMs <= 12000 && cur.lenMs === cur.endMs - cur.startMs)) bad++; }
    ok(bad === 0, 'invariantes dos marcadores (duração ' + dur + ' ms)');
  }
  // compatibilidade com a V5: sem escolha, o mesmo número de quadros
  let same = true;
  for (const dur of [500, 2500, 9999, 12000, 15000, 23450, 61000]) for (const fps of [1, 8, 12, 24, 30, 60]) { const d = V.normalizeSelection(dur); if (V.frameCountForSelection(d.lenMs, fps) !== V.frameCount(dur, fps, 12)) same = false; }
  ok(same, 'sem recorte manual, a contagem de quadros é idêntica à da V5');
  ok(V.frameCountForSelection(12000, 24) === 288 && V.frameCountForSelection(6000, 24) === 144, 'quadros do trecho: 12 s a 24 FPS = 288');
  ok(V.frameTimeUs(0, 24, 0) === 0 && V.frameTimeUs(24, 24, 0) === 1000000, 'instante dos quadros sem recorte = V5 (k/fps)');
  ok(V.frameTimeUs(0, 24, 6000) === 6000000 && V.frameTimeUs(287, 24, 6000) === 6000000 + Math.round(287e6 / 24), 'instante dos quadros com início em 06 s');
  // espelho da fórmula do Kotlin (VideoEngine.runBuild): todos os instantes caem DENTRO do trecho e do vídeo
  let inside = true;
  for (const [dur, a, b, fps] of [[23000, 6000, 18000, 24], [23450, 11450, 23450, 30], [12000, 0, 12000, 60], [9000, 2000, 9000, 12]]) {
    const n = V.frameCountForSelection(b - a, fps), startUs = a * 1000, lastUs = dur * 1000 - 1;
    for (let k = 0; k < n; k++) { const t = Math.min(startUs + Math.round(k * 1e6 / fps), lastUs); if (t < startUs || t > b * 1000) inside = false; }
  }
  ok(inside, 'todos os quadros ficam dentro do trecho escolhido');
  ok(V.fmtTime(6000) === '6,0 s' && V.fmtTime(65300) === '1 min 05,3 s' && V.fmtTime(0) === '0,0 s', 'formato de tempo legível');
  // integração com o plano (FPS, resolução e demais configurações continuam no plano)
  const baseBlob = new Blob([fs.readFileSync(BASE)]);
  const plan = await V.buildPlan(C, baseBlob, { N: 288, fps: 24, startMs: 6000, endMs: 18000, outW: 1280, outH: 720, displayName: 'Clipe' });
  const np = V.nativePlan(plan, 'Clipe.mcpack');
  ok(np.startMs === 6000 && np.endMs === 18000 && np.N === 288 && np.fps === 24 && np.frameSize[0] === 1280 && np.frameSize[1] === 720, 'plano nativo leva início/fim e mantém FPS e resolução');
  const plan0 = await V.buildPlan(C, baseBlob, { N: 24, fps: 24, outW: 640, outH: 360, displayName: 'Sem recorte' });
  ok(V.nativePlan(plan0, 'x.mcpack').startMs === 0, 'plano sem recorte começa em 0 (V5)');

  /* ================= B) atualização: lógica pura ================= */
  const good = { schema: 1, latestVersionCode: 60100, latestVersionName: '6.1.0', minVersionCode: 60000, mandatory: false, apkUrl: U.APK_PREFIX + 'v6.1.0/BetMC-6.1.0.apk', apkSize: 12345678, sha256: 'A'.repeat(64), notes: ['Novidade 1', ' Novidade 2 '], publishedAt: '2026-11-20' };
  const P = (o) => U.parse(JSON.stringify(Object.assign({}, good, o)));
  let r = P({}); ok(r.ok && r.info.sha256 === 'a'.repeat(64) && r.info.notes[1] === 'Novidade 2', 'update.json válido é aceito (SHA-256 normalizado)');
  ok(!U.parse('não é json').ok && !U.parse('[]').ok && !U.parse('null').ok, 'JSON inválido/formato errado rejeitado');
  ok(!P({ latestVersionCode: 0 }).ok && !P({ latestVersionCode: 1.5 }).ok && !P({ latestVersionCode: '60100' }).ok, 'versionCode inválido rejeitado');
  ok(!P({ latestVersionName: '' }).ok && !P({ latestVersionName: '<b>x</b>' }).ok, 'versionName inválido rejeitado');
  ok(!P({ minVersionCode: 70000 }).ok && !P({ minVersionCode: -1 }).ok, 'versão mínima maior que a mais recente rejeitada');
  ok(!P({ mandatory: 'sim' }).ok, 'mandatory precisa ser booleano');
  for (const bad of ['http://github.com/Gaspazinh/Conversor/releases/download/v6/a.apk', 'https://evil.example/a.apk', 'https://github.com/OutroUsuario/Conversor/releases/download/v6/a.apk', U.APK_PREFIX + '../../x.apk', U.APK_PREFIX + 'v6/a.apk?x=1', U.APK_PREFIX + 'v6/a.zip', U.APK_PREFIX + 'v6/a b.apk', 'https://github.com.evil.com/Gaspazinh/Conversor/releases/download/v6/a.apk'])
    ok(!P({ apkUrl: bad }).ok, 'apkUrl fora do permitido rejeitada: ' + bad.slice(0, 60));
  ok(!P({ sha256: 'xyz' }).ok && !P({ sha256: 'a'.repeat(63) }).ok && !U.parse(JSON.stringify(Object.assign({}, good, { sha256: undefined }))).ok, 'SHA-256 ausente/curto/inválido rejeitado');
  ok(!P({ apkSize: -5 }).ok && !P({ apkSize: 999999999 }).ok, 'tamanho inválido rejeitado');
  ok(P({ notes: 'texto único' }).info.notes.length === 1 && !P({ notes: [1, 2] }).ok && !P({ notes: new Array(40).fill('a') }).ok, 'notes: string única ok; tipos errados/excesso rejeitados');
  ok(P({ notes: ['<img src=x onerror=alert(1)>'] }).info.notes[0].startsWith('<img'), 'notes ficam como TEXTO (a interface usa textContent)');
  const info = P({}).info;
  ok(U.decide(info, 60100).state === 'none' && U.decide(info, 70000).state === 'none', 'mesma versão ou mais nova: nada a fazer');
  ok(U.decide(info, 60000).state === 'optional' && U.decide(info, 60000).required === 0, 'versão antiga ≥ mínima e não obrigatória: opcional');
  const info2 = P({ minVersionCode: 60100 }).info; ok(U.decide(info2, 60000).state === 'mandatory' && U.decide(info2, 60000).required === 60100, 'abaixo da versão mínima: obrigatória (e guarda a versão exigida)');
  const info3 = P({ mandatory: true }).info; ok(U.decide(info3, 60050).state === 'mandatory' && U.decide(info3, 60050).required === 60100, 'marcada como obrigatória: obrigatória');
  ok(U.decideOffline(60000, 60100).state === 'mandatory-offline' && U.decideOffline(60100, 60100).state === 'unknown' && U.decideOffline(60000, 0).state === 'unknown', 'sem internet: só bloqueia se já se sabia que a versão é proibida');
  ok(U.apkFileName(info) === 'BetMC-6.1.0.apk' && U.apkFileName({ latestVersionName: '6.1/../x' }).indexOf('/') < 0, 'nome do arquivo do APK seguro');
  const tpl = U.parse(read('update.json')); ok(tpl.ok, 'o update.json-modelo do projeto é válido: ' + (tpl.err || ''));

  /* ================= C) regra de nomes técnicos ================= */
  for (const k of N.TECHNICAL) ok(N.translate(k, 'mommy', { mommy: 'mamãe' }) === 'mommy', 'identificador (' + k + ') não é traduzido');
  ok(N.translate('ui', 'Cancel', { Cancel: 'Cancelar' }) === 'Cancelar' && N.translate('ui', 'Sem tradução', {}) === 'Sem tradução', 'texto de interface pode ser traduzido');
  ok(N.translate('ui', 'toString', {}) === 'toString', 'dicionário não confunde com propriedades herdadas');
  let threw = false; try { N.assertUnchanged('addon', 'mommy', 'mamãe'); } catch (e) { threw = true; } ok(threw, 'assertUnchanged acusa identificador alterado');
  ok(N.assertUnchanged('addon', 'mommy', 'mommy') === 'mommy' && N.assertUnchanged('ui', 'a', 'b') === 'b', 'assertUnchanged: ok quando igual / só vale para técnicos');
  const pm = await V.buildPlan(C, baseBlob, { N: 12, fps: 24, outW: 640, outH: 360, displayName: 'mommy' });
  const man = JSON.parse(pm.texts[pm.roles.manifest]);
  ok(man.header.name === 'mommy' && pm.displayName === 'mommy', 'nome do addon "mommy" preservado no manifest');
  ok(V.mcpackFileName('mommy') === 'mommy.mcpack' && V.displayNameOf('mommy', 'x.mp4') === 'mommy', 'nome do arquivo preserva "mommy"');
  const info0 = await C.analyze(baseBlob);
  ok(pm.texPrefix === info0.texPrefix && pm.ns === info0.ns && pm.framePaths.every((p) => p.indexOf(info0.texPrefix) >= 0), 'prefixo de textura, namespace e caminhos dos quadros iguais aos do pacote-base');
  ok(!/mam[ãa]e/i.test(JSON.stringify(pm.texts)), 'nenhum identificador foi traduzido nos JSONs gerados');
  const nonUi = ['www/core.js', 'www/video.js', 'www/update.js', 'www/video_ui.js', 'www/v6_ui.js'].some((f) => /\bmam[ãa]e\b/i.test(read(f)));
  ok(!nonUi, 'nenhum dicionário de tradução de identificadores no código');
  ok(fs.existsSync(path.join(ROOT, 'REGRAS_DO_PROJETO.md')) && /NUNCA traduzir automaticamente identificadores técnicos/.test(read('REGRAS_DO_PROJETO.md')), 'a regra global está escrita em REGRAS_DO_PROJETO.md');

  /* ================= D) textura-base embutida ================= */
  const basePath = path.join(ROOT, 'www', 'base', 'BetMC_UI_CORRIGIDO.mcpack');
  const bBytes = fs.readFileSync(basePath), bSha = crypto.createHash('sha256').update(bBytes).digest('hex');
  ok(bSha === '79b229c56abf09e315d857a8b8d0dcffcf53dcf13f98625511a08bdf78b34904', 'textura-base idêntica ao arquivo CORRIGIDO enviado (SHA-256)');
  ok(read(KT + 'PackInstaller.kt').indexOf('BASE_SHA256 = "' + bSha + '"') > 0, 'o SHA-256 conferido pelo Kotlin é o do arquivo embutido');
  ok(!fs.existsSync(path.join(ROOT, 'www', 'base', 'BetMC_UI-ORIGINAL.mcpack')) && !/UI-ORIGINAL/.test(read(KT + 'PackInstaller.kt')), 'a versão ORIGINAL (quebrada) não está no projeto');
  const bz = await C.openZip(new Blob([bBytes])); const names = bz.entries.map((e) => e.norm);
  ok(names.indexOf('manifest.json') >= 0, 'manifest.json na raiz da textura-base');
  ok(read(KT + 'PackInstaller.kt').indexOf('"base/BetMC_UI_CORRIGIDO.mcpack"') > 0, 'asset embutido referenciado pelo instalador');

  /* ================= E) projeto: manifest, Gradle, Kotlin ================= */
  const mf = read('android/app/src/main/AndroidManifest.xml');
  ok(/uses-permission android:name="android.permission.INTERNET"/.test(mf) && /REQUEST_INSTALL_PACKAGES/.test(mf), 'permissões INTERNET e REQUEST_INSTALL_PACKAGES declaradas');
  ok(!/READ_EXTERNAL_STORAGE|WRITE_EXTERNAL_STORAGE|MANAGE_EXTERNAL_STORAGE/.test(mf), 'nenhuma permissão ampla de armazenamento');
  ok(/androidx\.core\.content\.FileProvider/.test(mf) && /grantUriPermissions="true"/.test(mf) && /android:exported="false"/.test(mf.slice(mf.indexOf('FileProvider') - 120, mf.indexOf('FileProvider') + 260)), 'FileProvider não exportado, com permissão temporária');
  ok(/<queries><package android:name="com.mojang.minecraftpe"\/><\/queries>/.test(mf), 'visibilidade do pacote do Minecraft declarada');
  ok(!/usesCleartextTraffic="true"/.test(mf) && !/http:\/\//.test(read(KT + 'Updater.kt')) && !/http:\/\//.test(read(KT + 'PackInstaller.kt')), 'sem tráfego HTTP em texto puro');
  const fp = read('android/app/src/main/res/xml/file_paths.xml');
  ok(/files-path name="share" path="share\/"/.test(fp) && /files-path name="update" path="update\/"/.test(fp) && (fp.match(/<files-path/g) || []).length === 2, 'FileProvider expõe só files/share e files/update');
  ok(/blockNetworkLoads = true/.test(read(KT + 'MainActivity.kt')), 'o WebView continua com blockNetworkLoads (a rede é só do Kotlin)');
  const gr = read('android/app/build.gradle.kts');
  const vM = +/val vMajor = (\d+)/.exec(gr)[1], vm = +/vMinor = (\d+)/.exec(gr)[1], vp = +/vPatch = (\d+)/.exec(gr)[1];
  ok(vM * 10000 + vm * 100 + vp > 1 && /versionCode = vMajor \* 10000 \+ vMinor \* 100 \+ vPatch/.test(gr), 'versionCode cresce e vem da versão (V5 era 1)');
  ok(/System\.getenv\("BETMC_KEYSTORE_PATH"\)/.test(gr) && !/storePassword\s*=\s*"/.test(gr) && !/keyPassword\s*=\s*"/.test(gr), 'Gradle lê a assinatura do ambiente; sem senha no código');
  ok(/if \(hasReleaseKey\) signingConfig/.test(gr), 'release só assina quando a chave definitiva existe (debug continua igual)');
  const upd = read(KT + 'Updater.kt');
  ok(upd.indexOf('APK_PREFIX = "' + U.APK_PREFIX + '"') > 0, 'prefixo permitido do APK igual no Kotlin e no JS');
  ok(upd.indexOf('UPDATE_URL = "https://raw.githubusercontent.com/Gaspazinh/Conversor/main/update.json"') > 0, 'URL do update.json: Gaspazinh/Conversor, branch main');
  ok(/SHA-256/.test(upd) && /checkCompatible/.test(upd) && /canRequestPackageInstalls/.test(upd), 'atualizador confere SHA-256, assinatura e permissão do Android');
  ok(!/Runtime\.getRuntime\(\)\.exec|pm install|PackageInstaller\.Session|DevicePolicy/.test(upd + read(KT + 'PackInstaller.kt')), 'nenhuma tentativa de instalar em silêncio');
  const idx = read('www/index.html');
  ok(/nunca são enviados/.test(idx) && /verificar e baixar atualizações/.test(idx) && !/Nenhum vídeo sai do celular/.test(idx), 'texto de privacidade explica a conexão e que vídeos não são enviados');
  ok(/Não possui a textura-base da BETMC\? Instale-a antes de utilizar suas texturas\./.test(idx) && />PRIMEIRA INSTALAÇÃO|Primeira instalação</.test(idx) && /INSTALAR TEXTURA-BASE/.test(idx) && /INSTALAR NO MINECRAFT/.test(idx), 'textos pedidos presentes na interface');
  ok(/src="img\/tutorial_ordem_pacotes\.jpg"/.test(idx) && /Espaço reservado para a captura de tela real/.test(idx), 'captura real no tutorial (com o espaço reservado mantido só como reserva)');
  const shot = path.join(ROOT, 'www', 'img', 'tutorial_ordem_pacotes.jpg'), shotOrig = path.join(ROOT, 'docs', 'img', 'captura_original_minecraft_1001852262.jpg');
  ok(fs.existsSync(shot) && fs.existsSync(shotOrig), 'captura real e original arquivada presentes');
  const jpgDim = (b) => { let i = 2; while (i < b.length) { if (b[i] !== 0xff) { i++; continue; } const m = b[i + 1]; if (m >= 0xc0 && m <= 0xc3) return [b.readUInt16BE(i + 7), b.readUInt16BE(i + 5)]; i += 2 + b.readUInt16BE(i + 2); } return null; };
  const d1 = jpgDim(fs.readFileSync(shot)), d0 = jpgDim(fs.readFileSync(shotOrig));
  ok(d1 && d0 && d0[0] === 2340 && d0[1] === 1080 && d1[0] === 1170 && d1[1] === 540, 'captura redimensionada sem cortar nem mudar a proporção: ' + JSON.stringify([d0, d1]));
  ok(/width="1170" height="540"/.test(idx) && fs.statSync(shot).size < 600 * 1024, 'dimensões declaradas (sem salto de layout) e arquivo leve');
  const bm = JSON.parse(require('child_process').execSync('unzip -p "' + basePath + '" manifest.json').toString().replace(/^\uFEFF/, ''));
  ok(/BetMC UI — Menu Inicial/.test(idx) && bm.header.name === 'BetMC UI — Menu Inicial', 'a legenda cita o nome do pacote-base exatamente como o jogo o mostra (não traduzido)');

  console.log('\n' + pass + ' verificações OK, ' + fail + ' falhas');
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('ERRO NO TESTE:', e); process.exit(2); });
