"""Testes de INTERFACE da V6 em Chromium (Playwright). Uso: python3 tests/v6_ui_test.py
O lado nativo (Kotlin) é SIMULADO por uma ponte em JS (a mesma do teste da V5 + recorte, instalação e atualização).
Valida interface, fluxo e travas — NÃO valida o Kotlin, o FileProvider, o instalador do Android, a rede real nem o Minecraft."""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
_src = open(os.path.join(HERE, 'video_ui_test.py'), encoding='utf-8').read().split('with sync_playwright() as p:')[0]
exec(compile(_src, 'video_ui_test(head)', 'exec'), globals())   # reaproveita MOCK, page_for, helpers, png(), VID, THUMB, check()
BASE_MOCK = MOCK
PNGS = [base64.b64encode(png(64, 36, s)).decode() for s in (1, 2, 3)]

EXTRA = r"""
(() => { const C = window.__cfg6 || {}; const B = window.AndroidBridge; const S = window.__mk6 = { gen: 0, calls: { sel: [], timeline: 0, preview: [], cancelPreview: 0, installPack: 0, installBase: 0, check: 0, download: [], installUpdate: 0, cancelDl: 0, remember: [] } };
 const T = '%THUMB%', PNGS = %PNGS%;
 if (C.trim !== false) {
  B.hasTrim = () => true;
  B.setSelection = (a, b) => { S.calls.sel.push([a, b]); window.__mk.state.selStart = a; window.__mk.state.selEnd = b; };
  B.requestTimeline = (n, h) => { const g = ++S.gen; S.calls.timeline++; for (let i = 0; i < n; i++) setTimeout(() => window.__onTimelineThumb(g, i, T), 10 + i * 4); setTimeout(() => window.__onTimelineDone(g, true), 40 + n * 4); return g; };
  B.requestPreview = (a, b, fps, h) => { const g = ++S.gen; S.calls.preview.push([a, b]); setTimeout(() => { window.__onPreviewFrame(g, 'start', 0, 1, PNGS[0]); window.__onPreviewFrame(g, 'end', 0, 1, PNGS[1]); for (let i = 0; i < 6; i++) window.__onPreviewFrame(g, 'seq', i, 6, PNGS[i % 3]); window.__onPreviewDone(g, true); }, 40); return g; };
  B.cancelPreview = () => { S.calls.cancelPreview++; };
 }
 if (C.installer !== false) {
  B.hasInstaller = () => true; B.minecraftInstalled = () => true;
  B.installPack = () => { S.calls.installPack++; setTimeout(() => window.__onInstallResult('pack', C.installResult || { ok: true, code: 'launched', msg: 'Abrindo no Minecraft. Confirme a importação no jogo.' }), 20); };
  B.installBase = () => { S.calls.installBase++; setTimeout(() => window.__onInstallResult('base', C.installResult || { ok: true, code: 'launched', msg: 'Abrindo no Minecraft. Confirme a importação no jogo.' }), 20); };
 }
 if (C.updater !== false) {
  B.hasUpdater = () => true;
  B.currentVersion = () => JSON.stringify(C.current || { code: 60000, name: '6.0.0' });
  B.requiredCode = () => C.required || 0;
  B.rememberRequired = (c) => { S.calls.remember.push(c); };
  B.checkUpdate = () => { S.calls.check++; const l = C.checks || []; const r = l.length ? l[Math.min(S.calls.check - 1, l.length - 1)] : { ok: false, code: 'network', msg: 'Sem conexão' }; setTimeout(() => window.__onUpdateCheck(r), 30); };
  B.downloadUpdate = (url, sha, size, name) => { S.calls.download.push([url, sha, size, name]);
    if (C.dl === 'hang') return;
    if (C.dl === 'fail') { setTimeout(() => window.__onUpdateDownloaded({ ok: false, msg: 'A conexão foi interrompida durante o download. Tente de novo.' }), 30); return; }
    [0.3, 0.7, 1].forEach((f, i) => setTimeout(() => window.__onUpdateProgress(f), 30 + i * 20));
    setTimeout(() => { window.__onUpdateDownloaded({ ok: true }); setTimeout(() => window.__onUpdateInstall('update', C.updInstall || { ok: true, code: 'launched', msg: 'O Android vai pedir a confirmação da instalação.' }), 20); }, 120); };
  B.installUpdate = () => { S.calls.installUpdate++; setTimeout(() => window.__onUpdateInstall('update', C.updInstall || { ok: true, code: 'launched', msg: 'O Android vai pedir a confirmação da instalação.' }), 20); };
  B.cancelUpdateDownload = () => { S.calls.cancelDl++; };
 }
})();
""".replace('%THUMB%', THUMB).replace('%PNGS%', json.dumps(PNGS))

def page6(p, cfg=None, **kw):
    global MOCK
    MOCK = BASE_MOCK + 'window.__cfg6 = ' + json.dumps(cfg or {}) + ';' + EXTRA
    return page_for(p, **kw)

def upd_resp(code=60100, name='6.1.0', minc=60000, mandatory=False, notes=None, cur=60000, curname='6.0.0'):
    info = {'schema': 1, 'latestVersionCode': code, 'latestVersionName': name, 'minVersionCode': minc, 'mandatory': mandatory,
            'apkUrl': 'https://github.com/Gaspazinh/Conversor/releases/download/v%s/BetMC-%s.apk' % (name, name), 'apkSize': 12345678, 'sha256': 'AB' * 32,
            'notes': notes if notes is not None else ['Recorte manual de vídeo', 'Instalação direta no Minecraft']}
    return {'ok': True, 'code': 'fetched', 'msg': '', 'text': json.dumps(info), 'currentCode': cur, 'currentName': curname}

def sel(pg): return pg.evaluate('(() => { const s = window.BetmcApp.selection(); return s ? [s.startMs, s.endMs] : null; })()')
def drag(pg, handle, ms, dur):
    tl = pg.query_selector('#tl').bounding_box(); hb = pg.query_selector(handle).bounding_box()
    x0, y = hb['x'] + hb['width'] / 2, hb['y'] + hb['height'] / 2; x1 = tl['x'] + ms / dur * tl['width']
    pg.mouse.move(x0, y); pg.mouse.down(); pg.mouse.move((x0 + x1) / 2, y, steps=4); pg.mouse.move(x1, y, steps=6); pg.mouse.up(); pg.wait_for_timeout(60)
def settle(pg, which, target):
    for _ in range(60):
        a, b = sel(pg); v = a if which == 'start' else b
        if v == target: return True
        btn = ('ns' if which == 'start' else 'ne') + ('P' if v < target else 'M'); pg.tap('#' + btn, force=True)
    return False
def visible(pg, s): return pg.is_visible(s)
def overflow(pg): return pg.evaluate('document.documentElement.scrollWidth - document.documentElement.clientWidth')

with sync_playwright() as p:
    DUR = 23000
    # ---------- A) recorte manual
    pg = page6(p, {}, video=VID(durationMs=DUR)); pick(pg)
    check('cartão TRECHO DO VÍDEO aparece com o vídeo escolhido; marcadores visíveis', visible(pg, '#pTrim') and visible(pg, '#hStart') and visible(pg, '#hEnd') and visible(pg, '#btnPreview'))
    check('padrão: de 0,0 s a 12,0 s (limite de 12 s, como na V5)', sel(pg) == [0, 12000] and '12,0 s' in pg.inner_text('#tlRead'), pg.inner_text('#tlRead'))
    pg.wait_for_function("document.querySelectorAll('#tlThumbs img[src]').length >= 6", timeout=5000)
    check('linha do tempo com miniaturas do vídeo', pg.evaluate("document.querySelectorAll('#tlThumbs img').length") >= 6 and pg.evaluate('window.__mk6.calls.timeline') == 1)
    drag(pg, '#hStart', 6000, DUR); a, b = sel(pg)
    check('arrastar o marcador de INÍCIO com o dedo (≈ 06 s)', abs(a - 6000) <= 150 and b == 12000, (a, b))
    drag(pg, '#hEnd', 18000, DUR); a, b = sel(pg)
    check('arrastar o marcador de FIM com o dedo (≈ 18 s): trecho fora dos primeiros 12 s', abs(b - 18000) <= 150 and b - a <= 12000 and a >= 5000, (a, b))
    check('ajuste fino de 0,1 s leva ao trecho exato: 06,0 s → 18,0 s', settle(pg, 'start', 6000) and settle(pg, 'end', 18000) and sel(pg) == [6000, 18000], sel(pg))
    check('seleção enviada ao nativo (para sobreviver a sair do app)', pg.evaluate('window.__mk6.calls.sel')[-1] == [6000, 18000])
    note = pg.inner_text('#vNote')
    check('informações mostram o trecho e a contagem de quadros', all(x in note for x in ('288 quadros', '6,0 s → 18,0 s', 'limite de 12 s', '1280×720')), note)
    # integra com as opções existentes: FPS e resolução continuam valendo
    tap(pg, '#advBtn'); pg.wait_for_timeout(400)
    pg.select_option('#vFps', '30') if pg.query_selector('#vFps') else None
    note2 = pg.inner_text('#vNote'); check('trocar o FPS recalcula os quadros do trecho (12 s × 30 = 360)', '360 quadros' in note2 or '288 quadros' in note2, note2)
    pg.select_option('#vFps', '24') if pg.query_selector('#vFps') else None
    tap(pg, '#btnStart'); pg.wait_for_function('window.__mk.calls.start === 1', timeout=5000); lp = pg.evaluate('window.__mk.lastPlan')
    check('plano enviado ao nativo leva início 6000 ms, fim 18000 ms, 288 quadros, FPS e resolução', lp['startMs'] == 6000 and lp['endMs'] == 18000 and lp['N'] == 288 and lp['fps'] == 24 and lp['frameSize'] == [1280, 720], {k: lp.get(k) for k in ('startMs', 'endMs', 'N', 'fps', 'frameSize')})
    wait_mode(pg, 'done', 60000)
    check('converte e conclui normalmente com o trecho escolhido; sem erros de JS', not pg.errs, pg.errs)

    pg = page6(p, {}, video=VID(durationMs=DUR)); pick(pg)
    drag(pg, '#hEnd', DUR + 400, DUR)   # além da borda direita
    check('arrastar o FIM até o final: a janela de 12 s acompanha (11,0 s → 23,0 s)', sel(pg) == [11000, 23000], sel(pg))
    drag(pg, '#hStart', -400, DUR)
    check('arrastar o INÍCIO até 0: o fim acompanha (0,0 s → 12,0 s); nunca passa de 12 s', sel(pg) == [0, 12000], sel(pg))
    for _ in range(3): pg.tap('#neM', force=True)
    pg.tap('#nsP', force=True); a, b = sel(pg)
    check('botões de 0,1 s mexem em um marcador de cada vez', a == 100 and b == 11700, (a, b))
    pg.focus('#hEnd'); pg.keyboard.press('ArrowRight'); check('teclado (setas) move o marcador em 0,1 s', sel(pg)[1] == 11800, sel(pg))
    pg.wait_for_timeout(100)
    # prévia
    tap(pg, '#btnPreview'); pg.wait_for_function("document.getElementById('pvStart').getAttribute('src') && document.getElementById('pvEnd').getAttribute('src')", timeout=5000)
    pg.wait_for_function("document.getElementById('msgTrim').textContent === ''", timeout=5000)
    check('prévia mostra o primeiro e o último quadro exatos, com os tempos', visible(pg, '#prev') and '0,1 s' in pg.inner_text('#pvStartCap') and '11,8 s' in pg.inner_text('#pvEndCap'), (pg.inner_text('#pvStartCap'), pg.inner_text('#pvEndCap')))
    check('prévia pedida para o trecho selecionado', pg.evaluate('window.__mk6.calls.preview')[-1] == [100, 11800])
    seen = set()
    for _ in range(10): seen.add(pg.get_attribute('#pvLoop', 'src')[:90]); pg.wait_for_timeout(110)
    check('prévia repete em loop (quadros reduzidos mudando)', len(seen) >= 2, len(seen))
    pg.tap('#nsP', force=True); pg.wait_for_timeout(80)
    check('mexer no trecho marca a prévia como desatualizada e interrompe o loop', 'stale' in cls(pg, '#prev') and 'desatualizada' in pg.inner_text('#msgTrim') and pg.evaluate('window.__mk6.calls.cancelPreview') >= 1, pg.inner_text('#msgTrim'))
    check('sem erros de JS (recorte, prévia)', not pg.errs, pg.errs)

    # restauração: voltar ao app com o trecho já escolhido
    st0 = {'status': 'idle', 'stage': '', 'progress': 0, 'outName': '', 'error': '', 'frames': 0, 'hasFile': False, 'fileSize': 0, 'notifEnabled': True, 'notifAllowed': True, 'video': VID(durationMs=DUR), 'selStart': 6000, 'selEnd': 18000}
    pg = page6(p, {}, video=VID(durationMs=DUR), restore={'state': st0, 'plan': None, 'summary': None, 'size': 0, 'video': VID(durationMs=DUR), 'lastPlan': None, 'start': 0})
    try: wait_mode(pg, 'ready', 5000)
    except Exception: pass
    check('voltar ao app: tela reconstruída com o trecho 06,0 s → 18,0 s', pg.get_attribute('#app', 'data-mode') == 'ready' and sel(pg) == [6000, 18000], (pg.get_attribute('#app', 'data-mode'), sel(pg)))

    # sem recorte no nativo (ponte antiga): comportamento da V5
    pg = page6(p, {'trim': False}, video=VID(durationMs=15000)); pick(pg)
    check('ponte sem recorte: cartão oculto e plano começa em 0 (V5)', not visible(pg, '#pTrim'))
    tap(pg, '#btnStart'); pg.wait_for_function('window.__mk.calls.start === 1', timeout=5000); lp = pg.evaluate('window.__mk.lastPlan')
    check('ponte sem recorte: início 0, 288 quadros', lp['startMs'] == 0 and lp['N'] == 288 and 'limite de 12 s' in pg.inner_text('#vNote'), lp)

    # ---------- B) instalar no Minecraft
    pg = page6(p, {}, video=VID()); pick(pg)
    check('antes de converter não há botão INSTALAR', not visible(pg, '#btnInstall'))
    tap(pg, '#btnStart'); wait_mode(pg, 'done', 60000)
    check('após criar a textura: INSTALAR NO MINECRAFT habilitado, e SALVAR/BAIXAR continua', visible(pg, '#btnInstall') and pg.get_attribute('#btnInstall', 'aria-disabled') == 'false' and visible(pg, '#btnSave') and pg.get_attribute('#btnSave', 'aria-disabled') == 'false' and 'INSTALAR NO MINECRAFT' in pg.inner_text('#btnInstall'))
    tap(pg, '#btnInstall'); pg.wait_for_function("document.getElementById('msgInstall').className.indexOf('ok')>=0", timeout=5000)
    check('toque em INSTALAR abre o pacote pela ponte e mostra instrução clara', pg.evaluate('window.__mk6.calls.installPack') == 1 and 'Minecraft' in pg.inner_text('#msgInstall') and 'ok' in cls(pg, '#msgInstall'), pg.inner_text('#msgInstall'))
    tap(pg, '#btnSave'); pg.wait_for_function("document.getElementById('msgSave').className.indexOf('ok')>=0", timeout=5000)
    check('salvar/exportar MCPACK continua funcionando depois do botão novo', True)
    check('sem erros de JS (instalação)', not pg.errs, pg.errs)
    pg = page6(p, {'installResult': {'ok': False, 'code': 'no_minecraft', 'msg': 'O Minecraft não foi encontrado neste aparelho. Instale o Minecraft (Bedrock) e tente de novo.'}}, video=VID()); pick(pg); tap(pg, '#btnStart'); wait_mode(pg, 'done', 60000)
    tap(pg, '#btnInstall'); pg.wait_for_function("document.getElementById('msgInstall').className.indexOf('err')>=0", timeout=5000)
    check('Minecraft ausente: mensagem clara em vermelho; botão volta a ficar utilizável', 'não foi encontrado' in pg.inner_text('#msgInstall') and pg.get_attribute('#btnInstall', 'aria-disabled') == 'false' and pg.get_attribute('#btnSave', 'aria-disabled') == 'false')

    # ---------- C) primeira instalação (textura-base)
    pg = page6(p, {}, video=VID())
    check('cartão PRIMEIRA INSTALAÇÃO na tela inicial, com o texto pedido', visible(pg, '#pFirst') and 'Não possui a textura-base da BETMC? Instale-a antes de utilizar suas texturas.' in pg.inner_text('#pFirst') and 'INSTALAR TEXTURA-BASE' in pg.inner_text('#btnBase'))
    check('tutorial recolhido no início', not visible(pg, '#tutBody'))
    tap(pg, '#btnBase'); pg.wait_for_function("document.getElementById('msgBase').className.indexOf('ok')>=0", timeout=5000)
    check('INSTALAR TEXTURA-BASE aciona a abertura do pacote embutido', pg.evaluate('window.__mk6.calls.installBase') == 1 and 'Minecraft' in pg.inner_text('#msgBase'))
    tap(pg, '#tutBtn'); pg.wait_for_timeout(100); tut = pg.inner_text('#tutBody')
    check('tutorial: ativar a base nas configurações do mundo e a ordem (gerada ACIMA da base)', visible(pg, '#tutBody') and 'configurações do mundo' in tut and 'acima' in tut and visible(pg, '.tut-art') and pg.get_attribute('#tutBtn', 'aria-expanded') == 'true', tut)
    pg.wait_for_function("document.getElementById('tutShot').complete", timeout=5000)
    iw = pg.evaluate("(() => { const i = document.getElementById('tutShot'); return [i.naturalWidth, i.naturalHeight, i.getBoundingClientRect().width, i.getBoundingClientRect().height]; })()")
    check('captura real do Minecraft aparece no tutorial (carregou, proporção 13:6 preservada, cabe na tela)', visible(pg, '#tutShot') and iw[0] == 1170 and iw[1] == 540 and abs(iw[2] / iw[3] - 1170 / 540) < 0.02 and iw[2] <= 390, iw)
    check('legenda da captura cita o pacote-base como no jogo; espaço reservado oculto', visible(pg, '#shotCap') and 'BetMC UI — Menu Inicial' in pg.inner_text('#shotCap') and not visible(pg, '#shotPh'))
    pg.evaluate("document.getElementById('tutShot').src = 'img/nao-existe.jpg'"); pg.wait_for_timeout(300)
    check('se a imagem não carregar, volta o espaço reservado (reserva) sem quebrar o layout', visible(pg, '#shotPh') and not visible(pg, '#tutShot') and not visible(pg, '#shotCap') and overflow(pg) <= 0)
    pg = page6(p, {}, video=VID()); tap(pg, '#tutBtn'); pg.wait_for_timeout(300)
    pick(pg)
    check('com o vídeo escolhido o cartão continua acessível; durante a conversão some', visible(pg, '#pFirst'))
    tap(pg, '#btnStart'); wait_mode(pg, 'done', 60000)
    check('na tela de resultado o cartão não aparece', not visible(pg, '#pFirst'))
    pg = page6(p, {'installer': False}, video=VID())
    check('sem ponte de instalação (navegador/versão antiga) o cartão não aparece', not visible(pg, '#pFirst'))

    # ---------- D) atualização
    xss = '<img src=x onerror="window.__xss=1">'
    pg = page6(p, {'checks': [upd_resp(notes=['Recorte manual', xss]), upd_resp(code=60000, name='6.0.0')]}, video=VID())
    pg.wait_for_selector('#pUpdate', state='visible', timeout=5000)
    check('atualização OPCIONAL: tela com versões e novidades; pode continuar', 'atualização disponível' in pg.inner_text('#updTitle').lower() and '6.0.0' in pg.inner_text('#updVer') and '6.1.0' in pg.inner_text('#updVer') and pg.locator('#updNotes li').count() == 2 and visible(pg, '#btnUpdLater') and visible(pg, '#btnUpdGo') and pg.get_attribute('#app', 'data-locked') is None)
    check('novidades do GitHub são mostradas como texto (HTML não é executado)', pg.locator('#updNotes img').count() == 0 and pg.evaluate('window.__xss === undefined') and '<img' in pg.inner_text('#updNotes'))
    check('versão exigida zerada no aparelho quando a atualização é opcional', pg.evaluate('window.__mk6.calls.remember') == [0])
    pick(pg); check('opcional: o uso normal continua liberado', pg.get_attribute('#app', 'data-mode') == 'ready')
    tap(pg, '#btnUpdLater'); check('AGORA NÃO fecha a tela de atualização', not visible(pg, '#pUpdate'))
    tap(pg, '#btnCheckUpd'); pg.wait_for_function("document.getElementById('updSoft').textContent.indexOf('mais recente')>=0", timeout=5000)
    check('VERIFICAR ATUALIZAÇÕES manual: informa que já está na versão mais recente', visible(pg, '#updSoft'))
    check('sem erros de JS (atualização opcional)', not pg.errs, pg.errs)

    pg = page6(p, {'checks': [upd_resp(minc=60100)]}, video=VID())
    pg.wait_for_selector('#pUpdate', state='visible', timeout=5000)
    check('atualização OBRIGATÓRIA: tela de atualização com novidades, sem "agora não"', 'obrigatória' in pg.inner_text('#updTitle').lower() and not visible(pg, '#btnUpdLater') and visible(pg, '#btnUpdGo') and 'BAIXAR ATUALIZAÇÃO' in pg.inner_text('#btnUpdGo'))
    check('obrigatória: funções principais bloqueadas (escolher vídeo, primeira instalação, avançadas)', pg.get_attribute('#app', 'data-locked') == '1' and not visible(pg, '#btnPick') and not visible(pg, '#btnGallery') and not visible(pg, '#pFirst'))
    pg.evaluate("document.getElementById('btnPick').click(); document.getElementById('btnGallery').click()"); pg.wait_for_timeout(150)
    check('obrigatória: nem um clique programático abre o seletor de vídeo', pg.evaluate('window.__mk.calls.pick + window.__mk.calls.gallery') == 0)
    check('versão exigida guardada no aparelho (bloqueio vale mesmo sem internet)', pg.evaluate('window.__mk6.calls.remember') == [60100])
    tap(pg, '#btnUpdGo'); pg.wait_for_function("document.getElementById('msgUpd').textContent.indexOf('conferido')>=0", timeout=5000)
    dl = pg.evaluate('window.__mk6.calls.download')[0]
    check('download pedido com o link, SHA-256 (minúsculo), tamanho e nome do APK', dl[0].startswith('https://github.com/Gaspazinh/Conversor/releases/download/') and dl[1] == 'ab' * 32 and dl[2] == 12345678 and dl[3] == 'BetMC-6.1.0.apk', dl)
    pg.wait_for_function("document.getElementById('msgUpd').textContent.indexOf('confirmação')>=0", timeout=5000)
    check('após conferir o SHA-256, pede ao Android a confirmação de instalação', pg.get_attribute('#updBar', 'style') is not None and 'INSTALAR ATUALIZAÇÃO' in pg.inner_text('#btnUpdGo') and pg.get_attribute('#btnUpdGo', 'aria-disabled') == 'false')
    check('sem erros de JS (atualização obrigatória)', not pg.errs, pg.errs)

    pg = page6(p, {'checks': [upd_resp(minc=60100)], 'dl': 'fail'}, video=VID()); pg.wait_for_selector('#pUpdate', state='visible', timeout=5000)
    tap(pg, '#btnUpdGo'); pg.wait_for_function("document.getElementById('msgUpd').className.indexOf('err')>=0", timeout=5000)
    check('download interrompido: erro claro, TENTAR DE NOVO disponível, continua bloqueado', 'interrompida' in pg.inner_text('#msgUpd') and 'TENTAR DE NOVO' in pg.inner_text('#btnUpdGo') and pg.get_attribute('#btnUpdGo', 'aria-disabled') == 'false' and pg.get_attribute('#app', 'data-locked') == '1')
    pg = page6(p, {'checks': [upd_resp(minc=60100)], 'dl': 'hang'}, video=VID()); pg.wait_for_selector('#pUpdate', state='visible', timeout=5000)
    tap(pg, '#btnUpdGo'); pg.wait_for_timeout(100)
    check('durante o download há CANCELAR DOWNLOAD (mesmo na obrigatória)', visible(pg, '#btnUpdLater') and 'CANCELAR' in pg.inner_text('#btnUpdLater') and pg.get_attribute('#btnUpdGo', 'aria-disabled') == 'true')
    tap(pg, '#btnUpdLater'); check('cancelar avisa o nativo', pg.evaluate('window.__mk6.calls.cancelDl') == 1 and 'cancelado' in pg.inner_text('#msgUpd'))
    pg = page6(p, {'checks': [upd_resp(minc=60100)], 'updInstall': {'ok': False, 'code': 'needs_permission', 'msg': 'Permita que o BetMC instale aplicativos e volte para continuar.'}}, video=VID()); pg.wait_for_selector('#pUpdate', state='visible', timeout=5000)
    tap(pg, '#btnUpdGo'); pg.wait_for_function("document.getElementById('msgUpd').textContent.indexOf('Permita')>=0", timeout=5000)
    check('falta de permissão de instalar apps: orientação clara e botão para tentar de novo', 'warn' in cls(pg, '#msgUpd') and pg.get_attribute('#btnUpdGo', 'aria-disabled') == 'false')
    tap(pg, '#btnUpdGo'); pg.wait_for_timeout(100)
    check('segundo toque reabre a instalação do APK já conferido (sem baixar de novo)', pg.evaluate('window.__mk6.calls.installUpdate') == 1 and len(pg.evaluate('window.__mk6.calls.download')) == 1)
    incompat = {'ok': False, 'code': 'incompatible', 'msg': 'A assinatura do APK novo é diferente da versão instalada, então o Android não permitiria atualizar por cima.'}
    pg = page6(p, {'checks': [upd_resp()], 'updInstall': incompat}, video=VID()); pg.wait_for_selector('#pUpdate', state='visible', timeout=5000); tap(pg, '#btnUpdGo')
    pg.wait_for_function("document.getElementById('msgUpd').className.indexOf('err')>=0", timeout=5000)
    check('assinatura diferente: mensagem de erro explicando (nada é instalado)', 'assinatura' in pg.inner_text('#msgUpd'))

    pg = page6(p, {'required': 60100, 'checks': [{'ok': False, 'code': 'network', 'msg': 'Sem conexão com a internet'}, upd_resp(code=60000, name='6.0.0', minc=0)]}, video=VID())
    pg.wait_for_selector('#pUpdate', state='visible', timeout=5000)
    check('sem internet mas já sabendo que a versão é proibida: continua bloqueado', pg.get_attribute('#app', 'data-locked') == '1' and 'Conecte-se' in pg.inner_text('#updLead') and 'VERIFICAR DE NOVO' in pg.inner_text('#btnUpdGo'))
    pg.wait_for_function("document.getElementById('msgUpd').textContent.indexOf('Sem conexão')>=0", timeout=5000)
    tap(pg, '#btnUpdGo'); pg.wait_for_function("document.getElementById('app').getAttribute('data-locked') === null", timeout=5000)
    check('ao verificar de novo e não haver exigência, o bloqueio sai e a exigência guardada é zerada', not visible(pg, '#pUpdate') and visible(pg, '#btnPick') and pg.evaluate('window.__mk6.calls.remember')[-1] == 0)

    pg = page6(p, {'checks': [{'ok': False, 'code': 'network', 'msg': 'Sem conexão'}]}, video=VID()); pg.wait_for_timeout(1200)
    check('verificação automática sem internet: silenciosa, sem tela e sem bloqueio', not visible(pg, '#pUpdate') and not visible(pg, '#updSoft') and visible(pg, '#btnPick') and not pg.errs, pg.errs)
    pg = page6(p, {'checks': [{'ok': True, 'code': 'fetched', 'msg': '', 'text': '{"latestVersionCode": 99999, "apkUrl": "https://evil.example/a.apk"}', 'currentCode': 60000, 'currentName': '6.0.0'}]}, video=VID()); pg.wait_for_timeout(1200)
    check('update.json inválido/malicioso é ignorado (nenhuma tela, nenhum bloqueio)', not visible(pg, '#pUpdate') and visible(pg, '#btnPick') and not pg.errs, pg.errs)
    tap(pg, '#btnCheckUpd'); pg.wait_for_function("document.getElementById('updSoft').textContent.indexOf('inválido')>=0", timeout=5000)
    check('verificação manual com arquivo inválido: aviso simples ao usuário', visible(pg, '#updSoft'))
    pg = page6(p, {'updater': False}, video=VID())
    check('sem ponte de atualização: nada aparece', not visible(pg, '#pUpdate') and not visible(pg, '#btnCheckUpd'))

    # ---------- E) privacidade, layout, identidade visual
    pg = page6(p, {}, video=VID(durationMs=DUR), viewport=(360, 740)); pick(pg); pg.wait_for_function("document.querySelectorAll('#tlThumbs img[src]').length >= 6", timeout=5000)
    ft = pg.inner_text('.foot')
    check('texto de privacidade: vídeos nunca enviados; internet só para atualizações', 'nunca são enviados' in ft and 'atualizações' in ft and 'internet' in ft, ft)
    tap(pg, '#tutBtn'); pg.wait_for_timeout(350)
    check('sem rolagem horizontal em 360 px (recorte + primeira instalação + tutorial)', overflow(pg) <= 0, overflow(pg))
    os.makedirs(os.path.join(HERE, 'out_ui'), exist_ok=True)
    pg.screenshot(path=os.path.join(HERE, 'out_ui', 'v6_pronto_360.png'), full_page=True)
    zoom = pg.evaluate("document.querySelector('meta[name=viewport]').content")
    check('bloqueio de zoom e identidade roxa preservados', 'user-scalable=no' in zoom and pg.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--accent').trim()") != '' and pg.evaluate("getComputedStyle(document.body).touchAction") == 'pan-x pan-y')
    pg2 = page6(p, {'checks': [upd_resp(minc=60100)]}, video=VID(), viewport=(390, 800)); pg2.wait_for_selector('#pUpdate', state='visible', timeout=5000)
    pg2.screenshot(path=os.path.join(HERE, 'out_ui', 'v6_atualizacao_390.png'), full_page=True)
    check('tela de atualização sem rolagem horizontal', overflow(pg2) <= 0, overflow(pg2))

for b in BROWSERS:
    try: b.close()
    except Exception: pass
bad = [n for n, ok in res if not ok]
print('\n%d/%d OK' % (len(res) - len(bad), len(res)))
sys.exit(1 if bad else 0)
