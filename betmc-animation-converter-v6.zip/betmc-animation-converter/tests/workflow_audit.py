"""Auditoria ESTÁTICA dos workflows (não executa nada, não cria chave, não lê Secrets): python3 tests/workflow_audit.py"""
import os, re, sys, yaml
H = os.path.dirname(os.path.abspath(__file__)); R = os.path.join(H, '..')
res = []
def check(n, ok, d=''):
    res.append((n, bool(ok))); print(('PASS ' if ok else 'FAIL ') + n + ('' if ok else '  -> %s' % (d,)))
rd = lambda p: open(os.path.join(R, p), encoding='utf-8').read()
G = rd('github-workflows/gerar-keystore.yml'); B = rd('github-workflows/build.yml'); D = rd('docs/ASSINATURA_E_RELEASES.md')
g = yaml.safe_load(G); b = yaml.safe_load(B)
steps = g['jobs']['gerar']['steps']; names = [s.get('name', s.get('uses', '')) for s in steps]
def idx(sub): return next(i for i, s in enumerate(steps) if sub in (s.get('name', '') + s.get('uses', '')))
runs = [(s.get('name', ''), s.get('run', '')) for s in steps if 'run' in s]
allrun = '\n'.join(r for _, r in runs)

# --- gatilho, permissões, concorrência
check('só dispara manualmente (workflow_dispatch)', list((g.get(True) or g.get('on')).keys()) == ['workflow_dispatch'])
check('permissões do GITHUB_TOKEN: só contents: read', g['permissions'] == {'contents': 'read'})
check('concorrência: uma execução por vez, sem cancelar', g['concurrency'] == {'group': 'gerar-keystore', 'cancel-in-progress': False})
check('tem timeout', g['jobs']['gerar'].get('timeout-minutes'))
# --- logs
check('sem set -x / modo debug no script', not re.search(r'set\s+-\w*x|ACTIONS_STEP_DEBUG|xtrace', G))
SEC = r'\$\{?(KS_PASS|BK_PASS|GH_TOKEN|KS_B64)\b'
def leaks(text):
    out = []
    for l in text.splitlines():
        for m in re.finditer(r'\b(echo|printf|tee)\b[^;|&]*', l):           # impressão: só importa a EXPANSÃO de uma variável secreta
            if re.search(SEC, m.group(0)) and "'%s'" not in m.group(0): out.append(l.strip())
        for m in re.finditer(r'\bcat\b\s+[^;|&]*', l):                       # leitura de arquivo sensível
            if re.search(r'b64\.txt|\.p12(?!\.enc)|\.p12$', m.group(0)): out.append(l.strip())
    return out
leak = leaks(allrun)
check('nenhum echo/cat/printf de senha, token, base64 ou .p12', not leak, leak)
check('segredos só entram por env: (nenhum ${{ secrets.* }} dentro de run:)', 'secrets.' not in allrun)
check('senhas por variável de ambiente (-storepass:env, -pass env:), nunca literais', '-storepass:env KS_PASS' in allrun and '-pass env:BK_PASS' in allrun and not re.search(r'-storepass\s+[^\s:]|-pass\s+pass:|-keypass', allrun))
check('branch conferida por $GITHUB_REF (sem interpolação ${{ }} no script)', '"$GITHUB_REF" = "refs/heads/main"' in allrun)
# --- token
tok = [s.get('name', '') for s in steps if 'BETMC_ADMIN_TOKEN' in str(s.get('env', ''))]
check('token temporário só em 2 passos: checagem e gravação do Secret', len(tok) == 2 and 'Conferir' in tok[0] and 'Gravar' in tok[1], tok)
check('frase de backup só em 2 passos: checagem e cifragem', len([s for s in steps if 'BETMC_BACKUP_PASSPHRASE' in str(s.get('env', ''))]) == 2)
# --- uma só keystore / sem sobrescrever
chk = re.findall(r"grep -Eq '\^BETMC_KEYSTORE_B64\(\[\[:space:\]\]\|\$\)'", allrun)
check('existência do Secret conferida 2×: no início e imediatamente antes de gravar (nome exato)', len(chk) >= 3, len(chk))
check('há exatamente UM "gh secret set", com entrada por stdin e só BETMC_KEYSTORE_B64', allrun.count('gh secret set') == 1 and re.search(r'gh secret set BETMC_KEYSTORE_B64 --repo "\$GITHUB_REPOSITORY" < "\$RUNNER_TEMP/ks/b64\.txt"', allrun))
check('o Secret existente aborta sem nada alterar, orientando a restaurar do backup', 'JÁ EXISTE. Nada foi alterado' in G and 'RESTAURE do backup' in G)
check('confere o Secret na lista depois de gravar', allrun.count('gh secret list') >= 3)
# --- senhas e alias
check('senha da keystore e frase do backup: 24+ caracteres, e DIFERENTES entre si', '${#KS_PASS} -ge 24' in allrun and '${#BK_PASS} -ge 24' in allrun and '"$KS_PASS" != "$BK_PASS"' in allrun)
check('alias restrito a minúsculas/números/_/-', "'^[a-z0-9_-]{1,32}$'" in allrun)
# --- validação do base64 e tamanho
check('valida keystore (impressão digital), tamanho < 40 KB e round-trip base64 (cmp)', 'grep -m1 \'SHA256:\'' in allrun and '-lt 40000' in allrun and 'base64 -d "$D/b64.txt" | cmp - "$D/betmc-release.p12"' in allrun and 'base64 -w0' in allrun)
# --- backup
ups = [s for s in steps if str(s.get('uses', '')).startswith('actions/upload-artifact')]
check('exatamente um artefato publicado', len(ups) == 1)
u = ups[0]; paths = [p.strip() for p in str(u['with']['path']).splitlines() if p.strip()]
check('o artefato publicado contém SOMENTE o arquivo .enc', len(paths) == 1 and paths[0].endswith('betmc-release.p12.enc'), paths)
check('nenhum .p12 ou base64 sem cifra em qualquer artefato', not any(re.search(r'\.p12$|b64|base64', p) for p in paths))
check('artefato com validade de 1 dia e erro se faltar arquivo', u['with']['retention-days'] == 1 and u['with']['if-no-files-found'] == 'error')
check('backup cifrado: openssl AES-256-CBC, PBKDF2, 600 mil iterações, sal', 'openssl enc -aes-256-cbc -pbkdf2 -iter 600000 -salt' in allrun)
check('ordem: criar chave → cifrar → subir backup → gravar Secret', idx('Criar a keystore') < idx('Cifrar') < idx('upload-artifact') < idx('Gravar a chave'), names)
check('diretório do backup separado do da chave (o .p12 e o b64 nunca ficam na pasta publicada)', 'ks/backup/' in str(u['with']['path']) and '$D/backup' in allrun)
# --- documentação
for t in ['BETMC_BACKUP_PASSPHRASE', 'diferente', 'betmc-release.p12.enc', 'openssl enc -d -aes-256-cbc -pbkdf2 -iter 600000', 'keytool -list -v', 'BETMC_CERT_SHA256', 'revogue/apague', 'Nunca rode o `gerar-keystore.yml`', 'base64 -w0 betmc-release.p12']:
    check('docs: contém "%s"' % t, t in D)
check('docs: não manda guardar/baixar .p12 ou base64 sem cifra como backup', 'betmc-release.p12.base64.txt' not in D and 'BACKUP-BAIXE-E-APAGUE' not in D.replace('CIFRADO-BAIXE-E-APAGUE', ''))
# --- build.yml preservado
orig = open(os.path.join(H, 'fixtures_workflow', 'build.original.yml'), encoding='utf-8').read().splitlines(); new = B.splitlines(); i = 0; miss = []
for l in orig:
    if not l.strip(): continue
    try: i = new.index(l, i) + 1
    except ValueError: miss.append(l)
check('build.yml: todas as linhas do original preservadas, na mesma ordem', not miss, miss)
bsteps = b['jobs']['build']['steps']; rel = [s for s in bsteps if s.get('name', '').startswith('Release')]
check('build.yml: todos os passos de Release só rodam em tag vX.Y.Z', rel and all(s.get('if') == "startsWith(github.ref, 'refs/tags/v')" for s in rel))
check('build.yml: não usa o token temporário nem a frase de backup', 'BETMC_ADMIN_TOKEN' not in B and 'BACKUP_PASSPHRASE' not in B)
check('build.yml: Release criada como RASCUNHO', '--draft' in B)
bruns = '\n'.join(s.get('run', '') for s in bsteps if 'run' in s)
check('build.yml: nenhum eco/impressão das senhas ou do base64 da chave', not leaks(bruns) and 'set -x' not in B)
bad = [r for r, ok in res if not ok]
print('\n%d/%d OK' % (len(res) - len(bad), len(res))); sys.exit(1 if bad else 0)
