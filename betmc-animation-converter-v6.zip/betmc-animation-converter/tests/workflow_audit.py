"""Auditoria ESTÁTICA dos workflows (não executa nada, não cria chave, não lê Secrets): python3 tests/workflow_audit.py"""
import os, re, sys, yaml
H = os.path.dirname(os.path.abspath(__file__)); R = os.path.join(H, '..')
res = []
def check(n, ok, d=''):
    res.append((n, bool(ok))); print(('PASS ' if ok else 'FAIL ') + n + ('' if ok else '  -> %s' % (d,)))
rd = lambda p: open(os.path.join(R, p), encoding='utf-8').read()
G = rd('github-workflows/gerar-keystore.yml'); B = rd('github-workflows/build.yml'); D = rd('docs/ASSINATURA_E_RELEASES.md')
g = yaml.safe_load(G); b = yaml.safe_load(B)
steps = g['jobs']['gerar']['steps']; names = [s.get('name', s.get('uses', '')) for s in steps]
def idx(sub): return next(i for i, s in enumerate(steps) if sub in (s.get('name', '') + s.get('uses', '')))
runs = [(s.get('name', ''), s.get('run', '')) for s in steps if 'run' in s]
allrun_full = '\n'.join(r for _, r in runs)
allrun = re.sub(r"<<'PYEOF'\n.*?\n\s*PYEOF\n", '\n', allrun_full, flags=re.S)   # o script embutido é conferido nas checagens do backup

# --- gatilho, permissões, concorrência
check('só dispara manualmente (workflow_dispatch)', list((g.get(True) or g.get('on')).keys()) == ['workflow_dispatch'])
check('permissões do GITHUB_TOKEN: só contents: read', g['permissions'] == {'contents': 'read'})
check('concorrência: uma execução por vez, sem cancelar', g['concurrency'] == {'group': 'gerar-keystore', 'cancel-in-progress': False})
check('tem timeout', g['jobs']['gerar'].get('timeout-minutes'))
# --- logs
check('sem set -x / modo debug no script', not re.search(r'set\s+-\w*x|ACTIONS_STEP_DEBUG|xtrace', G))
SEC = r'\$\{?(KS_PASS|BK_PASS|GH_TOKEN|KS_B64)\b'
def leaks(text):
    out = []
    for l in text.splitlines():
        for m in re.finditer(r'\b(echo|printf|tee)\b[^;|&]*', l):           # impressão: só importa a EXPANSÃO de uma variável secreta
            if re.search(SEC, m.group(0)) and "'%s'" not in m.group(0): out.append(l.strip())
        for m in re.finditer(r'\bcat\b\s+(?!>)[^;|&]*', l):                       # leitura de arquivo sensível
            if re.search(r'b64\.txt|\.p12(?!\.enc)|\.p12$', m.group(0)): out.append(l.strip())
    return out
leak = leaks(allrun)
check('nenhum echo/cat/printf de senha, token, base64 ou .p12', not leak, leak)
check('segredos só entram por env: (nenhum ${{ secrets.* }} dentro de run:)', 'secrets.' not in allrun)
check('senha da keystore por variável de ambiente (-storepass:env), nunca literal', '-storepass:env KS_PASS' in allrun and not re.search(r'-storepass\s+[^\s:]|-pass\s+pass:|-keypass|openssl', allrun))
check('branch conferida por $GITHUB_REF (sem interpolação ${{ }} no script)', '"$GITHUB_REF" = "refs/heads/main"' in allrun)
# --- token
tok = [s.get('name', '') for s in steps if 'BETMC_ADMIN_TOKEN' in str(s.get('env', ''))]
check('token temporário só em 2 passos: checagem e gravação do Secret', len(tok) == 2 and 'Conferir' in tok[0] and 'Gravar' in tok[1], tok)
check('frase de backup só em 2 passos: checagem e cifragem', len([s for s in steps if 'BETMC_BACKUP_PASSPHRASE' in str(s.get('env', ''))]) == 2)
check('frase de backup entra na cifragem só como variável de ambiente BETMC_BK_PASS', 'secrets.BETMC_BACKUP_PASSPHRASE' in str([s for s in steps if s.get('name', '').startswith('Cifrar')][0]['env']) and 'BETMC_BK_PASS' in str([s for s in steps if s.get('name', '').startswith('Cifrar')][0]['env']))
# --- uma só keystore / sem sobrescrever
chk = re.findall(r"grep -Eq '\^BETMC_KEYSTORE_B64\(\[\[:space:\]\]\|\$\)'", allrun)
check('existência do Secret conferida 2×: no início e imediatamente antes de gravar (nome exato)', len(chk) >= 3, len(chk))
check('há exatamente UM "gh secret set", com entrada por stdin e só BETMC_KEYSTORE_B64', allrun.count('gh secret set') == 1 and re.search(r'gh secret set BETMC_KEYSTORE_B64 --repo "\$GITHUB_REPOSITORY" < "\$RUNNER_TEMP/ks/b64\.txt"', allrun))
check('o Secret existente aborta sem nada alterar, orientando a restaurar do backup', 'JÁ EXISTE. Nada foi alterado' in G and 'RESTAURE do backup' in G)
check('confere o Secret na lista depois de gravar', allrun.count('gh secret list') >= 3)
# --- senhas e alias
check('senha da keystore e frase do backup: 24+ caracteres, e DIFERENTES entre si', '${#KS_PASS} -ge 24' in allrun and '${#BK_PASS} -ge 24' in allrun and '"$KS_PASS" != "$BK_PASS"' in allrun)
check('alias restrito a minúsculas/números/_/-', "'^[a-z0-9_-]{1,32}$'" in allrun)
# --- validação do base64 e tamanho
check('valida keystore (impressão digital), tamanho < 40 KB e round-trip base64 (cmp)', 'grep -m1 \'SHA256:\'' in allrun and '-lt 40000' in allrun and 'base64 -d "$D/b64.txt" | cmp - "$D/betmc-release.p12"' in allrun and 'base64 -w0' in allrun)
# --- backup
ups = [s for s in steps if str(s.get('uses', '')).startswith('actions/upload-artifact')]
check('exatamente um artefato publicado', len(ups) == 1)
u = ups[0]; paths = [p.strip() for p in str(u['with']['path']).splitlines() if p.strip()]
check('o artefato publicado contém SOMENTE o arquivo .bkp (cifrado + HMAC)', len(paths) == 1 and paths[0].endswith('betmc-release.p12.bkp'), paths)
check('nenhum .p12 ou base64 sem cifra em qualquer artefato', not any(re.search(r'\.p12$|b64|base64', p) for p in paths))
check('artefato com validade de 1 dia e erro se faltar arquivo', u['with']['retention-days'] == 1 and u['with']['if-no-files-found'] == 'error')
cif = [s for s in steps if s.get('name', '').startswith('Cifrar')][0]['run']
loc = [s for s in steps if s.get('name', '').startswith('Localizar')][0]; tool = rd('tools/betmc_backup.py').rstrip('\n')
check('gerar-keystore executa tools/betmc_backup.py do ZIP do projeto (sem cópia embutida do código)', 'PYEOF' not in G and '<<' not in cif and 'cat >' not in allrun_full and "find src -path '*/tools/betmc_backup.py'" in loc['run'] and 'python3 "$BETMC_BACKUP_SCRIPT" selar' in cif)
copies = [os.path.relpath(os.path.join(dp, f), R) for dp, _, fs in os.walk(R) for f in fs if f.endswith(('.py', '.yml', '.sh', '.md', '.txt')) and ('MAGIC = b"' + 'BETMCBK1"') in open(os.path.join(dp, f), encoding='utf-8', errors='ignore').read()]
check('existe UMA só cópia do código do backup no projeto: tools/betmc_backup.py', copies == [os.path.join('tools', 'betmc_backup.py')], copies)
check('o passo que localiza o script não recebe segredos, roda antes de qualquer passo com segredo, e o checkout não persiste credenciais', 'env' not in loc and idx('Localizar') < idx('Conferir') < idx('Criar a keystore') < idx('Cifrar') and steps[0]['uses'].startswith('actions/checkout') and steps[0]['with']['persist-credentials'] is False)
check('o ZIP sem o script (ou sem ZIP) interrompe com mensagem clara antes de usar segredos', 'não contém tools/betmc_backup.py' in loc['run'] and 'Nenhum .zip do projeto' in loc['run'] and '|| true' in loc['run'])
pos = [cif.index(x) for x in ('selar', 'autoteste', 'abrir', 'cmp "$D/verificacao.p12"')]
check('backup: selar → autoteste de adulteração → abrir → cmp com a keystore, nessa ordem', pos == sorted(pos))
check('backup: verificacao.p12 é apagada; só a pasta backup/ é publicada', 'rm -f "$D/verificacao.p12"' in cif and 'ks/backup/' in str(u['with']['path']))
seal_src = tool[tool.index('def seal'):tool.index('def open_backup')]
check('script: selar recusa sobrescrever (checagem prévia + criação exclusiva O_EXCL, sem seguir link simbólico)', 'os.path.lexists(dst)' in seal_src and 'exclusive=True' in seal_src and 'exclusive=False' not in tool and 'os.O_EXCL' in tool)
check('script: cifra AES-256-CBC + PBKDF2-SHA256 600 mil iterações + HMAC-SHA256 (encrypt-then-MAC), tag em tempo constante', all(x in tool for x in ('-aes-256-cbc', '-pbkdf2', 'ITER = 600000', 'hashlib.sha256', 'hmac.compare_digest', 'LABEL + salt8')))
check('script: HMAC é conferido ANTES de decifrar; destino existente nunca é sobrescrito', tool.index('if not verify(data, pw)') < tool.index('run_openssl(True') and 'o destino ja existe' in tool)
check('script: a frase nunca vai em argumento nem é impressa', '"-pass", "env:" + ENV' in tool and not re.search(r'print\([^)]*\bpw\b|-pass\W+pass:|sys\.argv\[\d\][^\n]*pw', tool))
check('ordem: criar chave → cifrar/autenticar → subir backup → gravar Secret', idx('Criar a keystore') < idx('Cifrar') < idx('upload-artifact') < idx('Gravar a chave'), names)
check('diretório do backup separado do da chave (o .p12 e o b64 nunca ficam na pasta publicada)', 'ks/backup/' in str(u['with']['path']) and '$D/backup' in cif)
# --- documentação
for t in ['BETMC_BACKUP_PASSPHRASE', 'diferente', 'betmc-release.p12.bkp', 'python3 tools/betmc_backup.py abrir', 'HMAC-SHA256', 'ADULTERADO', 'keytool -list -v', 'BETMC_CERT_SHA256', 'revogue/apague', 'Nunca rode o `gerar-keystore.yml`', 'base64 -w0 betmc-release.p12', 'age']:
    check('docs: contém "%s"' % t, t in D)
check('docs: não manda guardar/baixar .p12 ou base64 sem cifra como backup, e não cita o formato antigo (.enc sem autenticação)', 'betmc-release.p12.base64.txt' not in D and 'BACKUP-BAIXE-E-APAGUE' not in D.replace('CIFRADO-BAIXE-E-APAGUE', '') and 'p12.enc' not in D and 'openssl enc -d -aes-256-cbc -pbkdf2 -iter 600000 -in' not in D.replace('-md sha256', ''))
# --- build.yml preservado
orig = open(os.path.join(H, 'fixtures_workflow', 'build.original.yml'), encoding='utf-8').read().splitlines(); new = B.splitlines(); i = 0; miss = []
for l in orig:
    if not l.strip(): continue
    try: i = new.index(l, i) + 1
    except ValueError: miss.append(l)
check('build.yml: todas as linhas do original preservadas, na mesma ordem', not miss, miss)
bsteps = b['jobs']['build']['steps']; rel = [s for s in bsteps if s.get('name', '').startswith('Release')]
check('build.yml: todos os passos de Release só rodam em tag vX.Y.Z', rel and all(s.get('if') == "startsWith(github.ref, 'refs/tags/v')" for s in rel))
check('build.yml: não usa o token temporário nem a frase de backup', 'BETMC_ADMIN_TOKEN' not in B and 'BACKUP_PASSPHRASE' not in B)
check('build.yml: Release criada como RASCUNHO', '--draft' in B)
bruns = '\n'.join(s.get('run', '') for s in bsteps if 'run' in s)
check('build.yml: nenhum eco/impressão das senhas ou do base64 da chave', not leaks(bruns) and 'set -x' not in B)

# --- build.yml × Gradle × gerar-keystore.yml: os três usam a chave do mesmo jeito
GR = rd('android/app/build.gradle.kts'); V5ID = 'com.betmc.converter'
rst = [s for s in bsteps if s.get('name', '').startswith('Release · restaurar')][0]; cmp_ = [s for s in bsteps if s.get('name', '').startswith('Release · compilar')][0]; ver = [s for s in bsteps if s.get('name', '').startswith('Release · verificar')][0]
check('build.yml lê exatamente os 3 Secrets criados: BETMC_KEYSTORE_B64, BETMC_KEYSTORE_PASSWORD, BETMC_KEY_ALIAS', 'secrets.BETMC_KEYSTORE_B64' in str(rst['env']) and 'secrets.BETMC_KEYSTORE_PASSWORD' in str(rst['env']) and 'secrets.BETMC_KEY_ALIAS' in str(rst['env']) and 'secrets.BETMC_KEYSTORE_PASSWORD' in str(cmp_['env']) and 'secrets.BETMC_KEY_ALIAS' in str(cmp_['env']))
check('gerar-keystore.yml grava o Secret com o MESMO nome (BETMC_KEYSTORE_B64) e usa os mesmos Secrets de senha e alias', 'gh secret set BETMC_KEYSTORE_B64' in allrun and 'secrets.BETMC_KEYSTORE_PASSWORD' in G and 'secrets.BETMC_KEY_ALIAS' in G)
check('codificação × decodificação casam: base64 -w0 (sem quebra) ↔ printf %s | base64 -d', 'base64 -w0 "$D/betmc-release.p12"' in allrun and "printf '%s' \"$KS_B64\" | base64 -d" in B)
check('Gradle recebe BETMC_KEYSTORE_PATH (do restaurar), BETMC_KEYSTORE_PASSWORD e BETMC_KEY_ALIAS (do passo de compilar)', 'BETMC_KEYSTORE_PATH=$RUNNER_TEMP/betmc-release.p12' in B and 'getenv("BETMC_KEYSTORE_PATH")' in GR and 'BETMC_KEYSTORE_PASSWORD:' in B and 'getenv("BETMC_KEYSTORE_PASSWORD")' in GR and 'BETMC_KEY_ALIAS:' in B and 'getenv("BETMC_KEY_ALIAS")' in GR)
check('tipo PKCS12 igual no keytool e no Gradle; senha da chave = senha da keystore (keytool sem -keypass; Gradle keyPassword = ksPass)', '-storetype PKCS12' in G and 'storeType = "PKCS12"' in GR and 'keyPassword = ksPass' in GR and '-keypass' not in G)
check('certificado: RSA 4096, SHA256withRSA explícito, validade ~30 anos (10950 dias)', all(x in G for x in ('-keyalg RSA', '-keysize 4096', '-sigalg SHA256withRSA', '-validity 10950')))
check('alias do workflow gerador (minúsculas) aceito pelo Gradle/keytool sem conversão', "'^[a-z0-9_-]{1,32}$'" in G)
check('identidade do app para atualizar por cima: applicationId/namespace iguais ao da V5 e versionCode crescente', ('applicationId = "%s"' % V5ID) in GR and ('namespace = "%s"' % V5ID) in GR and 'versionCode = vMajor * 10000 + vMinor * 100 + vPatch' in GR)
check('release SEM chave não vira APK instalável: só "app-release.apk" (assinado) é aceito e o job falha se faltar', 'release/app-release.apk' in str(ver['run']) and 'app-release.apk não foi gerado' in str(ver['run']) and 'if (hasReleaseKey) signingConfig' in GR)
check('build.yml confere a assinatura com apksigner e trava no certificado esperado (BETMC_CERT_SHA256)', '"$APKSIGNER" verify --print-certs' in str(ver['run']) and 'BETMC_CERT_SHA256' in str(ver['env']) and 'DIFERENTE do esperado' in str(ver['run']))
UP = rd('android/app/src/main/java/com/betmc/converter/Updater.kt')
check('o app confere pacote, versão maior e MESMA assinatura antes de pedir a instalação', all(x in UP for x in ('arc.packageName != c.packageName', 'getLongVersionCode(arc) <= cur.first', 'mine != theirs')))

# --- permissões mínimas e job de publicação separado (build.yml)
jobs = b['jobs']; pub = jobs['publicar']; build = jobs['build']
check('permissão padrão do workflow: só contents: read', b['permissions'] == {'contents': 'read'})
check('job build (compilações comuns e assinatura) NÃO tem contents: write', 'permissions' not in build or build['permissions'].get('contents') != 'write')
writers = [n for n, j in jobs.items() if str(j.get('permissions', {}).get('contents')) == 'write']
check('exatamente UM job com contents: write — o que cria a Release (publicar)', writers == ['publicar'], writers)
check('publicar: só em tag vX.Y.Z, só depois do build, e só com contents: write', pub['needs'] == 'build' and pub['if'] == "startsWith(github.ref, 'refs/tags/v')" and pub['permissions'] == {'contents': 'write'})
psteps = pub['steps']; pall = '\n'.join(str(x) for x in psteps)
check('publicar: sem checkout, sem Secrets/variáveis de assinatura e sem executar código do repositório', not any(str(x.get('uses', '')).startswith('actions/checkout') for x in psteps) and 'secrets.' not in pall.replace('github.token', '') and 'vars.' not in pall and 'unzip' not in pall and 'gradle' not in pall.lower())
prun = '\n'.join(x.get('run', '') for x in psteps)
check('publicar: baixa o artefato do build e reconfere tag × update.json e o SHA-256 do APK antes de criar a Release', any(str(x.get('uses', '')).startswith('actions/download-artifact') and x['with']['name'] == 'BetMC-release' for x in psteps) and 'não corresponde à versão do update.json' in prun and 'sha256sum' in prun and 'não confere com o update.json' in prun)
check('publicar: cria só RASCUNHO e exige que a tag exista (--draft --verify-tag); não publica', '--draft' in prun and '--verify-tag' in prun and '--latest' not in prun and 'gh release edit' not in prun)
check('o job build guarda APK + update.json em artefato para o job publicar', any(s.get('uses', '').startswith('actions/upload-artifact') and s.get('with', {}).get('name') == 'BetMC-release' for s in bsteps))
check('o job build já não cria a Release (nenhum "gh release" nele)', 'gh release' not in '\n'.join(s.get('run', '') for s in bsteps))
# --- BETMC_CERT_SHA256 obrigatório
req = [s for s in bsteps if s.get('name', '').startswith('Release · exigir BETMC_CERT_SHA256')]
check('BETMC_CERT_SHA256 é exigida logo no início da Release (vazia ou fora do formato de 64 hexadecimais → erro)', len(req) == 1 and 'vars.BETMC_CERT_SHA256' in str(req[0]['env']) and "grep -Eq '^[0-9a-f]{64}$'" in req[0]['run'] and 'exit 1' in req[0]['run'] and bsteps.index(req[0]) < [i for i, s in enumerate(bsteps) if s.get('name', '').startswith('Release · restaurar')][0])
check('não existe mais o caminho "só avisa": sem BETMC_CERT_SHA256 não se gera Release', '::warning::Variável BETMC_CERT_SHA256' not in B and 'não é permitido gerar Release sem ela' in B and '[ "$CERT" = "$WANT" ]' in B)
check('docs: BETMC_CERT_SHA256 obrigatória, job publicar com contents: write, script único em tools/ e sem sobrescrita', all(x in D for x in ('Impressão digital (obrigatória)', 'se recusa a gerar uma Release oficial', '`publicar`', 'o **único** com `contents: write`', 'única cópia', 'nunca sobrescreve', '--draft --verify-tag')))
bad = [r for r, ok in res if not ok]
print('\n%d/%d OK' % (len(res) - len(bad), len(res))); sys.exit(1 if bad else 0)
