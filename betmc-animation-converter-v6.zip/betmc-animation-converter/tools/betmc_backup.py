#!/usr/bin/env python3
"""
BETMC backup v1: cifra AES-256-CBC (openssl, PBKDF2-SHA256 com 600 mil iteracoes) + HMAC-SHA256 (encrypt-then-MAC).
Detecta adulteracao e corrupcao ANTES de decifrar. Usa so a biblioteca padrao do Python e o comando openssl.
A frase NUNCA vai em argumento de comando: vem da variavel de ambiente BETMC_BK_PASS ou e digitada (getpass).

Uso:
  python3 betmc_backup.py selar    ENTRADA SAIDA.bkp     (frase com 24+ caracteres; recusa sobrescrever arquivo existente)
  python3 betmc_backup.py abrir    ENTRADA.bkp SAIDA     (verifica o HMAC; so entao decifra; recusa sobrescrever)
  python3 betmc_backup.py autoteste ARQUIVO.bkp          (prova que qualquer alteracao e detectada)

Formato do arquivo:  "BETMCBK1"(8) || E || TAG(32)
  E   = saida de: openssl enc -aes-256-cbc -pbkdf2 -iter 600000 -md sha256 -salt   ("Salted__" + sal de 8 bytes + cifrado)
  K   = PBKDF2-HMAC-SHA256(frase, "BETMC-backup-v1-mac" + sal, 600000, 32 bytes)   (chave do MAC, independente da chave de cifra)
  TAG = HMAC-SHA256(K, "BETMCBK1" || E)
"""
import getpass, hashlib, hmac, os, subprocess, sys, tempfile

MAGIC = b"BETMCBK1"
SALTED = b"Salted__"
LABEL = b"BETMC-backup-v1-mac"
ITER = 600000
ENV = "BETMC_BK_PASS"
MIN_LEN = len(MAGIC) + 16 + 16 + 32          # magic + (Salted__ + sal) + 1 bloco + tag


def die(msg):
    sys.stderr.write("ERRO: " + msg + "\n")
    sys.exit(1)


def get_pass(confirm_len=False):
    p = os.environ.get(ENV)
    if p is None:
        p = getpass.getpass("Frase do backup: ")
    if confirm_len and len(p) < 24:
        die("a frase do backup precisa ter 24 ou mais caracteres.")
    return p


def mac_key(pw, salt8):
    return hashlib.pbkdf2_hmac("sha256", pw.encode("utf-8"), LABEL + salt8, ITER, 32)


def run_openssl(decrypt, src, dst, pw):
    env = dict(os.environ)
    env[ENV] = pw                                   # so por ambiente: nunca em argv
    cmd = ["openssl", "enc", "-d" if decrypt else "-e", "-aes-256-cbc", "-pbkdf2", "-iter", str(ITER), "-md", "sha256",
           "-pass", "env:" + ENV, "-in", src, "-out", dst]
    if not decrypt:
        cmd.insert(3, "-salt")
    r = subprocess.run(cmd, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    if r.returncode != 0:
        die("openssl falhou (" + r.stderr.decode("utf-8", "replace").strip()[:200] + ")")


def write_private(path, data, exclusive):
    flags = os.O_WRONLY | os.O_CREAT | (os.O_EXCL if exclusive else os.O_TRUNC)
    fd = os.open(path, flags, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(data)


def verify(data, pw):
    """True somente se formato, tamanho e HMAC conferem. Compara em tempo constante."""
    if len(data) < MIN_LEN or data[:8] != MAGIC:
        return False
    e, tag = data[8:-32], data[-32:]
    if e[:8] != SALTED or (len(e) - 16) % 16 != 0 or len(e) < 32:
        return False
    k = mac_key(pw, e[8:16])
    return hmac.compare_digest(hmac.new(k, MAGIC + e, hashlib.sha256).digest(), tag)


def seal(src, dst):
    if os.path.lexists(dst):
        die("o destino ja existe; escolha outro nome (nada foi sobrescrito).")
    pw = get_pass(True)
    with tempfile.TemporaryDirectory() as d:
        tmp = os.path.join(d, "e.bin")
        run_openssl(False, src, tmp, pw)
        e = open(tmp, "rb").read()
    if e[:8] != SALTED or len(e) < 32:
        die("saida inesperada do openssl.")
    tag = hmac.new(mac_key(pw, e[8:16]), MAGIC + e, hashlib.sha256).digest()
    try:
        write_private(dst, MAGIC + e + tag, exclusive=True)      # O_EXCL: nunca sobrescreve (nem segue link simbolico)
    except FileExistsError:
        die("o destino ja existe; escolha outro nome (nada foi sobrescrito).")
    print("Backup selado: %s (%d bytes)" % (dst, len(MAGIC) + len(e) + 32))


def open_backup(src, dst):
    if os.path.lexists(dst):
        die("o destino ja existe; escolha outro nome (nada foi sobrescrito).")
    data = open(src, "rb").read()
    pw = get_pass()
    if not verify(data, pw):
        die("backup ADULTERADO, CORROMPIDO ou frase ERRADA. Nada foi decifrado.")
    with tempfile.TemporaryDirectory() as d:
        os.chmod(d, 0o700)
        tmp_in, tmp_out = os.path.join(d, "e.bin"), os.path.join(d, "p.bin")
        write_private(tmp_in, data[8:-32], exclusive=True)
        run_openssl(True, tmp_in, tmp_out, pw)
        plain = open(tmp_out, "rb").read()
    write_private(dst, plain, exclusive=True)
    print("Backup verificado e aberto: %s (%d bytes)" % (dst, len(plain)))


def selftest(path):
    pw = get_pass()
    data = open(path, "rb").read()
    if not verify(data, pw):
        die("autoteste: o arquivo original nao passou na verificacao.")
    n = len(data)
    for pos in sorted({0, 7, 8, 15, 16, 24, n // 2, n - 33, n - 32, n - 1}):
        bad = bytearray(data); bad[pos] ^= 0x01
        if verify(bytes(bad), pw):
            die("autoteste: alteracao no byte %d NAO foi detectada." % pos)
    for cut in (data[:-1], data[:-32], data[:n // 2], data + b"\x00", b""):
        if verify(cut, pw):
            die("autoteste: truncamento/extensao NAO foi detectado.")
    print("Autoteste: original valido; alteracoes, truncamentos e extensoes detectados.")


def main(argv):
    if len(argv) == 4 and argv[1] == "selar":
        seal(argv[2], argv[3])
    elif len(argv) == 4 and argv[1] == "abrir":
        open_backup(argv[2], argv[3])
    elif len(argv) == 3 and argv[1] == "autoteste":
        selftest(argv[2])
    else:
        sys.stderr.write(__doc__)
        sys.exit(2)


if __name__ == "__main__":
    main(sys.argv)
