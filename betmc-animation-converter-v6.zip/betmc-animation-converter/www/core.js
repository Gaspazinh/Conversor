/*
 * BetMC Animation Converter - núcleo (ZIP + análise + conversão + validação)
 * 100% offline, sem dependências. Funciona em navegador/WebView e em Node >= 18.
 * Usa Blob.slice (baixo consumo de memória) e Compression/DecompressionStream.
 */
(function (global) {
  'use strict';

  const TD = new TextDecoder('utf-8');
  const TE = new TextEncoder();

  /* ------------------------------------------------------------------ CRC32 */
  const CRC_T = (() => {
    const t = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let c = n;
      for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
      t[n] = c >>> 0;
    }
    return t;
  })();
  function crcUpdate(crc, u8) {
    let c = crc;
    for (let i = 0; i < u8.length; i++) c = CRC_T[(c ^ u8[i]) & 0xff] ^ (c >>> 8);
    return c;
  }
  function crc32(u8) { return (crcUpdate(0xffffffff, u8) ^ 0xffffffff) >>> 0; }

  /* ---------------------------------------------------------------- ZIP read */
  function readAB(blob) {
    if (typeof blob.arrayBuffer === 'function') return blob.arrayBuffer();
    return new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = () => rej(fr.error || new Error('Falha ao ler o arquivo.')); fr.readAsArrayBuffer(blob); });
  }
  async function readU8(blob, a, b) { return new Uint8Array(await readAB(blob.slice(a, b))); }

  async function openZip(blob) {
    const size = blob.size;
    if (size < 22) throw new Error('Arquivo pequeno demais para ser um ZIP/MCPACK.');
    const tailLen = Math.min(size, 65557);
    const tail = await readU8(blob, size - tailLen, size);
    let e = -1;
    for (let i = tail.length - 22; i >= 0; i--) {
      if (tail[i] === 0x50 && tail[i + 1] === 0x4b && tail[i + 2] === 5 && tail[i + 3] === 6) { e = i; break; }
    }
    if (e < 0) throw new Error('Não é um ZIP válido (fim do diretório central não encontrado).');
    const dv = new DataView(tail.buffer, tail.byteOffset + e, 22);
    const total = dv.getUint16(10, true), cdSize = dv.getUint32(12, true), cdOff = dv.getUint32(16, true);
    if (total === 0xffff || cdSize === 0xffffffff || cdOff === 0xffffffff) throw new Error('ZIP64 não é suportado.');
    if (cdOff + cdSize > size) throw new Error('Diretório central fora dos limites do arquivo.');
    const cd = await readU8(blob, cdOff, cdOff + cdSize);
    const dc = new DataView(cd.buffer, cd.byteOffset, cd.byteLength);
    const entries = [];
    let p = 0;
    for (let i = 0; i < total; i++) {
      if (p + 46 > cd.length || dc.getUint32(p, true) !== 0x02014b50) throw new Error('Diretório central corrompido.');
      const nl = dc.getUint16(p + 28, true), xl = dc.getUint16(p + 30, true), cl = dc.getUint16(p + 32, true);
      const en = {
        vmade: dc.getUint16(p + 4, true),
        flags: dc.getUint16(p + 8, true),
        method: dc.getUint16(p + 10, true),
        time: dc.getUint16(p + 12, true),
        date: dc.getUint16(p + 14, true),
        crc: dc.getUint32(p + 16, true),
        csize: dc.getUint32(p + 20, true),
        usize: dc.getUint32(p + 24, true),
        ext: dc.getUint32(p + 38, true),
        lho: dc.getUint32(p + 42, true),
        name: TD.decode(cd.subarray(p + 46, p + 46 + nl)),
      };
      if (en.csize === 0xffffffff || en.usize === 0xffffffff || en.lho === 0xffffffff) throw new Error('ZIP64 não é suportado.');
      if (en.flags & 1) throw new Error('Pacote criptografado não é suportado: ' + en.name);
      en.norm = en.name.replace(/\\/g, '/');
      en.isDir = en.norm.endsWith('/');
      entries.push(en);
      p += 46 + nl + xl + cl;
    }
    return { blob, entries };
  }

  async function dataSlice(zip, en) {
    const h = await readU8(zip.blob, en.lho, en.lho + 30);
    const dv = new DataView(h.buffer);
    if (dv.getUint32(0, true) !== 0x04034b50) throw new Error('Cabeçalho local inválido: ' + en.name);
    const start = en.lho + 30 + dv.getUint16(26, true) + dv.getUint16(28, true);
    if (start + en.csize > zip.blob.size) throw new Error('Dados fora dos limites: ' + en.name);
    return zip.blob.slice(start, start + en.csize);
  }

  async function inflate(blob) {
    if (typeof DecompressionStream === 'undefined' || typeof blob.stream !== 'function') {
      throw new Error('Este WebView/navegador não suporta DecompressionStream (requer Chrome/WebView 80+). Atualize o "Android System WebView" e o Chrome na Play Store.');
    }
    const ds = blob.stream().pipeThrough(new DecompressionStream('deflate-raw'));
    return new Uint8Array(await new Response(ds).arrayBuffer());
  }

  async function extract(zip, en) {
    const d = await dataSlice(zip, en);
    if (en.method === 0) return new Uint8Array(await readAB(d));
    if (en.method === 8) return inflate(d);
    throw new Error('Método de compressão ' + en.method + ' não suportado: ' + en.name);
  }

  /* Verifica CRC e tamanho de uma entrada sem carregar tudo na memória. */
  async function verifyEntry(zip, en) {
    const d = await dataSlice(zip, en);
    if (typeof d.stream !== 'function') throw new Error('Este WebView/navegador não suporta Blob.stream() (requer Chrome/WebView 76+).');
    let stream = d.stream();
    if (en.method === 8 && typeof DecompressionStream === 'undefined') throw new Error('Este WebView/navegador não suporta DecompressionStream (requer Chrome/WebView 80+).');
    if (en.method === 8) stream = stream.pipeThrough(new DecompressionStream('deflate-raw'));
    else if (en.method !== 0) throw new Error('Método ' + en.method + ' não suportado: ' + en.name);
    const reader = stream.getReader();
    let c = 0xffffffff, n = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      c = crcUpdate(c, value); n += value.length;
    }
    c = (c ^ 0xffffffff) >>> 0;
    if (n !== en.usize) throw new Error('Tamanho divergente em ' + en.name);
    if (c !== en.crc) throw new Error('CRC divergente em ' + en.name);
  }

  /* --------------------------------------------------------------- ZIP write */
  async function deflate(u8) {
    if (typeof CompressionStream === 'undefined') return { method: 0, data: u8 };
    const cs = new Blob([u8]).stream().pipeThrough(new CompressionStream('deflate-raw'));
    const out = new Uint8Array(await new Response(cs).arrayBuffer());
    return out.length < u8.length ? { method: 8, data: out } : { method: 0, data: u8 };
  }

  class ZipWriter {
    constructor() { this.parts = []; this.off = 0; this.cd = []; this.count = 0; }
    add(name, meta, dataBlobOrU8, csize) {
      const nb = TE.encode(name);
      let flags = meta.flags & ~0x0009; // sem criptografia e sem data-descriptor
      if (/[^\x00-\x7f]/.test(name)) flags |= 0x0800;
      const h = new Uint8Array(30 + nb.length);
      const v = new DataView(h.buffer);
      v.setUint32(0, 0x04034b50, true); v.setUint16(4, 20, true); v.setUint16(6, flags, true);
      v.setUint16(8, meta.method, true); v.setUint16(10, meta.time, true); v.setUint16(12, meta.date, true);
      v.setUint32(14, meta.crc, true); v.setUint32(18, csize, true); v.setUint32(22, meta.usize, true);
      v.setUint16(26, nb.length, true); v.setUint16(28, 0, true); h.set(nb, 30);
      const c = new Uint8Array(46 + nb.length);
      const w = new DataView(c.buffer);
      w.setUint32(0, 0x02014b50, true); w.setUint16(4, meta.vmade || 20, true); w.setUint16(6, 20, true);
      w.setUint16(8, flags, true); w.setUint16(10, meta.method, true); w.setUint16(12, meta.time, true);
      w.setUint16(14, meta.date, true); w.setUint32(16, meta.crc, true); w.setUint32(20, csize, true);
      w.setUint32(24, meta.usize, true); w.setUint16(28, nb.length, true); w.setUint32(38, meta.ext || 0, true);
      w.setUint32(42, this.off, true); c.set(nb, 46);
      this.cd.push(c);
      this.parts.push(h, dataBlobOrU8);
      this.off += h.length + csize;
      this.count++;
    }
    async addFile(name, u8, like) {
      const { method, data } = await deflate(u8);
      this.add(name, { flags: 0, method, time: like.time, date: like.date, crc: crc32(u8), usize: u8.length, vmade: like.vmade, ext: like.ext }, data, data.length);
    }
    finish() {
      let cdSize = 0;
      for (const c of this.cd) cdSize += c.length;
      const e = new Uint8Array(22);
      const v = new DataView(e.buffer);
      v.setUint32(0, 0x06054b50, true); v.setUint16(8, this.count, true); v.setUint16(10, this.count, true);
      v.setUint32(12, cdSize, true); v.setUint32(16, this.off, true);
      return new Blob([...this.parts, ...this.cd, e], { type: 'application/octet-stream' });
    }
  }

  /* -------------------------------------------------------- JSON utilities */
  function stripBom(s) { return s.charCodeAt(0) === 0xfeff ? s.slice(1) : s; }
  function parseJsonBytes(u8) {
    const raw = TD.decode(u8);
    const bom = raw.charCodeAt(0) === 0xfeff;
    const text = stripBom(raw);
    return { obj: JSON.parse(text), fmt: detectFormat(text, bom) };
  }
  function detectFormat(text, bom) {
    const nl = text.indexOf('\n');
    let indent = null;
    if (nl >= 0) {
      const m = /^[ \t]+/.exec(text.slice(nl + 1));
      indent = m ? m[0] : 2;
    }
    return { indent, bom, crlf: /\r\n/.test(text), finalNewline: /\n\s*$/.test(text) };
  }
  function serializeJson(obj, fmt) {
    let s = JSON.stringify(obj, null, fmt.indent === null ? undefined : fmt.indent);
    if (fmt.finalNewline) s += '\n';
    if (fmt.crlf) s = s.replace(/\r?\n/g, '\r\n');
    return TE.encode((fmt.bom ? '\ufeff' : '') + s);
  }
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const escRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pad = (n, w) => String(n).padStart(w, '0');
  const parsePct = (s) => {
    const m = typeof s === 'string' ? /^(-?\d+(?:\.\d+)?)%$/.exec(s) : null;
    return m ? parseFloat(m[1]) : null;
  };
  const neg = (v) => (v === 0 ? 0 : -v);

  /* ---------------------------------------------------------------- ANÁLISE */
  /**
   * Lê o pacote real e descobre, sem supor nomes, onde está a animação.
   * Retorna um objeto `info` (ou lança Error com mensagem em português).
   */
  async function analyze(blobOrZip, onProgress) {
    const zip = blobOrZip.entries ? blobOrZip : await openZip(blobOrZip);
    const entries = zip.entries;
    const warnings = [];

    // raiz do pacote = pasta do manifest.json mais próximo da raiz
    const manifests = entries.filter((e) => e.norm === 'manifest.json' || e.norm.endsWith('/manifest.json'))
      .sort((a, b) => a.norm.split('/').length - b.norm.split('/').length);
    let root = '';
    if (!manifests.length) warnings.push('manifest.json não encontrado no pacote.');
    else root = manifests[0].norm.slice(0, -'manifest.json'.length);
    if (root) warnings.push('O pacote tem uma pasta-raiz ("' + root + '") acima do manifest.json. Ela foi preservada, mas o Minecraft pode exigir o manifest.json na raiz do .mcpack.');

    // procura JSONs de animação
    const jsonEntries = entries.filter((e) => !e.isDir && /\.json$/i.test(e.norm) && e.usize <= 8 * 1024 * 1024);
    let anim = null;
    let firstReadErr = null; // erro de leitura real (ex.: WebView sem DecompressionStream) não pode virar "nenhum JSON encontrado"
    const parsed = {};
    let done = 0;
    for (const en of jsonEntries) {
      done++;
      if (onProgress) onProgress(done / jsonEntries.length);
      let u8;
      try { u8 = await extract(zip, en); } catch (e) { if (!firstReadErr) firstReadErr = e; continue; }
      const txt = TD.decode(u8);
      if (!/"frame_\d+"/.test(txt) && !/frame_\d+@/.test(txt)) { parsed[en.norm] = { text: txt }; continue; }
      let p;
      try { p = parseJsonBytes(u8); } catch (e) { warnings.push('JSON ilegível (ignorado na análise): ' + en.norm); continue; }
      parsed[en.norm] = { text: txt, ...p };
      const o = p.obj;
      if (o && typeof o === 'object' && !Array.isArray(o)) {
        const fk = Object.keys(o).filter((k) => /^frame_\d+$/.test(k) && o[k] && typeof o[k].texture === 'string');
        const ak = Object.keys(o).filter((k) => /^anim_\d+$/.test(k) && o[k] && o[k].anim_type);
        if (fk.length && ak.length) {
          if (anim) throw new Error('Mais de um JSON de animação encontrado (' + anim.path + ' e ' + en.norm + '). Não é seguro adivinhar qual usar.');
          anim = { path: en.norm, entry: en, obj: o, fmt: p.fmt, frameKeys: fk, animKeys: ak };
        }
      }
    }
    if (!anim && firstReadErr) throw firstReadErr;
    if (!anim) throw new Error('Nenhum JSON de animação (frame_N + anim_N) foi encontrado neste pacote.');

    const A = anim.obj;
    const ns = typeof A.namespace === 'string' ? A.namespace : null;
    if (!ns) throw new Error('O JSON de animação não define "namespace".');
    const n = anim.frameKeys.length;
    const nums = anim.frameKeys.map((k) => +k.slice(6)).sort((a, b) => a - b);
    for (let i = 0; i < n; i++) if (nums[i] !== i + 1) throw new Error('Os frames do JSON não são sequenciais a partir de 1 (faltando frame_' + (i + 1) + ').');
    const anums = anim.animKeys.map((k) => +k.slice(5)).sort((a, b) => a - b);
    if (anums.length !== n || anums.some((v, i) => v !== i + 1)) throw new Error('As animações anim_N não correspondem aos frames (' + anums.length + ' anim para ' + n + ' frames).');

    // textura: prefixo + número
    const widths = new Set();
    let texPrefix = null;
    for (let i = 1; i <= n; i++) {
      const m = /^(.*?)(\d+)$/.exec(A['frame_' + i].texture);
      if (!m) throw new Error('Textura de frame_' + i + ' sem número no final: ' + A['frame_' + i].texture);
      if (texPrefix === null) texPrefix = m[1];
      else if (m[1] !== texPrefix) throw new Error('Os frames usam prefixos de textura diferentes (' + texPrefix + ' / ' + m[1] + ').');
      if (+m[2] !== i) throw new Error('frame_' + i + ' aponta para a textura número ' + +m[2] + '. Sequência fora de ordem.');
      widths.add(m[2].length === String(i).length && m[2][0] !== '0' ? 'sem zeros' : m[2].length + ' dígitos');
    }

    // grade de offsets (derivada do pacote, não imposta)
    const F = (i) => A['frame_' + i];
    const fx = [], fy = [];
    for (let i = 1; i <= n; i++) {
      const o = F(i).offset;
      const x = Array.isArray(o) ? parsePct(o[0]) : null, y = Array.isArray(o) ? parsePct(o[1]) : null;
      if (x === null || y === null) throw new Error('Offset de frame_' + i + ' fora do padrão esperado ("N%", "N%").');
      fx.push(x); fy.push(y);
    }
    const grid = { x0: fx[0], y0: fy[0], dx: n > 1 ? fx[1] - fx[0] : 100, dy: 100, cols: null, assumed: false };
    for (let i = 1; i < n; i++) if (fx[i] <= fx[i - 1]) { grid.cols = i; break; }
    if (grid.cols === null) { grid.cols = 31; grid.assumed = true; warnings.push('O pacote original cabe em uma única linha de offsets; assumindo 31 colunas ao ultrapassar essa linha.'); }
    if (n > grid.cols) grid.dy = fy[grid.cols] - fy[0];
    for (let i = 0; i < n; i++) {
      const ex = grid.x0 + grid.dx * (i % grid.cols), ey = grid.y0 + grid.dy * Math.floor(i / grid.cols);
      if (fx[i] !== ex || fy[i] !== ey) throw new Error('Os offsets do frame_' + (i + 1) + ' não seguem a grade regular detectada (' + fx[i] + '%,' + fy[i] + '% em vez de ' + ex + '%,' + ey + '%). Para não corromper a animação, a conversão foi recusada.');
    }
    // propriedades do frame iguais (fora texture/offset)
    const sig = (o) => JSON.stringify(Object.keys(o).filter((k) => k !== 'texture' && k !== 'offset').map((k) => [k, o[k]]));
    const s1 = sig(F(1));
    for (let i = 2; i <= n; i++) if (sig(F(i)) !== s1) throw new Error('frame_' + i + ' tem propriedades diferentes do frame_1; estrutura não uniforme.');

    // anims: from/to = -offset, encadeamento, duração
    const durations = new Set();
    for (let i = 1; i <= n; i++) {
      const a = A['anim_' + i];
      const exp = [neg(fx[i - 1]) + '%', neg(fy[i - 1]) + '%'];
      if (JSON.stringify(a.from) !== JSON.stringify(exp) || JSON.stringify(a.to) !== JSON.stringify(exp)) throw new Error('anim_' + i + ' não segue o padrão (from/to = -offset do frame_' + i + ').');
      const nx = '@' + ns + '.anim_' + (i === n ? 1 : i + 1);
      if (a.next !== nx) throw new Error('anim_' + i + '.next = "' + a.next + '", esperado "' + nx + '".');
      durations.add(a.duration);
    }
    if (durations.size !== 1) throw new Error('As animações têm durações diferentes entre si.');
    const duration = [...durations][0];
    if (Math.abs(duration - 1 / 24) > 1e-4) warnings.push('Duração por frame original = ' + duration + ' s (≠ 24 FPS). Foi preservada como está.');

    // JSON que monta os controles
    let bg = null;
    const ctlRe = new RegExp('^frame_(\\d+)@' + escRe(ns) + '\\.frame_(\\d+)$');
    for (const [path, p] of Object.entries(parsed)) {
      if (!p.obj || path === anim.path) continue;
      for (const [k, v] of Object.entries(p.obj)) {
        if (v && Array.isArray(v.controls) && v.controls.some((c) => c && Object.keys(c).some((kk) => ctlRe.test(kk)))) {
          if (bg) throw new Error('Mais de um JSON referencia os frames (' + bg.path + ' e ' + path + ').');
          bg = { path, entry: entries.find((e) => e.norm === path), obj: p.obj, fmt: p.fmt, key: k };
        }
      }
    }
    if (!bg) throw new Error('Nenhum JSON com os controles "frame_N@' + ns + '.frame_N" foi encontrado.');
    const ctrls = bg.obj[bg.key].controls;
    const ctlFrames = ctrls.filter((c) => c && Object.keys(c).some((kk) => ctlRe.test(kk)));
    if (ctlFrames.length !== n) warnings.push('O JSON de controles tem ' + ctlFrames.length + ' frames, mas a animação tem ' + n + '. Serão alinhados ao novo total.');
    // referências em outros JSONs
    const others = Object.entries(parsed).filter(([p, v]) => p !== anim.path && p !== bg.path && v.text && new RegExp(escRe(ns) + '\\.(frame|anim)_\\d+').test(v.text)).map(([p]) => p);
    if (others.length) warnings.push('Outros JSONs referenciam a animação e NÃO serão alterados: ' + others.join(', '));

    // listas auxiliares
    const texList = entries.find((e) => e.norm === root + 'textures/textures_list.json') || null;
    const contents = entries.find((e) => e.norm === root + 'contents.json') || null;

    // PNGs físicos dos frames
    const pngRe = new RegExp('^((?:.*/)?)' + escRe(texPrefix) + '(\\d+)\\.png$');
    const physical = [];
    for (const en of entries) {
      const m = pngRe.exec(en.norm);
      if (!m) continue;
      if (m[1] && !m[1].endsWith('/')) { /* o prefixo da textura inclui pasta; exige limite de pasta */ }
      physical.push({ entry: en, dir: m[1], num: +m[2], digits: m[2] });
    }
    return { zip, root, ns, n, texPrefix, widths: [...widths], grid, duration, anim, bg, texList, contents, physical, warnings, parsed };
  }

  /* -------------------------------------------------------------- CONVERSÃO */
  function validateCount(v) {
    const s = String(v).trim();
    if (!/^\d+$/.test(s)) return null;
    const n = parseInt(s, 10);
    return n >= 1 && n <= 100000 ? n : null;
  }

  async function convert(info, N, onProgress) {
    const P = (f, msg) => onProgress && onProgress(f, msg);
    N = validateCount(N);
    if (!N) throw new Error('Quantidade de frames inválida.');
    const { zip, ns, grid, texPrefix, root } = info;
    const W = Math.max(3, String(N).length);
    const warnings = [...info.warnings];
    if (N > 999) warnings.push('Mais de 999 frames: a numeração usa ' + W + ' dígitos.');
    const maxRows = Math.floor((N - 1) / grid.cols);
    if (grid.y0 + grid.dy * maxRows > 1500) warnings.push('A grade de offsets passa de 1500% (limite usado pelo pacote original). Teste no jogo.');
    const mod = new Map(); // norm path -> Uint8Array novo conteúdo

    P(0.05, 'Atualizando JSON da animação…');
    // ---- animação
    const A = info.anim.obj, out = {};
    const f1 = A.frame_1, a1 = A.anim_1;
    const offAt = (i) => {
      const c = (i - 1) % grid.cols, r = Math.floor((i - 1) / grid.cols);
      return [grid.x0 + grid.dx * c, grid.y0 + grid.dy * r];
    };
    const mkFrame = (i) => {
      const o = i <= info.n ? clone(A['frame_' + i]) : clone(f1);
      const [x, y] = offAt(i);
      o.texture = texPrefix + pad(i, W);
      o.offset = [x + '%', y + '%'];
      return o;
    };
    const mkAnim = (i) => {
      const o = i <= info.n ? clone(A['anim_' + i]) : clone(a1);
      const [x, y] = offAt(i);
      o.next = '@' + ns + '.anim_' + (i === N ? 1 : i + 1);
      o.from = [neg(x) + '%', neg(y) + '%'];
      o.to = [neg(x) + '%', neg(y) + '%'];
      o.duration = info.duration;
      return o;
    };
    let fDone = false, aDone = false;
    for (const k of Object.keys(A)) {
      if (/^frame_\d+$/.test(k) && A[k] && typeof A[k].texture === 'string') {
        if (!fDone) { for (let i = 1; i <= N; i++) out['frame_' + i] = mkFrame(i); fDone = true; }
      } else if (/^anim_\d+$/.test(k) && A[k] && A[k].anim_type) {
        if (!aDone) { for (let i = 1; i <= N; i++) out['anim_' + i] = mkAnim(i); aDone = true; }
      } else out[k] = A[k];
    }
    mod.set(info.anim.path, serializeJson(out, info.anim.fmt));

    // ---- controles
    P(0.15, 'Atualizando controles…');
    const B = clone(info.bg.obj);
    const panel = B[info.bg.key];
    const ctlRe = new RegExp('^frame_(\\d+)@' + escRe(ns) + '\\.frame_(\\d+)$');
    const isFrameCtl = (c) => c && Object.keys(c).length === 1 && ctlRe.test(Object.keys(c)[0]);
    const oldFrameCtls = panel.controls.filter(isFrameCtl);
    const ctlTpl = oldFrameCtls.length ? oldFrameCtls[0][Object.keys(oldFrameCtls[0])[0]] : {};
    const newCtls = [];
    for (let i = 1; i <= N; i++) newCtls.push({ ['frame_' + i + '@' + ns + '.frame_' + i]: clone(ctlTpl) });
    // preserva eventuais valores de controles já existentes
    oldFrameCtls.forEach((c) => {
      const k = Object.keys(c)[0], i = +ctlRe.exec(k)[1];
      if (i <= N) newCtls[i - 1] = c;
    });
    const rebuilt = []; let inserted = false;
    for (const c of panel.controls) {
      if (isFrameCtl(c)) { if (!inserted) { rebuilt.push(...newCtls); inserted = true; } } else rebuilt.push(c);
    }
    panel.controls = rebuilt;
    mod.set(info.bg.path, serializeJson(B, info.bg.fmt));

    // ---- textures_list.json
    P(0.25, 'Atualizando lista de texturas…');
    if (info.texList) {
      const p = parseJsonBytes(await extract(zip, info.texList));
      const L = p.obj;
      const re = new RegExp('^' + escRe(texPrefix) + '\\d+$');
      if (Array.isArray(L)) {
        const first = L.findIndex((s) => typeof s === 'string' && re.test(s));
        if (first >= 0) {
          const res = []; let ins = false;
          for (const s of L) {
            if (typeof s === 'string' && re.test(s)) { if (!ins) { for (let i = 1; i <= N; i++) res.push(texPrefix + pad(i, W)); ins = true; } } else res.push(s);
          }
          mod.set(info.texList.norm, serializeJson(res, p.fmt));
        } else warnings.push('textures_list.json não lista os frames; mantido sem alteração.');
      }
    }

    // ---- contents.json
    P(0.3, 'Atualizando contents.json…');
    if (info.contents) {
      const p = parseJsonBytes(await extract(zip, info.contents));
      const C = p.obj;
      const pngRe = new RegExp('^((?:.*/)?)' + escRe(texPrefix) + '(\\d+)\\.png$');
      if (C && Array.isArray(C.content)) {
        const isF = (e) => e && typeof e.path === 'string' && pngRe.test(e.path);
        const dirs = [];
        C.content.forEach((e) => { if (isF(e)) { const d = pngRe.exec(e.path)[1]; if (!dirs.includes(d)) dirs.push(d); } });
        if (dirs.length) {
          const tpl = C.content.find(isF);
          const res = []; const seen = new Set();
          for (const e of C.content) {
            if (!isF(e)) { res.push(e); continue; }
            const d = pngRe.exec(e.path)[1];
            if (seen.has(d)) continue;
            seen.add(d);
            for (let i = 1; i <= N; i++) { const ne = clone(tpl); ne.path = d + texPrefix + pad(i, W) + '.png'; res.push(ne); }
          }
          C.content = res;
          mod.set(info.contents.norm, serializeJson(C, p.fmt));
        } else warnings.push('contents.json não lista os PNGs dos frames; mantido sem alteração.');
      }
    }

    // ---- PNGs físicos
    P(0.35, 'Organizando imagens dos frames…');
    const rename = new Map(); // entry -> novo nome (raw) ou null (remover)
    const targets = new Map();
    let removed = 0, renamed = 0;
    const presentNums = new Set();
    for (const ph of info.physical) {
      if (ph.num > N) { rename.set(ph.entry, null); removed++; continue; }
      const newNorm = ph.dir + texPrefix + pad(ph.num, W) + '.png';
      if (targets.has(newNorm)) throw new Error('Dois arquivos de frame resultariam no mesmo nome: ' + newNorm);
      targets.set(newNorm, ph.entry);
      presentNums.add(ph.num);
      if (newNorm !== ph.entry.norm) { rename.set(ph.entry, newNorm); renamed++; }
    }
    const missing = N - presentNums.size;
    if (missing > 0) warnings.push('Faltam ' + missing + ' imagens de frame no pacote (' + presentNums.size + ' de ' + N + ' presentes). Adicione manualmente os PNGs ezgif-frame-' + pad(1, W) + ' até ezgif-frame-' + pad(N, W) + '. Nenhuma imagem foi gerada.');

    // ---- escreve o novo ZIP
    P(0.4, 'Montando o novo pacote…');
    const zw = new ZipWriter();
    const total = zip.entries.length;
    let idx = 0;
    for (const en of zip.entries) {
      idx++;
      if (idx % 20 === 0) P(0.4 + 0.45 * (idx / total), 'Montando o novo pacote…');
      if (mod.has(en.norm)) { await zw.addFile(en.name, mod.get(en.norm), en); continue; }
      if (rename.has(en)) {
        const nn = rename.get(en);
        if (nn === null) continue;
        const name = en.name.includes('\\') ? nn.replace(/\//g, '\\') : nn;
        zw.add(name, en, await dataSlice(zip, en), en.csize);
        continue;
      }
      zw.add(en.name, en, en.isDir ? new Uint8Array(0) : await dataSlice(zip, en), en.isDir ? 0 : en.csize);
    }
    const blob = zw.finish();
    P(0.9, 'Pacote montado.');
    return { blob, N, W, warnings, stats: { removed, renamed, present: presentNums.size, missing, modified: [...mod.keys()], root } };
  }

  /* --------------------------------------------------------------- VALIDAÇÃO */
  async function validate(outBlob, N, srcInfo, convResult, onProgress) {
    const checks = [];
    const add = (id, label, ok, detail, level) => checks.push({ id, label, ok, detail: detail || '', level: level || (ok ? 'ok' : 'error') });
    const W = Math.max(3, String(N).length);

    // 1. ZIP abre e todas as entradas conferem CRC/tamanho
    let zip;
    try {
      zip = await openZip(outBlob);
      let i = 0;
      for (const en of zip.entries) { if (!en.isDir) await verifyEntry(zip, en); i++; if (onProgress) onProgress(i / zip.entries.length); }
      add('zip', 'Arquivo .mcpack abre corretamente (CRC de todas as entradas confere)', true, zip.entries.length + ' entradas');
    } catch (e) {
      add('zip', 'Arquivo .mcpack abre corretamente', false, e.message);
      return { ok: false, checks };
    }

    // 2. JSONs válidos
    const modifiedSet = new Set(convResult.stats.modified);
    let jsonErr = [];
    for (const en of zip.entries) {
      if (en.isDir || !/\.json$/i.test(en.norm)) continue;
      try { parseJsonBytes(await extract(zip, en)); } catch (e) {
        if (modifiedSet.has(en.norm)) jsonErr.push(en.norm);
      }
    }
    add('json', 'Todos os JSONs alterados são válidos', jsonErr.length === 0, jsonErr.join(', '));

    // 3. reanálise independente do pacote de saída
    let info2 = null;
    try { info2 = await analyze(zip); } catch (e) { add('reanalyze', 'Estrutura da animação reconhecida no pacote final', false, e.message); return { ok: false, checks }; }
    add('reanalyze', 'Estrutura da animação reconhecida no pacote final (grade e encadeamento íntegros)', true);

    const A = info2.anim.obj, ns = info2.ns;
    add('count_frames', 'Quantidade de frames = ' + N, info2.n === N, 'frames: ' + info2.n);
    let animCount = Object.keys(A).filter((k) => /^anim_\d+$/.test(k)).length;
    add('count_anims', 'Quantidade de animações (anim_N) = ' + N, animCount === N, 'anim: ' + animCount);
    const ctl = info2.bg.obj[info2.bg.key].controls.filter((c) => c && Object.keys(c).some((k) => /^frame_\d+@/.test(k))).length;
    add('count_controls', 'Quantidade de controles de frame = ' + N, ctl === N, 'controles: ' + ctl);

    // 4. três dígitos
    const re = new RegExp('^' + escRe(info2.texPrefix) + '\\d{' + W + '}$');
    let badTex = 0;
    for (let i = 1; i <= N; i++) if (!re.test(A['frame_' + i].texture) || !A['frame_' + i].texture.endsWith(pad(i, W))) badTex++;
    add('digits', 'Nomenclatura com ' + W + ' dígitos em todas as referências', badTex === 0, badTex ? badTex + ' referências fora do padrão' : '');

    // 5. referências acima do limite (varre todos os JSONs)
    let over = [];
    const refRe = new RegExp('(?:frame_|anim_|' + escRe(info2.texPrefix) + ')(\\d+)', 'g');
    for (const en of zip.entries) {
      if (en.isDir || !/\.json$/i.test(en.norm) || en.usize > 8 * 1024 * 1024) continue;
      const txt = TD.decode(await extract(zip, en));
      let m; refRe.lastIndex = 0; let mx = 0;
      while ((m = refRe.exec(txt))) mx = Math.max(mx, +m[1]);
      if (mx > N && /(frame_|anim_|ezgif)/.test(txt)) over.push(en.norm + ' (máx ' + mx + ')');
    }
    add('over', 'Nenhuma referência acima do frame ' + N, over.length === 0, over.join('; '));

    // 6. loop
    add('loop', 'Último frame retorna ao primeiro (anim_' + N + ' → anim_1)', A['anim_' + N].next === '@' + ns + '.anim_1', A['anim_' + N].next);
    let chainBad = 0;
    for (let i = 1; i < N; i++) if (A['anim_' + i].next !== '@' + ns + '.anim_' + (i + 1)) chainBad++;
    add('chain', 'Sequência 001 → 002 → … → ' + pad(N, W) + ' contínua', chainBad === 0, chainBad ? chainBad + ' quebras' : '');

    // 7. velocidade
    const durs = new Set(); for (let i = 1; i <= N; i++) durs.add(A['anim_' + i].duration);
    add('fps', 'Duração por frame preservada (' + srcInfo.duration + ' s ≈ 24 FPS)', durs.size === 1 && [...durs][0] === srcInfo.duration, [...durs].join(', '));

    // 8. listas
    if (info2.texList) {
      const L = parseJsonBytes(await extract(zip, info2.texList)).obj;
      const c = L.filter((s) => typeof s === 'string' && re.test(s)).length;
      const all = L.filter((s) => typeof s === 'string' && s.startsWith(info2.texPrefix)).length;
      add('texlist', 'textures_list.json lista exatamente ' + N + ' frames', c === N && all === N, 'listados: ' + all);
    }
    if (info2.contents) {
      const C = parseJsonBytes(await extract(zip, info2.contents)).obj.content;
      const pr = new RegExp(escRe(info2.texPrefix) + '(\\d+)\\.png$');
      const byDir = {};
      C.forEach((e) => { const m = pr.exec(e.path); if (m) { const d = e.path.slice(0, m.index); byDir[d] = (byDir[d] || 0) + 1; } });
      const bad = Object.entries(byDir).filter(([, v]) => v !== N);
      add('contents', 'contents.json lista exatamente ' + N + ' PNGs de frame por pasta', Object.keys(byDir).length > 0 && bad.length === 0, JSON.stringify(byDir));
    }

    // 9. PNGs físicos
    const badPng = info2.physical.filter((p) => p.num > N || p.digits.length !== W);
    add('png', 'PNGs presentes têm nome com ' + W + ' dígitos e número ≤ ' + N, badPng.length === 0, badPng.map((p) => p.entry.norm).join(', '));

    // 10. arquivos não relacionados preservados byte a byte (CRC)
    const srcCrc = new Map(srcInfo.zip.entries.map((e) => [e.norm, e.crc]));
    const keptBad = [];
    for (const en of zip.entries) {
      if (en.isDir || modifiedSet.has(en.norm)) continue;
      const orig = srcCrc.get(en.norm);
      if (orig !== undefined && orig !== en.crc) keptBad.push(en.norm);
    }
    add('preserved', 'Arquivos não relacionados à animação preservados sem alteração', keptBad.length === 0, keptBad.join(', '));

    // avisos
    const missing = convResult.stats.missing;
    if (missing > 0) add('missing', 'Imagens dos frames presentes no pacote: ' + convResult.stats.present + ' de ' + N, true, 'Adicione manualmente as ' + missing + ' imagens restantes.', 'warn');
    return { ok: checks.every((c) => c.ok), checks };
  }

  /* ---------------------------------------------------------------- NOMES */
  function suggestName(inputName, N) {
    let base = String(inputName || 'Animation').replace(/\.(mcpack|zip)$/i, '');
    const m = /^(.*?)(\d+)([ _-]*Frames)/i.exec(base);
    if (m) return m[1] + N + m[3] + '.mcpack';
    return base + '_' + N + '_Frames.mcpack';
  }

  function features() {
    return {
      DecompressionStream: typeof DecompressionStream !== 'undefined',
      CompressionStream: typeof CompressionStream !== 'undefined',
      blobStream: typeof Blob !== 'undefined' && typeof Blob.prototype.stream === 'function',
      blobArrayBuffer: typeof Blob !== 'undefined' && typeof Blob.prototype.arrayBuffer === 'function',
    };
  }
  global.BetmcCore = { features, openZip, extract, analyze, convert, validate, validateCount, suggestName, crc32, pad };
  if (typeof module !== 'undefined' && module.exports) module.exports = global.BetmcCore;
})(typeof globalThis !== 'undefined' ? globalThis : this);
