/*
 * BetMC — REGRA GLOBAL: NUNCA traduzir automaticamente identificadores técnicos.
 *
 * Passam SEMPRE exatamente como vieram (nunca traduzidos, normalizados, abrevi­ados ou "corrigidos"):
 *   nomes de addons, de arquivos, de pastas, IDs, UUIDs, variáveis, chaves de JSON, namespaces, identificadores,
 *   nomes de pacotes e de recursos. Exemplo: "mommy" NÃO vira "mamãe".
 * Só texto escrito para a INTERFACE do usuário (rótulos, mensagens, instruções) pode passar por tradução.
 *
 * Qualquer camada de tradução futura deve chamar translate(kind, texto, dicionario): para kind diferente de 'ui' o texto volta intacto.
 * Teste: tests/v6_tests.js. Regra completa para quem mantém o projeto: REGRAS_DO_PROJETO.md.
 */
(function (global) {
  'use strict';
  /** Tipos que NUNCA são traduzidos. */
  const TECHNICAL = ['addon', 'file', 'folder', 'id', 'uuid', 'variable', 'key', 'namespace', 'identifier', 'package', 'resource'];
  const isTechnical = (kind) => TECHNICAL.indexOf(kind) >= 0;

  /** kind = 'ui' → traduz se o texto exato estiver no dicionário; qualquer outro kind → devolve o texto original, sem tocar. */
  function translate(kind, text, dict) {
    if (kind !== 'ui') return text;
    return dict && Object.prototype.hasOwnProperty.call(dict, text) ? dict[text] : text;
  }
  /** Garante (e documenta) que um identificador técnico não foi alterado por nenhuma etapa. */
  function assertUnchanged(kind, before, after) {
    if (isTechnical(kind) && before !== after) throw new Error('Identificador técnico alterado (' + kind + '): "' + before + '" → "' + after + '"');
    return after;
  }
  global.BetmcNames = { TECHNICAL, isTechnical, translate, assertUnchanged };
  if (typeof module !== 'undefined' && module.exports) module.exports = global.BetmcNames;
})(typeof globalThis !== 'undefined' ? globalThis : this);
