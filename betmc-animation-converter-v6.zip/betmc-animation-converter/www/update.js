/*
 * BetMC — decisão de ATUALIZAÇÃO (lógica pura, sem DOM e sem rede; testável em Node: tests/v6_tests.js).
 * A rede e o instalador ficam no Kotlin (Updater.kt). Aqui: validar o update.json e decidir "nada / opcional / obrigatória".
 *
 * update.json (hospedado em https://raw.githubusercontent.com/Gaspazinh/Conversor/main/update.json):
 *   { "schema": 1, "latestVersionCode": 60000, "latestVersionName": "6.0.0", "minVersionCode": 60000, "mandatory": false,
 *     "apkUrl": "https://github.com/Gaspazinh/Conversor/releases/download/v6.0.0/BetMC-6.0.0.apk", "apkSize": 12345678,
 *     "sha256": "<64 hex>", "notes": ["…"], "publishedAt": "2026-11-20" }
 */
(function (global) {
  'use strict';
  const APK_PREFIX = 'https://github.com/Gaspazinh/Conversor/releases/download/';
  const MAX_APK = 250 * 1024 * 1024;
  const isInt = (x) => typeof x === 'number' && Number.isInteger(x);

  /** Valida o texto do update.json. Devolve { ok:true, info } ou { ok:false, err }. */
  function parse(text) {
    let j;
    try { j = JSON.parse(String(text).replace(/^\uFEFF/, '')); } catch (e) { return { ok: false, err: 'O arquivo de atualização não é um JSON válido.' }; }
    if (!j || typeof j !== 'object' || Array.isArray(j)) return { ok: false, err: 'O arquivo de atualização está num formato inesperado.' };
    if (!isInt(j.latestVersionCode) || j.latestVersionCode < 1) return { ok: false, err: 'latestVersionCode inválido.' };
    if (typeof j.latestVersionName !== 'string' || !/^[0-9A-Za-z][0-9A-Za-z.+_-]{0,31}$/.test(j.latestVersionName)) return { ok: false, err: 'latestVersionName inválido.' };
    const min = j.minVersionCode === undefined ? 0 : j.minVersionCode;
    if (!isInt(min) || min < 0 || min > j.latestVersionCode) return { ok: false, err: 'minVersionCode inválido (deve estar entre 0 e a versão mais recente).' };
    if (j.mandatory !== undefined && typeof j.mandatory !== 'boolean') return { ok: false, err: 'mandatory deve ser true ou false.' };
    const url = j.apkUrl;
    if (typeof url !== 'string' || url.length > 300 || !url.startsWith(APK_PREFIX) || !/\.apk$/i.test(url) || /[\s\\]|\.\.|[?#]/.test(url.slice(APK_PREFIX.length - 1))) return { ok: false, err: 'apkUrl fora do repositório de Releases permitido.' };
    if (typeof j.sha256 !== 'string' || !/^[0-9a-fA-F]{64}$/.test(j.sha256)) return { ok: false, err: 'sha256 ausente ou inválido.' };
    let size = 0;
    if (j.apkSize !== undefined) { if (!isInt(j.apkSize) || j.apkSize < 1 || j.apkSize > MAX_APK) return { ok: false, err: 'apkSize inválido.' }; size = j.apkSize; }
    let notes = j.notes === undefined ? [] : j.notes;
    if (typeof notes === 'string') notes = [notes];
    if (!Array.isArray(notes) || notes.length > 30 || notes.some((n) => typeof n !== 'string' || n.length > 300)) return { ok: false, err: 'notes inválido.' };
    notes = notes.map((n) => n.trim()).filter(Boolean);
    return { ok: true, info: { latestVersionCode: j.latestVersionCode, latestVersionName: j.latestVersionName, minVersionCode: min, mandatory: j.mandatory === true, apkUrl: url, apkSize: size, sha256: j.sha256.toLowerCase(), notes, publishedAt: typeof j.publishedAt === 'string' ? j.publishedAt.slice(0, 40) : '' } };
  }

  /**
   * Decide o que mostrar. currentCode = versionCode instalado; rememberedRequired = maior versão exigida já conhecida neste aparelho.
   *  - 'none'      → está atualizado;
   *  - 'optional'  → há versão mais nova; o usuário pode continuar;
   *  - 'mandatory' → versão atual abaixo da mínima OU atualização marcada como obrigatória: bloqueia as funções principais.
   * required = versão que precisa ser guardada no aparelho para manter o bloqueio mesmo sem internet.
   */
  function decide(info, currentCode) {
    const newer = info.latestVersionCode > currentCode;
    if (!newer) return { state: 'none', required: 0 };
    const mandatory = info.mandatory || currentCode < info.minVersionCode;
    return { state: mandatory ? 'mandatory' : 'optional', required: mandatory ? Math.max(info.minVersionCode, info.mandatory ? info.latestVersionCode : 0) : 0 };
  }
  /** Sem internet: se já se soube que esta versão é abaixo da exigida, continua bloqueado (sem inventar dados). */
  function decideOffline(currentCode, rememberedRequired) {
    return rememberedRequired > currentCode ? { state: 'mandatory-offline', required: rememberedRequired } : { state: 'unknown', required: 0 };
  }
  function apkFileName(info) { return 'BetMC-' + String(info.latestVersionName).replace(/[^0-9A-Za-z._-]/g, '_') + '.apk'; }

  global.BetmcUpdate = { APK_PREFIX, parse, decide, decideOffline, apkFileName };
  if (typeof module !== 'undefined' && module.exports) module.exports = global.BetmcUpdate;
})(typeof globalThis !== 'undefined' ? globalThis : this);
