/*
 * BetMC V6 — interface de: INSTALAR NO MINECRAFT, PRIMEIRA INSTALAÇÃO (textura-base) e ATUALIZAÇÃO.
 * O que a V5 já fazia continua em video_ui.js. Aqui só há o que é novo; tudo depende da ponte Android (AndroidBridge) e some sem ela.
 * Rede e instalador: Kotlin (Updater.kt, PackInstaller.kt). Decisão de atualização: update.js. Regra de nomes: names.js.
 */
(function () {
  'use strict';
  var B = window.AndroidBridge, $ = function (id) { return document.getElementById(id); };
  var Diag = window.BetmcDiag || { log: function () {}, error: function () {}, tap: function () {} };
  var hasInstaller = !!(B && B.installPack && B.installBase);
  var hasUpdater = !!(B && B.checkUpdate && B.downloadUpdate && B.currentVersion);
  var U = window.BetmcUpdate;
  function say(id, text, cls) { var e = $(id); if (!e) return; e.textContent = text || ''; e.className = 'msg' + (cls ? ' ' + cls : ''); }
  function setDisabled(id, v) { var e = $(id); if (e) e.setAttribute('aria-disabled', v ? 'true' : 'false'); }
  function disabled(id) { return $(id).getAttribute('aria-disabled') === 'true'; }
  function tap(id, fn) { $(id).addEventListener('click', function () { Diag.tap($(id).textContent.trim().slice(0, 40)); if (window.__betmcLocked && id !== 'btnUpdGo' && id !== 'btnUpdLater') return; fn(); }); }

  /* ---------------------------------------------------------------- INSTALAR NO MINECRAFT / TEXTURA-BASE */
  var installing = false;
  function runInstall(kind) {
    if (installing) return;
    installing = true; var id = kind === 'base' ? 'msgBase' : 'msgInstall';
    say(id, 'Preparando o arquivo…', 'warn'); setDisabled(kind === 'base' ? 'btnBase' : 'btnInstall', true);
    try { kind === 'base' ? B.installBase() : B.installPack(); }
    catch (e) { window.__onInstallResult(kind, { ok: false, code: 'bridge', msg: 'Não foi possível acionar a instalação (' + e + ').' }); }
  }
  window.__onInstallResult = function (kind, r) {
    installing = false; r = r || {};
    say(kind === 'base' ? 'msgBase' : 'msgInstall', r.msg || (r.ok ? 'Abrindo no Minecraft.' : 'Não foi possível abrir.'), r.ok ? 'ok' : 'err');
    setDisabled('btnBase', false);
    if (kind === 'base') return;
    syncInstallBtn();
  };
  function syncInstallBtn() {   // INSTALAR NO MINECRAFT acompanha o botão de salvar: só habilita depois da verificação do MCPACK
    var save = $('btnSave'), b = $('btnInstall');
    b.hidden = !hasInstaller || save.hidden;
    b.setAttribute('aria-disabled', installing ? 'true' : (save.getAttribute('aria-disabled') || 'true'));
  }
  if (hasInstaller) {
    tap('btnInstall', function () { if (!disabled('btnInstall')) runInstall('pack'); });
    tap('btnBase', function () { runInstall('base'); });
    new MutationObserver(syncInstallBtn).observe($('btnSave'), { attributes: true, attributeFilter: ['hidden', 'aria-disabled'] });
    syncInstallBtn();
  }
  // cartão PRIMEIRA INSTALAÇÃO: na tela inicial e com um vídeo escolhido
  function syncFirst() {
    var m = $('app').getAttribute('data-mode');
    $('pFirst').hidden = !(hasInstaller && (m === 'empty' || m === 'ready'));
    if (hasInstaller) syncInstallBtn();
  }
  new MutationObserver(syncFirst).observe($('app'), { attributes: true, attributeFilter: ['data-mode'] });
  syncFirst();
  $('tutBtn').addEventListener('click', function () {
    var open = $('tutBody').hidden; $('tutBody').hidden = !open; $('tutBtn').setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  // captura de tela real do Minecraft: www/img/tutorial_ordem_pacotes.jpg (original em docs/img/). Se o arquivo faltar ou não carregar, volta o espaço reservado (e a legenda some)
  (function () {
    var im = $('tutShot'), ph = $('shotPh');
    function none() { im.hidden = true; $('shotCap').hidden = true; ph.hidden = false; }
    im.addEventListener('error', none);
    if (im.complete && im.naturalWidth === 0) none();
  })();

  /* ---------------------------------------------------------------- ATUALIZAÇÃO */
  var upd = { info: null, cur: null, state: 'none', downloading: false, downloaded: false, dismissed: false };
  function lock(on) {
    window.__betmcLocked = !!on;
    if (on) $('app').setAttribute('data-locked', '1'); else $('app').removeAttribute('data-locked');
  }
  function curVersion() { try { return JSON.parse(B.currentVersion()); } catch (e) { return { code: 0, name: '?' }; } }
  function showPanel(state, info) {
    upd.state = state; upd.info = info; var cur = upd.cur || curVersion();
    var mand = state !== 'optional';
    $('updTitle').textContent = mand ? 'Atualização obrigatória' : 'Atualização disponível';
    $('updVer').textContent = info ? 'Versão instalada ' + cur.name + ' → nova versão ' + info.latestVersionName : 'Versão instalada ' + cur.name;
    $('updLead').textContent = state === 'mandatory-offline'
      ? 'Esta versão do BETMC não é mais permitida. Conecte-se à internet e verifique de novo para atualizar.'
      : mand ? 'Para continuar usando o BETMC, atualize para a versão mais recente. As funções de conversão ficam bloqueadas até lá.'
             : 'Há uma versão nova do BETMC. Você pode atualizar agora ou continuar usando esta versão.';
    var ul = $('updNotes'); ul.innerHTML = '';
    ((info && info.notes) || []).forEach(function (n) { var li = document.createElement('li'); li.textContent = n; ul.appendChild(li); });   // textContent: o texto do GitHub nunca vira HTML
    $('updBarWrap').hidden = true; $('updBar').style.width = '0%'; say('msgUpd', '', '');
    $('btnUpdGo').querySelector('span').textContent = state === 'mandatory-offline' ? 'VERIFICAR DE NOVO' : 'BAIXAR ATUALIZAÇÃO';
    setDisabled('btnUpdGo', false); $('btnUpdLater').hidden = mand; $('btnUpdLater').textContent = 'AGORA NÃO';
    upd.downloading = false; upd.downloaded = false;
    $('pUpdate').hidden = false; $('updSoft').hidden = true;
    lock(mand);
    window.scrollTo(0, 0);
  }
  function hidePanel() { $('pUpdate').hidden = true; lock(false); }
  function soft(text) { var e = $('updSoft'); e.textContent = text; e.hidden = !text; }

  var manual = false;
  function check(isManual) {
    if (!hasUpdater) return;
    manual = !!isManual; upd.cur = curVersion();
    var rem = typeof B.requiredCode === 'function' ? B.requiredCode() : 0;
    var off = U.decideOffline(upd.cur.code, rem);
    if (off.state === 'mandatory-offline' && upd.state !== 'mandatory') showPanel('mandatory-offline', null);   // continua bloqueado mesmo sem internet
    if (manual) soft('Verificando atualizações…');
    try { B.checkUpdate(); } catch (e) { window.__onUpdateCheck({ ok: false, code: 'bridge', msg: String(e) }); }
  }
  window.__onUpdateCheck = function (r) {
    r = r || {}; var cur = { code: r.currentCode || (upd.cur && upd.cur.code) || 0, name: r.currentName || (upd.cur && upd.cur.name) || '?' }; upd.cur = cur;
    if (!r.ok) {
      Diag.log('atualização: ' + (r.code || '?') + ' ' + (r.msg || ''));
      if (upd.state === 'mandatory-offline') say('msgUpd', 'Sem conexão com o GitHub. Verifique a internet e tente de novo.', 'err');
      else if (manual) soft('Não foi possível verificar atualizações agora. Confira a conexão e tente de novo.');
      return;
    }
    var p = U.parse(r.text);
    if (!p.ok) { Diag.log('atualização: arquivo inválido — ' + p.err); if (manual) soft('O arquivo de atualização publicado está inválido. Tente mais tarde.'); return; }
    var d = U.decide(p.info, cur.code);
    if (typeof B.rememberRequired === 'function') B.rememberRequired(d.required);   // 0 quando nada é exigido: limpa o bloqueio guardado
    if (d.state === 'none') { if (upd.state === 'mandatory-offline' || upd.state === 'mandatory') hidePanel(); upd.state = 'none'; if (manual) soft('Você já usa a versão mais recente (' + cur.name + ').'); return; }
    if (d.state === 'optional' && upd.dismissed && !manual) return;
    showPanel(d.state, p.info);
  };

  function startDownload() {
    if (upd.state === 'mandatory-offline') { check(true); return; }
    if (!upd.info || upd.downloading) return;
    if (upd.downloaded) { setDisabled('btnUpdGo', true); say('msgUpd', 'Abrindo a instalação…', 'warn'); try { B.installUpdate(); } catch (e) {} return; }
    upd.downloading = true; setDisabled('btnUpdGo', true);
    $('updBarWrap').hidden = false; $('updBar').style.width = '0%'; say('msgUpd', 'Baixando a atualização… 0%', 'warn');
    $('btnUpdLater').hidden = false; $('btnUpdLater').textContent = 'CANCELAR DOWNLOAD';
    try { B.downloadUpdate(upd.info.apkUrl, upd.info.sha256, upd.info.apkSize || 0, U.apkFileName(upd.info)); }
    catch (e) { window.__onUpdateDownloaded({ ok: false, msg: 'Não foi possível iniciar o download (' + e + ').' }); }
  }
  window.__onUpdateProgress = function (f) {
    var pct = Math.max(0, Math.min(100, Math.round(f * 100)));
    $('updBar').style.width = pct + '%'; say('msgUpd', 'Baixando a atualização… ' + pct + '%', 'warn');
  };
  window.__onUpdateDownloaded = function (r) {
    upd.downloading = false; r = r || {};
    $('btnUpdLater').hidden = upd.state !== 'optional'; $('btnUpdLater').textContent = 'AGORA NÃO';
    if (r.ok) { upd.downloaded = true; $('updBar').style.width = '100%'; say('msgUpd', 'Download conferido (SHA-256 confere). Abrindo a instalação…', 'ok'); $('btnUpdGo').querySelector('span').textContent = 'INSTALAR ATUALIZAÇÃO'; }
    else { $('updBarWrap').hidden = true; say('msgUpd', r.msg || 'O download falhou. Tente de novo.', 'err'); $('btnUpdGo').querySelector('span').textContent = 'TENTAR DE NOVO'; setDisabled('btnUpdGo', false); }
  };
  window.__onUpdateInstall = function (kind, r) {
    r = r || {}; setDisabled('btnUpdGo', false); $('btnUpdGo').querySelector('span').textContent = 'INSTALAR ATUALIZAÇÃO';
    say('msgUpd', r.msg || '', r.ok ? 'ok' : (r.code === 'needs_permission' ? 'warn' : 'err'));
  };
  if (hasUpdater && U) {
    tap('btnUpdGo', startDownload);
    tap('btnUpdLater', function () {
      if (upd.downloading) { try { B.cancelUpdateDownload(); } catch (e) {} say('msgUpd', 'Download cancelado.', 'warn'); return; }
      if (upd.state === 'optional') { upd.dismissed = true; hidePanel(); }
    });
    $('btnCheckUpd').hidden = false;
    $('btnCheckUpd').addEventListener('click', function () { Diag.tap('VERIFICAR ATUALIZAÇÕES'); check(true); });
    setTimeout(function () { check(false); }, 600);
  }
  window.BetmcV6 = { state: function () { return upd.state; }, locked: function () { return !!window.__betmcLocked; } };
})();
