/*
 * BetMC — interface do conversor VÍDEO → MCPACK (única tela do app).
 * Lógica em video.js (plano/validação, testada em Node) e VideoEngine.kt (extração/ZIP). Aqui: estados, progresso real,
 * reconstrução do estado ao voltar ao app e feedback visual. Nada de progresso fictício: a % vem do processamento.
 */
(function () {
  'use strict';
  var Diag = window.BetmcDiag || { set: function () {}, log: function () {}, error: function () {}, tap: function () {} };
  var $ = function (id) { return document.getElementById(id); };
  var C = window.BetmcCore, V = window.BetmcVideo, B = window.AndroidBridge;
  if (!$('btnPick')) return;
  var hasNative = !!(B && B.pickVideo && B.startVideoBuild && B.baseSize && B.getVideoState);
  var hasTrim = hasNative && !!(B.requestTimeline && B.requestPreview);   // APK/ponte sem recorte: comportamento da V5 (início do vídeo, até 12 s)
  var st = { sel: null, tl: { gen: -1, key: '' }, pv: { gen: -1, frames: [], timer: null, drag: null }, mode: 'empty', video: null, plan: null, outName: '', busy: false, preparing: false, validating: false, saving: false, cancelReq: false, touched: { file: false, name: false } };
  var tick = function () { return new Promise(function (r) { setTimeout(r, 0); }); };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var fmtMB = function (n) { return (n / 1048576).toFixed(n >= 10485760 ? 0 : 1) + ' MB'; };
  function say(id, text, kind) { var e = $(id); e.textContent = text || ''; e.className = 'msg' + (kind ? ' ' + kind : ''); }
  function disable(id, d) { var b = $(id); b.setAttribute('aria-disabled', d ? 'true' : 'false'); }
  function fmtDur(ms) { var s = ms / 1000, m = Math.floor(s / 60); return m ? m + ' min ' + Math.round(s - m * 60) + ' s' : s.toFixed(s < 10 ? 1 : 0) + ' s'; }
  function icon(id) { return '<svg class="ic"><use href="#' + id + '"/></svg>'; }

  /* ---------------------------------------------------------------- mensagens de erro compreensíveis */
  function friendly(raw) {
    var m = String(raw || '');
    if (/decodific|codec|faixa de v[ií]deo|primeiro quadro/i.test(m)) return 'Não foi possível ler os quadros deste vídeo. O formato pode não ser compatível com este aparelho. Tente outro vídeo (de preferência MP4).';
    if (/Espa[cç]o livre|ENOSPC|No space|insuficiente: preciso/i.test(m)) return 'Não há espaço suficiente no aparelho para gerar o pacote. Libere armazenamento ou escolha menos FPS ou uma resolução menor, e tente de novo.';
    if (/Mem[óo]ria insuficiente|OutOfMemory/i.test(m)) return 'O aparelho ficou sem memória durante a conversão. Tente uma resolução menor (960×540 ou 854×480).';
    if (/interrompida/i.test(m)) return 'A conversão foi interrompida antes de terminar (o app foi encerrado ou o sistema parou o processamento). Toque em tentar novamente.';
    if (/trecho escolhido come[cç]a/i.test(m)) return 'O trecho escolhido não cabe mais no vídeo. Ajuste o recorte e tente de novo.';
    if (/reler o v[ií]deo|permiss|selecione-o novamente/i.test(m)) return 'Não foi possível reabrir o vídeo escolhido. Selecione-o de novo.';
    if (/Valida[cç][aã]o|verifica|corrompid|manifest|incompleto/i.test(m)) return 'O pacote gerado não passou na verificação e por isso não foi liberado. Tente de novo; se repetir, use menos FPS ou outra resolução.';
    if (/aleat[óo]rio seguro/i.test(m)) return 'Este aparelho não conseguiu gerar os identificadores do pacote. Atualize o Android System WebView e tente de novo.';
    return 'Algo deu errado durante a conversão. Tente novamente. Se o problema continuar, o suporte pode pedir o diagnóstico (acesso de desenvolvedor).';
  }

  /* ---------------------------------------------------------------- estados da tela */
  function setMode(m) {
    st.mode = m; $('app').setAttribute('data-mode', m);
    var ready = m === 'ready', empty = m === 'empty';
    $('pCard').hidden = !(ready || empty);
    $('vidBox').hidden = !(ready && st.video); $('vNote').hidden = !(ready && st.video);
    $('pTrim').hidden = !(ready && st.video && hasTrim);
    if (!ready) stopPreview(true);
    $('pAdv').hidden = !ready; $('btnStart').hidden = !ready;
    $('pRun').hidden = m !== 'running'; $('pDone').hidden = m !== 'done'; $('pErr').hidden = m !== 'error';
    disable('btnStart', !(ready && st.video));
    window.scrollTo(0, 0);
    if (ready && st.video && hasTrim) { renderTrim(); ensureTimeline(); }
  }
  function showError(raw) {
    st.busy = false; st.preparing = false;
    Diag.error('vídeo → mcpack: ' + raw); Diag.set('conv', '✖ ' + String(raw).slice(0, 120), 'bad');
    $('errMsg').textContent = friendly(raw); setMode('error');
  }

  /* ---------------------------------------------------------------- abas inexistentes: só a tela de conversão. Configurações avançadas */
  $('advBtn').addEventListener('click', function () {
    var open = !$('pAdv').classList.contains('open');
    $('pAdv').classList.toggle('open', open); $('advBtn').setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  V.FPS_CHOICES.forEach(function (f) { var o = document.createElement('option'); o.value = String(f); o.textContent = f + ' FPS' + (f === V.DEFAULTS.fps ? ' (padrão)' : ''); if (f === V.DEFAULTS.fps) o.selected = true; $('vFps').appendChild(o); });
  V.SIZE_CHOICES.forEach(function (s) { var o = document.createElement('option'); o.value = s[0] + 'x' + s[1]; o.textContent = s[0] + '×' + s[1] + (s[0] === V.DEFAULTS.outW ? ' (padrão)' : ''); if (s[0] === V.DEFAULTS.outW) o.selected = true; $('vSize').appendChild(o); });
  function cfg() { var wh = $('vSize').value.split('x').map(Number); return { fps: +$('vFps').value, w: wh[0], h: wh[1] }; }
  function updateNote() {
    if (!st.video) return;
    var c = cfg(), sel = curSel(), n = V.frameCountForSelection(sel.lenMs, c.fps), total = st.video.durationMs / 1000;
    var mb = (n * c.w * c.h * 3 * 0.5) / 1048576;
    $('vNote').innerHTML = '<b>' + n + ' quadros</b> a ' + c.fps + ' FPS · trecho <b>' + V.fmtTime(sel.startMs) + ' → ' + V.fmtTime(sel.endMs) + '</b> (' + V.fmtTime(sel.lenMs) + ')' + (total > V.MAX_SECONDS ? ' · limite de 12 s' : '') +
      '<br>Recorte central 16:9 sem distorção · saída ' + c.w + '×' + c.h + ' · pacote de até ~' + Math.round(mb) + ' MB';
  }
  $('vFps').addEventListener('change', updateNote); $('vSize').addEventListener('change', updateNote);
  $('vFile').addEventListener('input', function () { st.touched.file = true; });
  $('vName').addEventListener('input', function () { st.touched.name = true; });

  /* ---------------------------------------------------------------- notificações (ligar/desligar + permissão) */
  function notifOn() { return !!(hasNative && B.notifEnabled && B.notifEnabled()); }
  function ensureNotifPermission() {
    return new Promise(function (resolve) {
      if (!(notifOn() && B.needsNotifPermission && B.needsNotifPermission())) return resolve();
      var done = false;
      window.__onNotifPermission = function (g) { if (done) return; done = true; Diag.log('permissão de notificações: ' + g); resolve(); };
      setTimeout(function () { if (!done) { done = true; resolve(); } }, 60000);
      B.requestNotifPermission();
    });
  }
  $('swNotif').addEventListener('change', function () {
    Diag.tap('notificações ' + this.checked);
    if (!hasNative || !B.setNotifEnabled) return;
    B.setNotifEnabled(this.checked);
    if (this.checked && B.needsNotifPermission && B.needsNotifPermission()) { window.__onNotifPermission = function (g) { Diag.log('permissão de notificações: ' + g); }; B.requestNotifPermission(); }
  });

  /* ---------------------------------------------------------------- RECORTE MANUAL (V6): linha do tempo, marcadores e prévia */
  function curSel() {
    if (!st.video) return { startMs: 0, endMs: 0, lenMs: 0 };
    if (!st.sel) st.sel = V.normalizeSelection(st.video.durationMs);
    return st.sel;
  }
  function setSel(sel, commit) {
    st.sel = sel; renderTrim(); updateNote();
    if (commit !== false) { if (B && B.setSelection) B.setSelection(sel.startMs, sel.endMs); markPreviewStale(); }
  }
  function renderTrim() {
    if (!st.video || !hasTrim || $('pTrim').hidden) return;
    var dur = st.video.durationMs, sel = curSel(), a = sel.startMs / dur * 100, b = sel.endMs / dur * 100;
    $('hStart').style.left = a + '%'; $('hEnd').style.left = b + '%';
    $('tlDimL').style.width = a + '%'; $('tlDimR').style.width = (100 - b) + '%';
    $('tlWin').style.left = a + '%'; $('tlWin').style.width = (b - a) + '%';
    [['hStart', sel.startMs], ['hEnd', sel.endMs]].forEach(function (h) { var e = $(h[0]); e.setAttribute('aria-valuemax', String(dur)); e.setAttribute('aria-valuenow', String(h[1])); e.setAttribute('aria-valuetext', V.fmtTime(h[1])); });
    $('tlRead').innerHTML = '<span>Início <b>' + V.fmtTime(sel.startMs) + '</b></span><span>Fim <b>' + V.fmtTime(sel.endMs) + '</b></span><span>Trecho <b>' + V.fmtTime(sel.lenMs) + '</b></span>';
  }
  /** Miniaturas da linha do tempo: pedidas ao nativo uma vez por vídeo; chegam uma a uma. */
  function ensureTimeline() {
    var key = (st.video.name || '') + '|' + st.video.durationMs;
    if (st.tl.key === key) return;
    st.tl.key = key;
    var n = Math.max(6, Math.min(12, Math.round(($('tl').clientWidth || 300) / 44))), box = $('tlThumbs');
    box.innerHTML = ''; for (var i = 0; i < n; i++) { var im = document.createElement('img'); im.alt = ''; box.appendChild(im); }
    var g = B.requestTimeline(n, 112); st.tl.gen = typeof g === 'number' ? g : -1;
  }
  window.__onTimelineThumb = function (gen, i, b64) {
    if (st.tl.gen >= 0 && gen !== st.tl.gen) return;
    var im = $('tlThumbs').children[i]; if (im) im.src = 'data:image/jpeg;base64,' + b64;
  };
  window.__onTimelineDone = function (gen, ok) {
    if (st.tl.gen >= 0 && gen !== st.tl.gen) return;
    if (!ok && !$('tlThumbs').querySelector('img[src]')) say('msgTrim', 'Não foi possível gerar as miniaturas. Você ainda pode escolher o trecho pelos marcadores.', 'warn');
  };
  /* marcadores: arrastar com o dedo (Pointer Events) ou teclado; passos de 0,1 s; o limite de 12 s empurra o outro marcador */
  function bindHandle(el, which) {
    el.addEventListener('pointerdown', function (e) {
      if (window.__betmcLocked || !st.video) return;
      e.preventDefault(); try { el.setPointerCapture(e.pointerId); } catch (x) {}
      el.classList.add('drag'); st.pv.drag = { which: which, id: e.pointerId };
    });
    el.addEventListener('pointermove', function (e) {
      var d = st.pv.drag; if (!d || d.which !== which || d.id !== e.pointerId) return;
      var r = $('tl').getBoundingClientRect(); if (!(r.width > 0)) return;
      var ms = (e.clientX - r.left) / r.width * st.video.durationMs;
      setSel(V.moveMarker(curSel(), which, ms, st.video.durationMs, V.MAX_SECONDS, 100), false);
    });
    function end(e) {
      var d = st.pv.drag; if (!d || d.which !== which) return;
      st.pv.drag = null; el.classList.remove('drag'); setSel(curSel(), true);   // grava uma vez, ao soltar
    }
    el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end); el.addEventListener('lostpointercapture', end);
    el.addEventListener('keydown', function (e) {
      var k = e.key === 'ArrowLeft' ? -1 : e.key === 'ArrowRight' ? 1 : 0; if (!k || !st.video) return;
      e.preventDefault(); nudge(which, k * 100);
    });
  }
  function nudge(which, deltaMs) {
    if (!st.video || window.__betmcLocked) return;
    var sel = curSel();
    setSel(V.moveMarker(sel, which, (which === 'start' ? sel.startMs : sel.endMs) + deltaMs, st.video.durationMs, V.MAX_SECONDS, 1), true);
  }
  bindHandle($('hStart'), 'start'); bindHandle($('hEnd'), 'end');
  $('nsM').addEventListener('click', function () { nudge('start', -100); }); $('nsP').addEventListener('click', function () { nudge('start', 100); });
  $('neM').addEventListener('click', function () { nudge('end', -100); }); $('neP').addEventListener('click', function () { nudge('end', 100); });
  window.addEventListener('resize', renderTrim);

  /* prévia: quadros reduzidos em loop + quadros exatos de início e fim (para conferir o corte antes de converter) */
  function stopLoop() { if (st.pv.timer) { clearInterval(st.pv.timer); st.pv.timer = null; } }
  function stopPreview(cancelNative) {
    stopLoop(); st.pv.gen = -2;
    if (cancelNative && hasTrim && B.cancelPreview) { try { B.cancelPreview(); } catch (e) {} }
    disable('btnPreview', false);
  }
  function markPreviewStale() {
    if ($('prev').hidden) return;
    stopPreview(true); $('prev').classList.add('stale');
    say('msgTrim', 'Prévia desatualizada: toque em VER PRÉVIA DO TRECHO para atualizar.', 'warn');
  }
  $('btnPreview').addEventListener('click', function () {
    Diag.tap('VER PRÉVIA DO TRECHO');
    if (!st.video || !hasTrim || window.__betmcLocked || st.busy) return;
    var sel = curSel();
    stopLoop(); st.pv.frames = []; $('prev').hidden = false; $('prev').classList.remove('stale');
    $('pvStart').removeAttribute('src'); $('pvEnd').removeAttribute('src'); $('pvLoop').removeAttribute('src');
    $('pvStartCap').textContent = 'Início · ' + V.fmtTime(sel.startMs); $('pvEndCap').textContent = 'Fim · ' + V.fmtTime(sel.endMs);
    say('msgTrim', 'Gerando prévia…', 'warn'); disable('btnPreview', true);
    var g = B.requestPreview(sel.startMs, sel.endMs, 6, 220); st.pv.gen = typeof g === 'number' ? g : -1;
  });
  window.__onPreviewFrame = function (gen, kind, idx, total, b64) {
    if (st.pv.gen === -2 || (st.pv.gen >= 0 && gen !== st.pv.gen)) return;
    var url = 'data:image/jpeg;base64,' + b64;
    if (kind === 'start') $('pvStart').src = url; else if (kind === 'end') $('pvEnd').src = url;
    else { st.pv.frames[idx] = url; if (idx === 0) $('pvLoop').src = url; say('msgTrim', 'Gerando prévia… ' + (idx + 1) + '/' + total, 'warn'); }
  };
  window.__onPreviewDone = function (gen, ok) {
    if (st.pv.gen === -2 || (st.pv.gen >= 0 && gen !== st.pv.gen)) return;
    disable('btnPreview', false);
    if (!ok || !st.pv.frames.length) { say('msgTrim', 'Não foi possível gerar toda a prévia deste trecho. Os marcadores continuam valendo para a conversão.', 'err'); return; }
    say('msgTrim', '', '');
    var i = 0, fr = st.pv.frames; stopLoop();
    if (fr.length > 1) st.pv.timer = setInterval(function () { if (document.hidden) return; i = (i + 1) % fr.length; $('pvLoop').src = fr[i]; }, 1000 / 6);
  };

  /* ---------------------------------------------------------------- 1) seleção do vídeo */
  // Duas origens: GALERIA (seletor nativo de fotos/vídeos do Android) e ARQUIVOS (gerenciador de arquivos). Ambas entregam
  // uma URI ao mesmo processamento (sondagem → miniatura/duração/resolução → conversão).
  function pickVia(kind) {
    Diag.tap(kind === 'gallery' ? 'GALERIA' : 'ARQUIVOS');
    if (window.__betmcLocked) return;
    if (st.busy) { say('msgPick', 'Aguarde: há uma conversão em andamento.', 'warn'); return; }
    if (!hasNative) { say('msgPick', 'A conversão de vídeo funciona apenas no aplicativo BetMC para Android.', 'err'); return; }
    say('msgPick', '', '');
    if (kind === 'gallery' && B.pickGallery) B.pickGallery(); else B.pickVideo();
  }
  $('btnGallery').addEventListener('click', function () { pickVia('gallery'); });
  $('btnPick').addEventListener('click', function () { pickVia('files'); });
  if (hasNative && !B.pickGallery) $('btnGallery').hidden = true; // APK/ponte sem Galeria: só o seletor de arquivos
  function setVideo(info, restoring) {
    st.video = info; st.sel = null; st.tl.key = ''; stopPreview(true); $('prev').hidden = true;
    var rs = V.rotatedSize(info.width, info.height, info.rotation || 0);
    $('vThumb').src = 'data:image/jpeg;base64,' + info.thumb;
    $('vThumbTag').textContent = fmtDur(info.durationMs);
    $('vName0').textContent = info.name || 'Vídeo selecionado';
    $('vChips').innerHTML = '<span class="chip">' + icon('i-clock') + fmtDur(info.durationMs) + '</span><span class="chip">' + icon('i-film') + rs[0] + '×' + rs[1] + '</span>';
    if (!st.touched.file || restoring) { var base = V.videoBaseName(info.name) || 'Animation'; if (!st.touched.file) $('vFile').value = base; if (!st.touched.name) $('vName').value = base; }
    $('dropT').textContent = 'Trocar vídeo';
    updateNote();
    Diag.set('import', (info.name || '?') + ' · ' + fmtDur(info.durationMs) + ' · ' + rs[0] + '×' + rs[1], 'ok');
  }
  window.__onVideoPicked = function (info) {
    if (typeof info === 'string') { try { info = JSON.parse(info); } catch (e) { info = { ok: false, err: 'resposta inválida' }; } }
    if (!info.ok) {
      if (info.err === 'cancelado') { say('msgPick', '', ''); return; }
      say('msgPick', friendly(info.err), 'err'); Diag.error('vídeo: ' + info.err); return;
    }
    say('msgPick', '', ''); setVideo(info, false); setMode('ready');
  };

  /* ---------------------------------------------------------------- progresso REAL */
  function setProgress(frac, stage) {
    var pct = Math.round(Math.max(0, Math.min(1, frac)) * 100);
    $('barFill').style.width = pct + '%'; $('bar').setAttribute('aria-valuenow', String(pct)); $('runPct').textContent = pct + '%';
    if (stage) $('runStage').textContent = stage;
    var step = frac < 0.06 ? 1 : frac < 0.94 ? 2 : 3;
    [].slice.call($('steps').children).forEach(function (li) { var s = +li.getAttribute('data-s'); li.className = s < step ? 'done' : s === step ? 'on' : ''; });
  }
  function runUi(active) { $('bar').classList.toggle('stop', !active); }

  /* ---------------------------------------------------------------- 2) conversão automática */
  function b64ToU8(b64) { var bin = atob(b64), u = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u; }
  async function loadBase() {
    var size = B.baseSize();
    if (!(size > 0)) throw new Error('Pacote-base não encontrado dentro do aplicativo (assets/base).');
    var parts = [], got = 0;
    for (var i = 0; got < size; i++) {
      var b64 = B.baseChunk(i);
      if (!b64) throw new Error('Falha ao ler o pacote-base embutido.');
      var u = b64ToU8(b64); parts.push(u); got += u.length; await tick();
    }
    if (got !== size) throw new Error('Pacote-base lido incompleto (' + got + ' de ' + size + ' bytes).');
    return new Blob(parts);
  }
  function backToReady() { st.busy = false; st.preparing = false; setMode(st.video ? 'ready' : 'empty'); }
  $('btnStart').addEventListener('click', async function () {
    Diag.tap('CONVERTER');
    if (st.busy || window.__betmcLocked) return;
    if (!hasNative) { say('msgPick', 'A conversão de vídeo funciona apenas no aplicativo BetMC para Android.', 'err'); return; }
    if (!st.video) return;
    var c = cfg(), sel = curSel(), N = V.frameCountForSelection(sel.lenMs, c.fps);
    if (N < 1) { showError('O vídeo é curto demais para o FPS escolhido.'); return; }
    stopPreview(true);
    st.busy = true; st.preparing = true; st.cancelReq = false; st.plan = null;
    $('runTitle').textContent = 'Convertendo'; runUi(true); setProgress(0.01, 'Preparando'); setMode('running'); disable('btnCancel', false);
    $('runNote').textContent = notifOn() ? 'Você pode sair do app: a conversão continua em segundo plano e avisamos quando terminar.' : 'Mantenha o BetMC aberto até concluir (notificações desligadas).';
    Diag.set('conv', 'preparando…', 'warn');
    try {
      await ensureNotifPermission();
      if (notifOn() && B.notifAllowed && !B.notifAllowed()) $('runNote').textContent = 'Você pode sair do app, mas as notificações estão bloqueadas no Android: volte aqui para ver o resultado.';
      setProgress(0.02, 'Carregando o pacote-base'); var base = await loadBase();
      if (st.cancelReq) { backToReady(); return; }
      setProgress(0.04, 'Planejando o pacote');
      var plan = await V.buildPlan(C, base, { N: N, fps: c.fps, startMs: sel.startMs, endMs: sel.endMs, outW: c.w, outH: c.h, displayName: V.displayNameOf($('vName').value, st.video.name), description: $('vDesc').value });
      if (st.cancelReq) { backToReady(); return; }
      plan.warnings.forEach(function (w) { Diag.log('aviso: ' + w); }); // avisos técnicos: só no diagnóstico
      st.plan = plan; st.outName = V.mcpackFileName($('vFile').value, st.video.name);
      setProgress(0.06, 'Iniciando a extração dos quadros');
      var r = B.startVideoBuild(JSON.stringify(V.nativePlan(plan, st.outName)), JSON.stringify(plan));
      if (r !== 'ok') throw new Error(String(r).replace(/^err:/, ''));
      st.preparing = false; Diag.set('conv', 'extraindo quadros…', 'warn');
      if (st.cancelReq && B.cancelVideo) B.cancelVideo();
    } catch (e) { showError(e.message || String(e)); }
  });
  $('btnCancel').addEventListener('click', function () {
    Diag.tap('CANCELAR'); st.cancelReq = true; disable('btnCancel', true); $('runStage').textContent = 'Cancelando…';
    if (!st.preparing && B && B.cancelVideo) B.cancelVideo();
  });

  window.__onVideoProgress = function (frac, stage) { if (st.mode !== 'running') { st.busy = true; setMode('running'); } setProgress(frac, stage); };
  window.__onVideoError = function (msg) { showError(msg); };
  window.__onVideoCancelled = function () { Diag.set('conv', 'cancelada', 'warn'); backToReady(); };
  window.__onVideoBuilt = function (str) {
    try { var S = typeof str === 'string' ? JSON.parse(str) : str; if (st.plan) verifyAndFinish(S, st.plan); else syncFromNative(); }
    catch (e) { showError('Erro ao ler o resultado: ' + (e.message || e)); }
  };

  /* verificação (14 itens) do pacote gravado → libera o download */
  async function verifyAndFinish(S, plan) {
    if (st.validating) return;
    st.validating = true;
    try {
      st.busy = true; if (st.mode !== 'running') setMode('running');
      $('runTitle').textContent = 'Verificando'; setProgress(0.96, 'Verificando o pacote'); await tick();
      var v = V.validatePackage(S, plan);
      v.checks.forEach(function (c) { Diag.log((c.ok ? '✔ ' : '✖ ') + c.label + (c.detail ? ' — ' + c.detail : '')); });
      if (!v.ok) {
        var bad = v.checks.filter(function (x) { return !x.ok; }).map(function (x) { return x.label + (x.detail ? ' — ' + x.detail : ''); }).join(' | ');
        if (B.reportValidation) B.reportValidation(false, 'verificação falhou');
        showError('Validação falhou: ' + bad); return;
      }
      if (B.reportValidation) B.reportValidation(true, '');
      finishDone({ frames: plan.N, fileSize: S.fileSize, outName: st.outName });
    } catch (e) { showError('Erro ao verificar: ' + (e.message || e)); }
    finally { st.validating = false; }
  }
  function finishDone(info) {
    st.busy = false; st.preparing = false; st.outName = info.outName || st.outName;
    setProgress(1, 'Concluído'); runUi(false);
    $('doneS').textContent = (info.frames ? info.frames + ' quadros · ' : '') + (info.fileSize ? fmtMB(info.fileSize) + ' · ' : '') + st.outName;
    say('msgSave', '', ''); $('saveBarWrap').hidden = true; setSave(0); disable('btnSave', false);
    Diag.set('conv', '✔ pacote verificado e pronto', 'ok'); setMode('done');
  }

  /* ---------------------------------------------------------------- 3) exportação */
  function setSave(f) { $('saveBar').style.width = Math.round(Math.max(0, Math.min(1, f)) * 100) + '%'; }
  $('btnSave').addEventListener('click', function () {
    Diag.tap('BAIXAR MCPACK PRONTO');
    if (st.saving) { say('msgSave', 'Gravação em andamento.', 'warn'); return; }
    st.saving = true; setSave(0); $('saveBarWrap').hidden = false; say('msgSave', 'Escolha onde salvar…', 'warn'); B.exportVideoPack(st.outName || 'BetMC.mcpack');
  });
  window.__onVideoExportProgress = function (frac) { setSave(frac); };
  window.__onVideoExported = function (info) {
    st.saving = false;
    if (typeof info === 'string') { try { info = JSON.parse(info); } catch (e) { info = { ok: false, err: 'resposta inválida' }; } }
    if (!info.ok) {
      $('saveBarWrap').hidden = true;
      if (info.err === 'cancelado') { say('msgSave', 'Salvamento cancelado. Toque em baixar para tentar de novo.', 'warn'); return; }
      Diag.error('exportação: ' + info.err); say('msgSave', 'Não foi possível salvar o arquivo. Verifique o espaço livre e tente de novo.', 'err'); return;
    }
    var exp = info.expected;
    var good = info.written === exp && (info.onDisk < 0 || info.onDisk === exp);
    if (!good) { Diag.error('exportação: bytes divergentes (esperado ' + exp + ', gravado ' + info.written + ', disco ' + info.onDisk + ')'); $('saveBarWrap').hidden = true; say('msgSave', 'O arquivo não foi gravado por completo. Tente baixar de novo.', 'err'); return; }
    setSave(1); say('msgSave', '✔ Salvo: ' + (info.name || st.outName) + ' (' + fmtMB(info.written) + '). Abra o arquivo para importar no Minecraft.', 'ok');
    Diag.set('save', '✔ ' + (info.name || st.outName) + ' · ' + info.written + ' bytes', 'ok');
  };
  $('btnNew').addEventListener('click', function () { Diag.tap('NOVA CONVERSÃO'); if (hasNative && B.resetVideo) B.resetVideo(); st.plan = null; backToReady(); });
  $('btnRetry').addEventListener('click', function () { Diag.tap('TENTAR NOVAMENTE'); if (hasNative && B.resetVideo) B.resetVideo(); st.plan = null; backToReady(); });

  /* ---------------------------------------------------------------- reconstrução do estado (voltar ao app / toque na notificação) */
  function applyNativeState(s) {
    if (!s) return;
    $('swNotif').checked = !!s.notifEnabled;
    if (s.video && (!st.video || st.video.name !== s.video.name || st.video.durationMs !== s.video.durationMs)) setVideo(s.video, true);
    if (hasTrim && st.video && s.selStart >= 0 && s.selEnd > s.selStart) {   // trecho escolhido antes de sair do app
      var rs0 = V.normalizeSelection(st.video.durationMs, s.selStart, s.selEnd), cs = curSel();
      if (rs0.startMs !== cs.startMs || rs0.endMs !== cs.endMs) setSel(rs0, false);
    }
    switch (s.status) {
      case 'running':
        st.busy = true; st.preparing = false; if (st.mode !== 'running') { $('runTitle').textContent = 'Convertendo'; setMode('running'); }
        runUi(true); setProgress(s.progress || 0, s.stage || 'Convertendo'); break;
      case 'built':
        if (!st.validating) { try { var plan = JSON.parse(s.plan), S = JSON.parse(s.summary); st.plan = plan; st.outName = s.outName; verifyAndFinish(S, plan); } catch (e) { showError('Erro ao reconstruir o resultado: ' + (e.message || e)); } }
        break;
      case 'ready':
        if (st.mode !== 'done') finishDone({ frames: s.frames, fileSize: s.fileSize, outName: s.outName });
        break;
      case 'error':
        if (!st.preparing && st.mode !== 'error') showError(s.error || 'erro desconhecido');
        break;
      default: // idle
        if (st.mode === 'running' && !st.preparing) backToReady();
        else if (st.mode === 'empty' && st.video) setMode('ready');
    }
  }
  function syncFromNative() {
    if (!hasNative) return;
    try { applyNativeState(JSON.parse(B.getVideoState())); } catch (e) { Diag.error('estado: ' + e.message); }
  }
  window.__onVideoResume = syncFromNative;
  document.addEventListener('visibilitychange', function () { if (!document.hidden) syncFromNative(); });

  /* ---------------------------------------------------------------- zoom por pinça bloqueado (reforço ao viewport/touch-action/WebView) */
  document.addEventListener('touchmove', function (e) { if (e.touches && e.touches.length > 1) e.preventDefault(); }, { passive: false });
  document.addEventListener('gesturestart', function (e) { e.preventDefault(); });

  /* ---------------------------------------------------------------- acesso de desenvolvedor: 7 toques rápidos no logotipo */
  (function () {
    var n = 0, t0 = 0;
    $('brand').addEventListener('click', function () {
      var now = Date.now(); if (now - t0 > 5000) n = 0; t0 = t0 && now - t0 <= 5000 ? t0 : now; n++;
      if (n >= 7) { n = 0; t0 = 0; var d = $('diag'); d.hidden = false; d.scrollIntoView({ behavior: 'smooth', block: 'start' }); Diag.log('painel de desenvolvedor aberto'); }
    });
  })();

  /* ---------------------------------------------------------------- diagnóstico (só desenvolvedor) e início */
  Diag.set('core', C ? '✔ BetmcCore carregado' : '✖ BetmcCore ausente', C ? 'ok' : 'bad');
  try {
    if (B && B.ping) { var pi = JSON.parse(B.ping()); Diag.set('bridge', '✔ ativa · Android SDK ' + pi.sdk + ' · WebView ' + pi.webview + (pi.model ? ' · ' + pi.model : ''), 'ok'); }
    else Diag.set('bridge', 'ausente (modo navegador)', 'warn');
  } catch (e) { Diag.set('bridge', '✖ erro na ponte: ' + e.message, 'bad'); }
  if (hasNative && B.notifEnabled) $('swNotif').checked = !!B.notifEnabled();
  setMode('empty');
  syncFromNative();
  window.BetmcApp = { mode: function () { return st.mode; }, busy: function () { return st.busy; }, selection: function () { return st.video ? curSel() : null; } };
  window.__betmcAppReady = true; Diag.set('app', '✔ interface pronta', 'ok'); Diag.log('video_ui.js pronto (ponte de vídeo ' + (hasNative ? 'presente' : 'ausente') + ')');
})();
